package com.knexis.tip.core.schema;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the RangeMatch POJO, verifying Lombok behavior and
 * the structure of the data fields.
 */
public class RangeMatchTest {

    @Test
    void testDefaultValues() {
        RangeMatch def = new RangeMatch();
        assertEquals(0, def.getStart(), "Start should default to 0");
        assertEquals(0, def.getEnd(), "End should default to 0");
        assertNull(def.getMatch(), "Match list should default to null");
    }

    @Test
    void testGettersAndSetters() {
        RangeMatch def = new RangeMatch();
        List<String> expectedMatchList = Arrays.asList("DFA", "HDR", "FTR");

        // Set all properties
        def.setStart(1);
        def.setEnd(3);
        def.setMatch(expectedMatchList);

        // Verify all properties
        assertEquals(1, def.getStart(), "Start position should be set correctly.");
        assertEquals(3, def.getEnd(), "End position should be set correctly.");
        assertEquals(expectedMatchList, def.getMatch(), "Match list should be set correctly.");
    }

    @Test
    void testToStringOutput() {
        RangeMatch def = new RangeMatch();
        List<String> matchList = Arrays.asList("RHR");

        def.setStart(1);
        def.setEnd(3);
        def.setMatch(matchList);

        // Asserting the exact Lombok @ToString format
        String expectedToString = "RangeMatch(start=1, end=3, match=[RHR])";

        assertEquals(expectedToString, def.toString(), "toString() should match the expected Lombok format.");
    }
}
