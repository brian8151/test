package com.knexis.tip.core.schema;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the RecordSchema POJO.
 */
public class RecordSchemaTest {

    @Test
    void testDefaultValues() {
        RecordSchema schema = new RecordSchema();
        assertNull(schema.getTagField(), "TagField should default to null");
        assertNull(schema.getFields(), "Fields list should default to null");
    }

    @Test
    void testGettersAndSetters() {
        RecordSchema schema = new RecordSchema();
        TagField tf = new TagField();
        FieldDef fd = new FieldDef();
        List<FieldDef> fields = Collections.singletonList(fd);

        // Set properties
        schema.setTagField(tf);
        schema.setFields(fields);

        // Verify properties
        assertSame(tf, schema.getTagField(), "TagField should be set correctly.");
        assertSame(fields, schema.getFields(), "Fields list should be set correctly.");
        assertEquals(1, schema.getFields().size());
    }

    @Test
    void testToStringOutput() {
        RecordSchema schema = new RecordSchema();
        TagField tf = new TagField();
        FieldDef fd = new FieldDef();
        List<FieldDef> fields = Collections.singletonList(fd);

        schema.setTagField(tf);
        schema.setFields(fields);

        // Asserting the exact Lombok @ToString format, relying on nested mocks' toString()
        String expectedToString = "RecordSchema(tagField=TagField(start=0, end=0, match=null), fields=[FieldDef(name=null, start=0, end=0, type=STRING, scale=null, pattern=null, trim=null, nullable=null, enumMap=null, allowedValues=null)])";
        assertEquals(expectedToString, schema.toString(), "toString() should match the expected Lombok format, including child objects.");
    }
}