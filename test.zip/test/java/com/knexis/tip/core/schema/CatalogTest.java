package com.knexis.tip.core.schema;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the Catalog POJO.
 */
public class CatalogTest {

    @Test
    void testDefaultValues() {
        Catalog catalog = new Catalog();
        assertNull(catalog.getSchemas(), "Schemas list should default to null.");
    }

    @Test
    void testGettersAndSettersWithEmptyList() {
        Catalog catalog = new Catalog();
        List<Entry> emptyList = Collections.emptyList();

        catalog.setSchemas(emptyList);

        assertSame(emptyList, catalog.getSchemas(), "Schemas list should be set correctly to an empty list.");
        assertTrue(catalog.getSchemas().isEmpty(), "The schemas list should be empty.");
    }

    @Test
    void testGettersAndSettersWithEntries() {
        Catalog catalog = new Catalog();

        Entry entry1 = new Entry();
        entry1.setId("DFA");
        entry1.setResource("direct-financial.yml");
        Entry entry2 = new Entry();
        entry1.setId("DIST");
        entry1.setResource("distribution.yml");
        List<Entry> schemas = Arrays.asList(entry1, entry2);

        catalog.setSchemas(schemas);

        assertSame(schemas, catalog.getSchemas(), "Schemas list should be set correctly.");
        assertEquals(2, catalog.getSchemas().size(), "The schemas list should contain 2 entries.");
        assertEquals("DIST", catalog.getSchemas().get(0).getId());
    }
}