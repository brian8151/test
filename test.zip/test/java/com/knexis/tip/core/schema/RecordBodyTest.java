package com.knexis.tip.core.schema;

import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the RecordBody POJO.
 */
public class RecordBodyTest {

    @Test
    void testDefaultValues() {
        RecordBody body = new RecordBody();
        assertNull(body.getStartRecord(), "StartRecord should default to null");
        assertNull(body.getGroupingKey(), "GroupingKey should default to null");
        assertNull(body.getRecords(), "Records list should default to null");
    }

    @Test
    void testGettersAndSetters() {
        RecordBody body = new RecordBody();
        StartRecord sr = new StartRecord();
        RecordDef rd = new RecordDef();
        List<RecordDef> records = Collections.singletonList(rd);
        String key = "constant";

        // Set properties
        body.setStartRecord(sr);
        body.setGroupingKey(key);
        body.setRecords(records);

        // Verify properties
        assertSame(sr, body.getStartRecord(), "StartRecord should be set correctly.");
        assertEquals(key, body.getGroupingKey(), "GroupingKey should be set correctly.");
        assertSame(records, body.getRecords(), "Records list should be set correctly.");
    }

}