package com.knexis.tip.core.schema;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the TagField POJO.
 */
public class TagFieldTest {

    @Test
    void testDefaultValues() {
        TagField tf = new TagField();
        // Integers default to 0
        assertEquals(0, tf.getStart(), "Start position should default to 0.");
        assertEquals(0, tf.getEnd(), "End position should default to 0.");
        // String defaults to null
        assertNull(tf.getMatch(), "Match string should default to null.");
    }

    @Test
    void testGettersAndSetters() {
        TagField tf = new TagField();
        final int newStart = 1;
        final int newEnd = 3;
        final String newMatch = "RHR";

        // Set properties
        tf.setStart(newStart);
        tf.setEnd(newEnd);
        tf.setMatch(newMatch);

        // Verify properties
        assertEquals(newStart, tf.getStart(), "Start position should be set correctly.");
        assertEquals(newEnd, tf.getEnd(), "End position should be set correctly.");
        assertEquals(newMatch, tf.getMatch(), "Match string should be set correctly.");
    }

    @Test
    void testToStringOutput() {
        TagField tf = new TagField();
        tf.setStart(1);
        tf.setEnd(3);
        tf.setMatch("RHR");

        String expectedToString = "TagField(start=1, end=3, match=RHR)";

        assertEquals(expectedToString, tf.toString(), "toString() should match the expected Lombok format.");
    }
}