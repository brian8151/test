package com.knexis.tip.core.schema;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the FieldDef POJO.
 */
public class FieldDefTest {

    @Test
    void testDefaultValues() {
        FieldDef def = new FieldDef();
        assertNull(def.getName(), "Name should default to null");
        assertEquals(0, def.getStart(), "Start should default to 0");
        assertEquals(0, def.getEnd(), "End should default to 0");
        assertEquals(FieldDef.DataType.STRING, def.getType(), "Type should default to STRING");
        assertNull(def.getScale(), "Scale should default to null");
        assertNull(def.getTrim(), "Trim should default to null");
    }

    @Test
    void testGettersAndSetters() {
        FieldDef def = new FieldDef();

        // Standard Fields
        def.setName("accountNumber");
        def.setStart(42);
        def.setEnd(61);
        def.setType(FieldDef.DataType.STRING);

        assertEquals("accountNumber", def.getName());
        assertEquals(42, def.getStart());
        assertEquals(61, def.getEnd());
        assertEquals(FieldDef.DataType.STRING, def.getType());

        // Optional Fields (set and verify non-null values)
        def.setScale(2);
        def.setPattern("yyyyMMdd");
        def.setTrim(true);
        def.setNullable(false);

        assertEquals(2, def.getScale());
        assertEquals("yyyyMMdd", def.getPattern());
        assertTrue(def.getTrim());
        assertFalse(def.getNullable());

        // Enum/List Fields
        Map<String, String> enumMap = new HashMap<>();
        enumMap.put("A", "ACH");
        def.setEnumMap(enumMap);

        List<String> allowedValues = Arrays.asList("0", "1");
        def.setAllowedValues(allowedValues);

        assertEquals(enumMap, def.getEnumMap());
        assertEquals(allowedValues, def.getAllowedValues());
    }

    @Test
    void testToStringOutput() {
        FieldDef def = new FieldDef();
        def.setName("fileTypeText");
        def.setStart(7);
        def.setEnd(21);
        def.setType(FieldDef.DataType.STRING);

        String expectedToString = "FieldDef(name=fileTypeText, start=7, end=21, type=STRING, scale=null, pattern=null, trim=null, nullable=null, enumMap=null, allowedValues=null)";

        assertEquals(expectedToString, def.toString(), "toString() should match the expected format");
    }

    @Test
    void testDataTypeEnumValues() {
        assertEquals(6, FieldDef.DataType.values().length);
        assertEquals(FieldDef.DataType.DECIMAL, FieldDef.DataType.valueOf("DECIMAL"));
        assertEquals(FieldDef.DataType.DATE, FieldDef.DataType.valueOf("DATE"));
        assertEquals(FieldDef.DataType.LONG, FieldDef.DataType.valueOf("LONG"));

    }
}