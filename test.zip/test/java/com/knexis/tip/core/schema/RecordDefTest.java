package com.knexis.tip.core.schema;
import jdk.jfr.Threshold;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the RecordDef POJO.
 */
public class RecordDefTest {

    private RangeMatch createRangeMatch(int start, int end, String match) {
        RangeMatch rm = new RangeMatch();
        rm.setStart(start);
        rm.setEnd(end);
        rm.setMatch(Collections.singletonList(match));
        return rm;
    }

    @Test
    void testDefaultValues() {
        RecordDef def = new RecordDef();
        // Primitives defaults
        assertFalse(def.isRequired(), "Required should default to false.");
        assertFalse(def.isRepeat(), "Repeat should default to false.");
        // Object/String defaults
        assertNull(def.getId(), "ID should default to null.");
        assertNull(def.getTag(), "Tag should default to null.");
        assertNull(def.getSequence(), "Sequence should default to null.");
        assertNull(def.getClassName(), "ClassName should default to null.");
        assertNull(def.getFields(), "Fields list should default to null.");
    }

    @Test
    void testGettersAndSetters() {
        RecordDef def = new RecordDef();
        // Use helper method to create RangeMatch instances
        RangeMatch tagMatch = createRangeMatch(1, 3, "DFA");
        RangeMatch seqMatch = createRangeMatch(4, 6, "001");

        FieldDef field = new FieldDef();
        field.setName("testField");
        List<FieldDef> fieldList = Collections.singletonList(field);

        // Set properties
        def.setId("DFA-001");
        def.setTag(tagMatch);
        def.setSequence(seqMatch);
        def.setClassName("com.example.Record1");
        def.setRequired(true);
        def.setRepeat(false);
        def.setFields(fieldList);

        // Verify properties
        assertEquals("DFA-001", def.getId(), "ID should be set correctly.");
        assertSame(tagMatch, def.getTag(), "Tag object reference should be correct.");
        assertSame(seqMatch, def.getSequence(), "Sequence object reference should be correct.");
        assertEquals("com.example.Record1", def.getClassName(), "ClassName should be set correctly.");
        assertTrue(def.isRequired(), "Required should be set to true.");
        assertFalse(def.isRepeat(), "Repeat should be set to false.");
        assertSame(fieldList, def.getFields(), "Fields list reference should be correct.");
    }

    @Test
    void testToStringOutput() {
        // Use helper method to create RangeMatch instances
        RangeMatch tagMatch = createRangeMatch(1, 3, "RHR");
        RangeMatch seqMatch = createRangeMatch(4, 6, "001");

        // The FieldDef mock now has a simplified toString(), so this assertion will pass.
        FieldDef field = new FieldDef();
        field.setName("recordType");
        List<FieldDef> fieldList = Collections.singletonList(field);

        RecordDef def = new RecordDef();
        def.setId("DFA-001");
        def.setTag(tagMatch);
        def.setSequence(seqMatch);
        def.setClassName("com.example.Record1");
        def.setRequired(true);
        def.setRepeat(false);
        def.setFields(fieldList);

        String actualToString = def.toString();
        assertTrue(actualToString.contains("id=DFA-001"), "ID must be present.");
        assertTrue(actualToString.contains("required=true"), "Required flag must be present.");
        assertTrue(actualToString.contains("tag=RangeMatch(start=1, end=3, match=[RHR])"), "Tag match data must be present.");
        assertTrue(actualToString.contains("sequence=RangeMatch(start=4, end=6, match=[001])"), "Sequence match data must be present.");

    }

    @Test
    void testThresholdAnnotationPresence() {
        assertTrue(RecordDef.class.isAnnotationPresent(Threshold.class),
                "RecordDef class should have the @Threshold annotation.");
    }
}
