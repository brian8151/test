package com.knexis.tip.core.schema;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the Entry POJO.
 */
public class EntryTest {

    @Test
    void testDefaultValues() {
        Entry entry = new Entry();
        // All strings should default to null
        assertNull(entry.getId(), "ID should default to null.");
        assertNull(entry.getResource(), "Resource should default to null.");
    }

    @Test
    void testGettersAndSetters() {
        Entry entry = new Entry();
        final String newId = "FINANCIALDIRECT";
        final String newResource = "schemas/financial-direct.yml";

        // Set properties
        entry.setId(newId);
        entry.setResource(newResource);

        // Verify properties
        assertEquals(newId, entry.getId(), "ID should be set correctly.");
        assertEquals(newResource, entry.getResource(), "Resource should be set correctly.");
    }

    @Test
    void testToStringOutput() {
        Entry entry = new Entry();
        entry.setId("DISTRIBUTION");
        entry.setResource("schemas/distribution.yml");

        String expectedToString = "Entry(id=DISTRIBUTION, resource=schemas/distribution.yml)";

        assertEquals(expectedToString, entry.toString(), "toString() should match the expected Lombok format.");
    }
}
