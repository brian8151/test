package com.knexis.tip.core.schema;

import com.knexis.tip.core.exception.SchemaException;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SchemaRegistryTest {

    @Test
    void load_success_with_catalog_and_fetch_by_id() {
        SchemaRegistry reg = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        // basic contains
        Set<String> ids = reg.allIds();
        assertThat(ids).isNotEmpty();
        assertThat(ids).contains("FINANCIALDIRECT");

        // fetch schema
        OutboundFileSchema dfa = reg.getById("FINANCIALDIRECT");
        assertThat(dfa).isNotNull();
        // If fileType is present in the YAML, it should equal the id by contract
        if (dfa.getFileType() != null) {
            assertThat(dfa.getFileType()).isEqualTo("FINANCIALDIRECT");
        }
    }

    @Test
    void allIds_is_unmodifiable() {
        SchemaRegistry reg = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        Set<String> ids = reg.allIds();
        assertThrows(UnsupportedOperationException.class, () -> ids.add("NEWID"));
    }

    @Test
    void getById_unknown_throws() {
        SchemaRegistry reg = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        assertThrows(SchemaException.class, () -> reg.getById("UNKNOWN_ID"));
    }

    @Test
    void empty_catalog_throws() {
        assertThrows(SchemaException.class,
                () -> SchemaRegistry.loadFromResource("schemas/catalog-empty.yml"));
    }

    @Test
    void missing_id_throws() {
        assertThrows(SchemaException.class,
                () -> SchemaRegistry.loadFromResource("schemas/catalog-missing-id.yml"));
    }

    @Test
    void missing_resource_throws() {
        assertThrows(SchemaException.class,
                () -> SchemaRegistry.loadFromResource("schemas/catalog-missing-resource.yml"));
    }

    @Test
    void mismatch_fileType_vs_id_throws() {
        assertThrows(SchemaException.class,
                () -> SchemaRegistry.loadFromResource("schemas/catalog-mismatch.yml"));
    }
}
