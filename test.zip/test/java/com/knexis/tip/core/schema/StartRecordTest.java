package com.knexis.tip.core.schema;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Unit tests for the StartRecord POJO.
 */
public class StartRecordTest {

    @Test
    void testDefaultValues() {
        StartRecord sr = new StartRecord();
        // All strings should default to null
        assertNull(sr.getTag(), "Tag should default to null.");
        assertNull(sr.getSequence(), "Sequence should default to null.");
        assertNull(sr.getRecordRef(), "RecordRef should default to null.");
    }

    @Test
    void testGettersAndSetters() {
        StartRecord sr = new StartRecord();
        final String newTag = "DFA";
        final String newSequence = "001";
        final String newRecordRef = "DFA-001";

        // Set properties
        sr.setTag(newTag);
        sr.setSequence(newSequence);
        sr.setRecordRef(newRecordRef);

        // Verify properties
        assertEquals(newTag, sr.getTag(), "Tag should be set correctly.");
        assertEquals(newSequence, sr.getSequence(), "Sequence should be set correctly.");
        assertEquals(newRecordRef, sr.getRecordRef(), "RecordRef should be set correctly.");
    }

    @Test
    void testToStringOutput() {
        StartRecord sr = new StartRecord();
        sr.setTag("RTR");
        sr.setSequence("001");
        sr.setRecordRef("RTR-001");

        String expectedToString = "StartRecord(tag=RTR, sequence=001, recordRef=RTR-001)";

        assertEquals(expectedToString, sr.toString(), "toString() should match the expected Lombok format.");
    }
}