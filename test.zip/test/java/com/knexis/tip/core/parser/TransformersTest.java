package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.FieldDef;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TransformersTest {

    /** Helper: set enum type on FieldDef via reflection (handles unknown enum class name). */
    private static void setType(FieldDef def, String enumName) throws Exception {
        Method setter = null;
        for (Method m : FieldDef.class.getMethods()) {
            if (m.getName().equals("setType") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isEnum()) {
                setter = m;
                break;
            }
        }
        if (setter == null) throw new IllegalStateException("FieldDef#setType(Enum) not found");
        @SuppressWarnings({"unchecked","rawtypes"})
        Class<? extends Enum> enumClass = (Class<? extends Enum>) setter.getParameterTypes()[0];
        @SuppressWarnings({"unchecked","rawtypes"})
        Enum val = Enum.valueOf((Class) enumClass, enumName);
        setter.invoke(def, val);
    }

    private static FieldDef mk(String type, boolean trim, boolean nullable) throws Exception {
        FieldDef d = new FieldDef();
        setType(d, type);
        d.setTrim(trim);
        d.setNullable(nullable);
        return d;
    }

    @Test
    void string_trim_and_nullable_behavior() throws Exception {
        // trim=true, nullable=true, raw="  " -> null
        FieldDef d1 = mk("STRING", true, true);
        Object v1 = Transformers.convert(d1, "   ");
        assertThat(v1).isNull();

        // trim=false, nullable=false, raw=null -> "" (no NPE)
        FieldDef d2 = mk("STRING", false, false);
        Object v2 = Transformers.convert(d2, null);
        assertThat(v2).isEqualTo("");

        // trim=true, nullable=false, raw="  A  " -> "A"
        FieldDef d3 = mk("STRING", true, false);
        Object v3 = Transformers.convert(d3, "  A  ");
        assertThat(v3).isEqualTo("A");
    }

    @Test
    void int_parsing_and_blanks() throws Exception {
        FieldDef di = mk("INT", true, false);

        // numeric
        assertThat(Transformers.convert(di, "123")).isEqualTo(123);

        // blank string (after trim) -> parseInt returns null
        assertThat(Transformers.convert(di, "   ")).isNull();

        // invalid -> NumberFormatException
        assertThrows(NumberFormatException.class, () -> Transformers.convert(di, "12x"));
    }

    @Test
    void long_parsing_and_blanks() throws Exception {
        FieldDef dl = mk("LONG", false, false);
        assertThat(Transformers.convert(dl, "9223372036854775806")).isEqualTo(9223372036854775806L);
        assertThat(Transformers.convert(dl, "")).isNull();
        assertThrows(NumberFormatException.class, () -> Transformers.convert(dl, "notALong"));
    }

    @Test
    void decimal_with_and_without_scale() throws Exception {
        FieldDef dd = mk("DECIMAL", false, false);
        dd.setScale(null);
        assertThat(Transformers.convert(dd, "12345")).isEqualTo(new BigDecimal("12345"));

        dd.setScale(2);
        assertThat(Transformers.convert(dd, "12345")).isEqualTo(new BigDecimal("123.45"));

        // blank -> null
        assertThat(Transformers.convert(dd, " ")).isNull();

        // invalid -> NumberFormatException
        assertThrows(NumberFormatException.class, () -> Transformers.convert(dd, "12a3"));
    }

    @Test
    void date_with_default_and_custom_patterns() throws Exception {
        FieldDef df = mk("DATE", true, false);

        // default yyyyMMdd
        df.setPattern(null);
        Object d1 = Transformers.convert(df, "20250819");
        assertThat(d1).isEqualTo(LocalDate.of(2025, 8, 19));

        // custom pattern
        df.setPattern("yyyy-MM-dd");
        Object d2 = Transformers.convert(df, "2025-10-06");
        assertThat(d2).isEqualTo(LocalDate.of(2025, 10, 6));

        // blank -> null
        Object d3 = Transformers.convert(df, "   ");
        assertThat(d3).isNull();

        // invalid -> DateTimeParseException
        assertThrows(java.time.format.DateTimeParseException.class, () -> Transformers.convert(df, "2025-13-99"));
    }

    @Test
    void enum_mapping_and_passthrough() throws Exception {
        FieldDef de = mk("ENUM", true, false);

        Map<String,String> map = new HashMap<>();
        map.put("A", "Alpha");
        map.put("B", "Beta");
        de.setEnumMap(map);

        assertThat(Transformers.convert(de, "A")).isEqualTo("Alpha");
        assertThat(Transformers.convert(de, "B")).isEqualTo("Beta");
        // unknown key -> identity
        assertThat(Transformers.convert(de, "Z")).isEqualTo("Z");

        // null map -> identity
        de.setEnumMap(null);
        assertThat(Transformers.convert(de, "A")).isEqualTo("A");
    }

    @Test
    void nullable_applies_before_type_conversion() throws Exception {
        // nullable=true, raw blank -> early null (even for INT)
        FieldDef dn = mk("INT", true, true);
        Object v = Transformers.convert(dn, "   ");
        assertThat(v).isNull();
    }
}
