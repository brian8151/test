package com.knexis.tip.core.parser;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

class BeanMapperTest {

    static class SetterBean {
        private Integer seq;
        boolean setterCalled = false;

        public Integer getSeq() { return seq; }
        public void setSeq(Integer seq) { this.seq = seq; this.setterCalled = true; }
    }

    static class PublicFieldBean {
        public String name;
    }

    static class PrivateFieldBean {
        private String data;
        public String getData() { return data; }
    }

    @Test
    void populate_usesSetter_whenExactTypeMatches() {
        SetterBean bean = new SetterBean();
        Map<String, Object> values = new HashMap<>();
        values.put("seq", 42);

        BeanMapper.populate(bean, values);

        assertEquals(42, bean.getSeq());
        assertTrue(bean.setterCalled, "Expected setter to be invoked when type matches exactly");
    }

    @Test
    void populate_setsPublicField_whenNoSetterPresent() {
        PublicFieldBean bean = new PublicFieldBean();
        Map<String, Object> values = new HashMap<>();
        values.put("name", "DFA");

        BeanMapper.populate(bean, values);

        assertEquals("DFA", bean.name);
    }

    @Test
    void populate_setsPrivateField_whenNoSetterPresent() {
        PrivateFieldBean bean = new PrivateFieldBean();
        Map<String, Object> values = new HashMap<>();
        values.put("data", "abcdef");

        BeanMapper.populate(bean, values);

        assertEquals("abcdef", bean.getData(), "Expected private field to be set via reflection");
    }

    @Test
    void populate_ignoresUnknownKeys_withoutThrowing() {
        SetterBean bean = new SetterBean();
        Map<String, Object> values = new HashMap<>();
        values.put("unknownProp", "whatever");
        assertDoesNotThrow(() -> BeanMapper.populate(bean, values));

    }

    @Test
    void populate_allowsNullAssignments() {
        SetterBean bean = new SetterBean();
        Map<String, Object> values = new HashMap<>();
        values.put("seq", null);
        assertDoesNotThrow(() -> BeanMapper.populate(bean, values));
        assertNull(bean.getSeq());
    }
}
