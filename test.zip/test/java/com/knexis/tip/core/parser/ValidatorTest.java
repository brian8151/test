package com.knexis.tip.core.parser;
import com.knexis.tip.core.exception.RecordParseException;
import com.knexis.tip.core.schema.FieldDef;
import com.knexis.tip.core.schema.RecordSchema;
import com.knexis.tip.core.schema.TagField;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ValidatorTest {

    @Test
    void minRequiredLength_ignores_filler_and_handles_null() {
        // null list -> 0
        assertThat(Validator.minRequiredLength(null)).isZero();

        // fields with and without filler (case/whitespace-insensitive)
        List<FieldDef> fields = new ArrayList<>();

        FieldDef f1 = new FieldDef();
        f1.setName("account");
        f1.setEnd(10);
        fields.add(f1);

        FieldDef filler = new FieldDef();
        filler.setName("  FILLER ");
        filler.setEnd(200);
        fields.add(filler);

        FieldDef f2 = new FieldDef();
        f2.setName("amount");
        f2.setEnd(20);
        fields.add(f2);

        int min = Validator.minRequiredLength(fields);
        assertThat(min).isEqualTo(20); // ignores filler (even though it has larger end)
    }

    @Test
    void assertLength_throws_on_null_line() {
        assertThrows(RecordParseException.class, () -> Validator.assertLength(null, 100, 1));
    }

    @Test
    void assertLength_throws_when_below_min_required() {
        String line = "12345"; // len=5
        // minRequiredLen = 8 -> should throw
        assertThrows(RecordParseException.class, () -> Validator.assertLength(line, 10, 8, 7));
    }

    @Test
    void assertLength_warns_only_when_missing_trailing_filler() {
        String line = "1234567890"; // len=10
        // expected=20 but minRequiredLen=0 -> should NOT throw (warning only)
        assertDoesNotThrow(() -> Validator.assertLength(line, 20, 0, 3));

        // expected=20 and minRequiredLen=5 (actual 10 >= 5) -> also should NOT throw
        assertDoesNotThrow(() -> Validator.assertLength(line, 20, 5, 4));
    }

    @Test
    void preview_limits_length_and_handles_null() {
        assertThat(Validator.preview(null)).isEqualTo("");
        assertThat(Validator.preview("short")).isEqualTo("short");

        String longStr = "A".repeat(150);
        String preview = Validator.preview(longStr);
        assertThat(preview).endsWith("...");
        assertThat(preview.length()).isEqualTo(123); // 120 + "..."
        assertThat(preview.substring(0, 3)).isEqualTo("AAA");
    }

    private static RecordSchema headerSchema(String tag, int start, int end) {
        TagField tf = new TagField();
        tf.setMatch(tag);
        tf.setStart(start);
        tf.setEnd(end);
        RecordSchema rs = new RecordSchema();
        rs.setTagField(tf);
        return rs;
    }

    @Test
    void validateHeaderLine_success_and_failures() {
        RecordSchema rs = headerSchema("RHR", 1, 3);
        String line = "RHR001FINANCIALDIRECT";

        // success
        assertDoesNotThrow(() -> Validator.validateHeaderLine(line, rs, 0));

        // wrong tag -> throws
        String bad = "ZZZ001FINANCIALDIRECT";
        assertThrows(IllegalArgumentException.class, () -> Validator.validateHeaderLine(bad, rs, 0));

        // override mismatch -> throws (schema says RHR, override says HDR)
        assertThrows(IllegalArgumentException.class, () -> Validator.validateHeaderLine(line, rs, 0, "HDR"));

        // override equals -> OK
        assertDoesNotThrow(() -> Validator.validateHeaderLine(line, rs, 0, "RHR"));
    }

    @Test
    void validateTrailerLine_success_and_bad_schema() {
        RecordSchema rs = headerSchema("RTR", 1, 3);
        String line = "RTR001FINANCIALDIRECT";

        // OK
        assertDoesNotThrow(() -> Validator.validateTrailerLine(line, rs, 0));

        // null schema/tagField -> throws
        RecordSchema bad = new RecordSchema();
        // missing tagField
        assertThrows(IllegalArgumentException.class, () -> Validator.validateTrailerLine(line, bad, 0));
        // null line -> throws
        assertThrows(IllegalArgumentException.class, () -> Validator.validateTrailerLine(null, rs, 0));
    }
}
