package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class ParseDispatcherFactoryTest {

    private static Path resourcePath(String res) throws Exception {
        URL url = ParseDispatcherFactoryTest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }

    @SuppressWarnings("unchecked")
    private static Map<String, ?> reflectStrategies(ParseDispatcher d) throws Exception {
        Field f = ParseDispatcher.class.getDeclaredField("strategies");
        f.setAccessible(true);
        return (Map<String, ?>) f.get(d);
    }

    @Test
    void registerAll_registers_every_id_and_parses_financialDirect() throws Exception {
        // Arrange
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);

        // Assert registration via reflection: all ids present
        Set<String> ids = registry.allIds();
        assertThat(ids).isNotEmpty();
        Map<String, ?> strategies = reflectStrategies(dispatcher);
        assertThat(strategies.keySet()).containsAll(ids);

        // And: can parse FINANCIALDIRECT without manual registration
        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        ParseDispatcher.Result result = dispatcher.dispatch(input, lines, "FINANCIALDIRECT");

        assertThat(result.txClass()).isEqualTo(TransactionGroup.class);
        OutboundFile<TransactionGroup> file = result.cast(TransactionGroup.class);

        assertThat(file.getHeader().get("recordType")).isEqualTo("RHR");
        assertThat(file.getHeader().get("fileTypeText")).isEqualTo("FINANCIALDIRECT");
        assertThat(file.getTrailer().get("recordType")).isEqualTo("RTR");
        assertThat(file.getItems()).hasSize(5);
    }

    @Test
    void registerAll_returns_dispatcher_ready_for_use() {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);
        assertDoesNotThrow(() -> reflectStrategies(dispatcher));
    }
}