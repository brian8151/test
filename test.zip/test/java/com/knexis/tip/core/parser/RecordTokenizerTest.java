package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.FieldDef;
import com.knexis.tip.core.schema.RecordSchema;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RecordTokenizerTest {

    @Test
    void slice_examples_and_edges() {
        String s = "ABCDEFG";

        // basic 1-based inclusive ranges
        assertThat(RecordTokenizer.slice(s, 1, 3)).isEqualTo("ABC");
        assertThat(RecordTokenizer.slice(s, 4, 6)).isEqualTo("DEF");

        // clip end beyond length
        assertThat(RecordTokenizer.slice(s, 7, 10)).isEqualTo("G");

        // start > end -> empty
        assertThat(RecordTokenizer.slice(s, 5, 4)).isEqualTo("");

        // null line -> empty
        assertThat(RecordTokenizer.slice(null, 1, 3)).isEqualTo("");

        // range entirely beyond line -> empty
        assertThat(RecordTokenizer.slice("ABC", 5, 7)).isEqualTo("");

        // start <= 0 clamps to 1
        assertThat(RecordTokenizer.slice("XYZ", 0, 1)).isEqualTo("X");

        // whitespace preserved
        assertThat(RecordTokenizer.slice(" A B ", 2, 4)).isEqualTo("A B");
    }

    @Test
    void fileTypeId_honors_trim_true() {
        // Header: RHR001 + "FINANCIALDIRECT  " (two trailing spaces considered part of the field)
        String header = "RHR001FINANCIALDIRECT  ";
        // Define schema: fileTypeText at cols 7..23 to capture the trailing spaces
        RecordSchema rs = new RecordSchema();
        List<FieldDef> fields = new ArrayList<>();

        FieldDef fileType = new FieldDef();
        fileType.setName("fileTypeText");
        fileType.setStart(7);
        fileType.setEnd(23);
        fileType.setTrim(true);
        fields.add(fileType);

        rs.setFields(fields);

        String id = RecordTokenizer.fileTypeId(header, rs);
        assertThat(id).isEqualTo("FINANCIALDIRECT");
    }

    @Test
    void fileTypeId_honors_trim_false() {
        String header = "RHR001FINANCIALDIRECT  ";
        RecordSchema rs = new RecordSchema();
        List<FieldDef> fields = new ArrayList<>();

        FieldDef fileType = new FieldDef();
        fileType.setName("fileTypeText");
        fileType.setStart(7);
        fileType.setEnd(23);
        fileType.setTrim(false);
        fields.add(fileType);
        rs.setFields(fields);

        String id = RecordTokenizer.fileTypeId(header, rs);
        assertThat(id).isEqualTo("FINANCIALDIRECT  "); // retains spaces
    }

    @Test
    void fileTypeId_throws_when_missing_field() {
        String header = "RHR001FINANCIALDIRECT";
        RecordSchema rs = new RecordSchema();
        rs.setFields(new ArrayList<>()); // no fileTypeText

        assertThrows(IllegalArgumentException.class, () -> RecordTokenizer.fileTypeId(header, rs));
    }

    @Test
    void fileTypeId_throws_on_nulls() {
        RecordSchema rs = new RecordSchema();
        rs.setFields(null); // simulate missing fields

        assertThrows(IllegalArgumentException.class, () -> RecordTokenizer.fileTypeId("RHR001...", rs));
        assertThrows(IllegalArgumentException.class, () -> RecordTokenizer.fileTypeId(null, new RecordSchema()));
    }
}
