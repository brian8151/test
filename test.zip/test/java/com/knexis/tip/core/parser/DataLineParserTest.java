package com.knexis.tip.core.parser;
import com.knexis.tip.core.exception.ValidationException;
import com.knexis.tip.core.schema.OutboundFileSchema;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.aggregation.GroupAggregator;
import com.knexis.tip.extensions.aggregation.GroupAggregatorFactory;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
/**
 * Proxy-free tests for DataLineParser using real schema + sample lines.
 */
class DataLineParserSuiteTest {

    private static Path resourcePath(String res) throws Exception {
        URL url = DataLineParserSuiteTest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }

    static class SimpleGroupAggregator implements GroupAggregator<Map<String,Object>> {
        final List<Map<String,Object>> details = new ArrayList<>();
        @Override public void onRecord(String recordId, Object parsedPojo) {
            Map<String,Object> one = new HashMap<>();
            one.put("recordId", recordId);
            details.add(one);
        }
        @Override public Map<String,Object> finish() {
            Map<String,Object> group = new HashMap<>();
            group.put("details", details);
            return group;
        }
    }
    static class SimpleFactory implements GroupAggregatorFactory<Map<String,Object>> {
        @Override public GroupAggregator<Map<String, Object>> create() { return new SimpleGroupAggregator(); }
    }

    @Test
    void parse_e2e_financialDirect() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        DataLineParser parser = new DataLineParser(schema);

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        OutboundFile<Map<String,Object>> file = parser.parse(lines, new SimpleFactory());

        assertThat(file.getHeader()).isNotNull();
        assertThat(file.getHeader().get("recordType")).isEqualTo("RHR");
        assertThat(file.getHeader().get("fileTypeText")).isEqualTo("FINANCIALDIRECT");

        assertThat(file.getTrailer()).isNotNull();
        assertThat(file.getTrailer().get("recordType")).isEqualTo("RTR");

        // 4 DFA001 groups present
        assertThat(file.getItems()).hasSize(5);
    }

    @Test
    void parse_skips_unknown_body_record() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        DataLineParser parser = new DataLineParser(schema);

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = new ArrayList<>(Files.readAllLines(input));
        lines.add(lines.size()-1, "ZZZ999SOMETHINGUNKNOWN........................................................................");

        OutboundFile<Map<String,Object>> file = parser.parse(lines, new SimpleFactory());
        assertThat(file.getItems()).hasSize(5);
    }

    @Test
    void parse_throws_on_missing_trailer() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        DataLineParser parser = new DataLineParser(schema);

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = new ArrayList<>(Files.readAllLines(input));
        lines.remove(lines.size()-1);

        assertThrows(ValidationException.class, () -> parser.parse(lines, new SimpleFactory()));
    }

    @Test
    void parse_throws_on_empty_file() {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        DataLineParser parser = new DataLineParser(schema);

        assertThrows(ValidationException.class, () -> parser.parse(Collections.emptyList(), new SimpleFactory()));
    }

    @Test
    void parse_lenient_length_accepts_lines_with_padding() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        DataLineParser parser = new DataLineParser(schema);

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = new ArrayList<>(Files.readAllLines(input));

        // make one DFA002 line shorter by trimming trailing spaces (if any)
        for (int i = 1; i < lines.size()-1; i++) {
            if (lines.get(i).startsWith("DFA002")) {
                lines.set(i, lines.get(i).stripTrailing());
                break;
            }
        }

        assertDoesNotThrow(() -> parser.parse(lines, new SimpleFactory()));
    }
}
