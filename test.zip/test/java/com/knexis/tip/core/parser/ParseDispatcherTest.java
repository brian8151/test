package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.core.schema.OutboundFileSchema;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionRecords;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.extensions.formats.OutboundTransaction;
import org.junit.jupiter.api.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ParseDispatcherRecordsTest {
    private static Path resourcePath(String res) throws Exception {
        URL url = ParseDispatcherRecordsTest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }

    // Cast-mismatch sentinel only
    static class DummyTx implements OutboundTransaction<OutboundDetail> {
        @Override public void add(OutboundDetail d) {}
        @Override public java.util.List<OutboundDetail> details() { return java.util.List.of(); }
    }

    @Test
    void dispatch_financialDirect_with_transactionRecords() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = new ParseDispatcher(registry);

        // Use DFA for FINANCIALDIRECT
        dispatcher.register("FINANCIALDIRECT",
                new ParseDispatcher.Strategy<>("DFA", TransactionRecords::new, TransactionRecords.class));

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        ParseDispatcher.Result result = dispatcher.dispatch(input, lines, "FINANCIALDIRECT");

        assertThat(result.fileTypeId()).isEqualTo("FINANCIALDIRECT");
        assertThat(result.txClass()).isEqualTo(TransactionRecords.class);

        OutboundFile<TransactionRecords> of = result.cast(TransactionRecords.class);
        assertThat(of.getHeader().get("recordType")).isEqualTo("RHR");
        assertThat(of.getHeader().get("fileTypeText")).isEqualTo("FINANCIALDIRECT");
        assertThat(of.getTrailer().get("recordType")).isEqualTo("RTR");

        // Expect 4 groups (each starting with DFA001)
        assertThat(of.getItems()).hasSize(5);
        of.getItems().forEach(tx -> assertThat(tx.details()).isNotEmpty());
    }

    @Test
    void missing_strategy_throws() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = new ParseDispatcher(registry);

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        assertThrows(RuntimeException.class, () -> dispatcher.dispatch(lines, "FINANCIALDIRECT"));
    }

    @Test
    void cast_mismatch_throws() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = new ParseDispatcher(registry);

        dispatcher.register("FINANCIALDIRECT",
                new ParseDispatcher.Strategy<>("DFA", TransactionRecords::new, TransactionRecords.class));

        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        ParseDispatcher.Result result = dispatcher.dispatch(input, lines, "FINANCIALDIRECT");

        // Wrong cast -> ClassCastException (proves Result.cast guard)
        assertThrows(ClassCastException.class, () -> result.cast(DummyTx.class));
    }
}