package com.knexis.tip;

import com.fasterxml.jackson.databind.JsonNode;
import com.knexis.tip.core.exception.ValidationException;
import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.parser.RecordTokenizer;
import com.knexis.tip.core.parser.Validator;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.share.FormatPostProcessor;
import com.knexis.tip.extensions.formats.share.PostProcessorRegistry;
import com.knexis.tip.extensions.formats.share.TransactionUnit;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.utils.TransactionPrinter;
import org.junit.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Java6Assertions.assertThatThrownBy;

/**
 * E2E tests for DistributionPostProcessor:
 * - Valid DIVIDEND header with multiple DVR runs
 * - Runs continue across TransactionGroup boundaries
 * - Non-DIVIDEND header ignored, next DIVIDEND header processed
 */
public class DistributionPostProcessorE2ETest {

    // ---- Suggested resource names ----
//    private static final String FILE_BASIC_RUNS     = "data/DA.basic-runs.TIP";
//    private static final String FILE_CROSS_GROUPS   = "data/DA.cross-groups.TIP";
//    private static final String FILE_NON_DIVIDEND   = "data/DA.non-dividend.TIP";
    private static final String FILE_BASIC_RUNS     = "data/MFB.MB701.TIP02";
    private static final String FILE_CROSS_GROUPS   = "data/MFB.MB701.TIP02";
    private static final String FILE_NON_DIVIDEND   = "data/MFB.MB701.TIP03";
    // If you want to temporarily point at your real file:
    // private static final String FILE_BASIC_RUNS = "data/MFB.MB701.TIP01";

    /** Resolve classpath resource to a Path. */
    private static Path resourcePath(String res) throws Exception {
        URL url = DistributionPostProcessorE2ETest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }

//    @Test
//    public void distribution_basicRuns_producesTwoUnits() throws Exception {
//        OutboundFile<TransactionGroup> file = parseResource(FILE_BASIC_RUNS);
//
//        // Sanity on parsed file
//        assertHeaderTrailerOk(file);
//        assertThat(file.getItems()).isNotEmpty();
//
//        // Post-process
//        var units = runPostProcessor(file);
//
//        // Expect two runs (e.g., [DVH, 1,2,5] and [DVH, 1,3])
//        assertThat(units).hasSize(2);
//        // Each unit has one member (mini-group)
//        for (TransactionUnit<TransactionGroup> u : units) {
//            assertThat(u.members()).hasSize(1);
//            assertThat(u.members().get(0).details()).isNotEmpty();
//            assertThat(u.reason()).contains("header + run"); // from processor reason string
//        }
//
//        TransactionPrinter.printUnits(units);
//    }
//
//    @Test
//    public void distribution_runsAcrossGroups_producesTwoUnits() throws Exception {
//        OutboundFile<TransactionGroup> file = parseResource(FILE_CROSS_GROUPS);
//
//        assertHeaderTrailerOk(file);
//
//        var units = runPostProcessor(file);
//
//        // First run spans across groups; second run starts at next DVR001
//        assertThat(units).hasSize(2);
//        TransactionPrinter.printUnits(units);
//    }

    @Test
    public void distribution_dividend_happyPath_toJson() throws Exception {
        OutboundFile<TransactionGroup> file = parseResource(FILE_BASIC_RUNS);
        assertHeaderTrailerOk(file);

        // Post-process into units (each unit is a single DVH… mini-group)
        String fileTypeId = (String) file.getHeader().getOrDefault("fileTypeText", "DISTRIBUTIONACTIVITY");
        FormatPostProcessor pp = PostProcessorRegistry.resolve(fileTypeId);
        List<TransactionUnit<TransactionGroup>> units = pp.process(fileTypeId, file);

        assertThat(units).isNotEmpty();
        for (var u : units) {
            assertThat(u.members()).hasSize(1);
            assertThat(u.members().get(0).details()).isNotEmpty();
        }

        // Convert units -> JSON DTOs and print
        List<JsonNode> json = pp.convert(units);
        System.out.println("----- JSON OUTPUT (Distribution) ----------");
        TransactionPrinter.printJson(json); // pretty prints each node
        TransactionPrinter.printJson(json); // prints unique accounts/ISINs

        // Basic JSON invariants for each produced TradeDTO
        for (JsonNode n : json) {
            assertThat(n.path("transactionType").asText()).isEqualTo("DIVIDEND");
            assertThat(n.path("settlementCurrency").asText()).isEqualTo("USD");

            // presence of all expected fields
            assertThat(n.hasNonNull("dealId")).isTrue();
            assertThat(n.hasNonNull("accountId")).isTrue();
            assertThat(n.hasNonNull("isin")).isTrue();
            assertThat(n.hasNonNull("tradeDate")).isTrue();
            assertThat(n.hasNonNull("settlementDate")).isTrue();
            assertThat(n.hasNonNull("shares")).isTrue();

            // tradeDate == settlementDate (both come from distributionReinvestDate)
            assertThat(n.path("tradeDate").asText())
                    .isEqualTo(n.path("settlementDate").asText());

            // shares is serialized as a string (ToStringSerializer)
            assertThat(n.path("shares").isTextual()).isTrue();
        }
    }

    @Test
    public void distribution_nonDividendHeader_throws() throws Exception {
        OutboundFile<TransactionGroup> file = parseResource(FILE_NON_DIVIDEND);
        assertHeaderTrailerOk(file);

        String fileTypeId = (String) file.getHeader().getOrDefault("fileTypeText", "DISTRIBUTIONACTIVITY");
        FormatPostProcessor pp = PostProcessorRegistry.resolve(fileTypeId);
        List<TransactionUnit<TransactionGroup>> units = pp.process(fileTypeId, file);

        // Convert should FAIL because DistributionTransferMapper now enforces type == "0"
        assertThatThrownBy(() -> pp.convert(units))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("distributionTypeCode")
                .hasMessageContaining("only '0' DIVIDEND is supported");
    }

    // -------------------- helpers --------------------

    private static OutboundFile<TransactionGroup> parseResource(String resource) throws Exception {
        Path input = resourcePath(resource);
        List<String> lines = Files.readAllLines(input);

        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        String anyId = registry.allIds().iterator().next();
        var common = registry.getById(anyId);

        // Validate header/trailer
        var headerSchema  = common.getHeader();
        var trailerSchema = common.getTrailer();
        int recordLen     = common.getRecordLength() != null ? common.getRecordLength() : 0;
        String headerLine = lines.get(0);
        Validator.validateHeaderLine(headerLine, headerSchema, recordLen);
        Validator.validateTrailerLine(lines.get(lines.size() - 1), trailerSchema, recordLen);

        String fileTypeId = RecordTokenizer.fileTypeId(headerLine, headerSchema);

        // Dispatch & parse
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);
        ParseDispatcher.Result result = dispatcher.dispatch(input, lines, fileTypeId);

        // Cast to agreed container
        return result.cast(TransactionGroup.class);
    }

    private static void assertHeaderTrailerOk(OutboundFile<TransactionGroup> file) {
        assertThat(file.getHeader()).isNotNull();
        assertThat(file.getHeader()).containsKeys("recordType", "fileTypeText");
        assertThat(file.getHeader().get("recordType")).isEqualTo("RHR");

        assertThat(file.getTrailer()).isNotNull();
        assertThat(file.getTrailer()).containsKeys("recordType", "fileTypeText");
        assertThat(file.getTrailer().get("recordType")).isEqualTo("RTR");
    }

}