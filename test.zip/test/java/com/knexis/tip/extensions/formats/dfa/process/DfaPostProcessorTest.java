package com.knexis.tip.extensions.formats.dfa.process;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord10;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
/**
 * Unit tests for DFA post-processor pairing/classification.
 */
class DfaPostProcessorTest {

    private static TransactionGroup tx(String effect, Long id1, Long id2) {
        TransactionGroup g = new TransactionGroup();

        DfaRecord1 r1 = new DfaRecord1();
        r1.setShareBalanceEffect(effect); // 'A'|'S'|'N'

        DfaRecord10 r10 = new DfaRecord10();
        r10.setEventId1(id1);
        r10.setEventId2(id2);

        g.add(r1);
        g.add(r10);
        return g;
    }

    private static <T> OutboundFile<T> fileOf(List<T> items) {
        Map<String,Object> header = new HashMap<>();
        header.put("recordType", "RHR");
        header.put("fileTypeText", "FINANCIALDIRECT");
        Map<String,Object> trailer = new HashMap<>();
        trailer.put("recordType", "RTR");
        return new OutboundFile<>(header, items, trailer);
    }

    @Test
    void pairs_ADD_and_SUB_by_same_eventKey() {
        var pp = new DfaPostProcessor();
        var items = new ArrayList<TransactionGroup>();
        items.add(tx("A", 1L, 2L)); // Effect.ADD
        items.add(tx("S", 1L, 2L)); // Effect.SUB

        var units = pp.process("FINANCIALDIRECT", fileOf(items));

        assertThat(units).hasSize(1);
        assertThat(units.get(0).members()).hasSize(2);
    }

    @Test
    void fallback_pairs_first_two_when_both_ADD() {
        var pp = new DfaPostProcessor();
        var items = new ArrayList<TransactionGroup>();
        items.add(tx("A", 10L, 20L));
        items.add(tx("A", 10L, 20L));

        var units = pp.process("FINANCIALDIRECT", fileOf(items));

        assertThat(units).hasSize(1);
        assertThat(units.get(0).members()).hasSize(2);
    }

    @Test
    void classifies_remaining_singletons_by_effect() {
        var pp = new DfaPostProcessor();
        var items = new ArrayList<TransactionGroup>();
        // No event keys => will not pair; should classify individually
        items.add(tx("A", null, null)); // SUBSCRIPTION
        items.add(tx("S", null, null)); // REDEMPTION
        items.add(tx("N", null, null)); // UNKNOWN/NONE

        var units = pp.process("FINANCIALDIRECT", fileOf(items));

        // 3 single-item units expected
        assertThat(units).hasSize(3);
        units.forEach(u -> assertThat(u.members()).hasSize(1));
    }

    @Test
    void passes_through_for_non_financialdirect_type() {
        var pp = new DfaPostProcessor();
        var items = new ArrayList<TransactionGroup>();
        items.add(tx("A", 1L, 1L));
        items.add(tx("S", 1L, 1L));

        var units = pp.process("OTHER_TYPE", fileOf(items));

        // Each transaction becomes its own unit (unknown kind)
        assertThat(units).hasSize(2);
        units.forEach(u -> assertThat(u.members()).hasSize(1));
    }
}