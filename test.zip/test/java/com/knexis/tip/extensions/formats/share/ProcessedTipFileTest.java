package com.knexis.tip.extensions.formats.share;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ProcessedTipFileTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void testRecordAccessorsAndImmutability() {
        final String fileId = "FINANCIALDIRECT";

        // Create mock JsonNode objects
        JsonNode tx1 = mapper.createObjectNode().put("id", 1).put("type", "SUB");
        JsonNode tx2 = mapper.createObjectNode().put("id", 2).put("type", "RED");

        List<JsonNode> transactions = List.of(tx1, tx2);

        // Instantiate the record
        ProcessedTipFile tipFile = new ProcessedTipFile(fileId, transactions);

        // 1. Test accessors
        assertEquals(fileId, tipFile.fileTypeId(), "fileTypeId accessor should return the correct value.");
        assertEquals(2, tipFile.transactions().size(), "transactions list size should be 2.");
        assertSame(tx1, tipFile.transactions().get(0), "First transaction node should match the input.");

        // 2. Test implicit immutability of the transactions list
        List<JsonNode> retrievedList = tipFile.transactions();
        assertThrows(UnsupportedOperationException.class, () -> {
            retrievedList.add(mapper.createObjectNode().put("id", 3));
        }, "The list returned by transactions() should be unmodifiable.");
    }

    @Test
    void testSerializationAndDeserialization() throws Exception {
        final String fileId = "DISTRIBUTION";
        ArrayNode transactionsArray = mapper.createArrayNode();
        transactionsArray.add(mapper.createObjectNode().put("status", "OK"));

        ProcessedTipFile originalFile = new ProcessedTipFile(fileId, List.of(transactionsArray));

        // 1. Serialization (verify structure)
        String json = mapper.writeValueAsString(originalFile);
        assertTrue(json.contains("\"fileTypeId\":\"DISTRIBUTION\""), "JSON should contain the fileTypeId.");
        assertTrue(json.contains("\"transactions\":[[{\"status\":\"OK\"}]]"), "JSON should contain the nested transactions structure.");

        // 2. Deserialization (verify data integrity)
        ProcessedTipFile deserializedFile = mapper.readValue(json, ProcessedTipFile.class);

        assertEquals(fileId, deserializedFile.fileTypeId(), "Deserialized fileTypeId must match original.");
        assertEquals(1, deserializedFile.transactions().size(), "Deserialized list size must be 1.");
    }
}