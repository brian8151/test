package com.knexis.tip.extensions.formats.share;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TxnKindTest {

    private static final String NS = "DFA";
    private static final String CODE = "SUBSCRIPTION";
    private static final TxnKind SAMPLE_KIND = TxnKind.of(NS, CODE);

    @Test
    void testFactoryMethodNormalizesToUpperCase() {
        TxnKind kind = TxnKind.of("dfa", "subscription");
        assertEquals(NS.toUpperCase(), kind.namespace(), "Namespace must be upper case.");
        assertEquals(CODE.toUpperCase(), kind.code(), "Code must be upper case.");
    }

    @Test
    void testFactoryMethodRejectsNull() {
        assertThrows(NullPointerException.class, () -> TxnKind.of(null, "CODE"), "Must reject null namespace.");
        assertThrows(NullPointerException.class, () -> TxnKind.of("NS", null), "Must reject null code.");
    }

    @Test
    void testAccessors() {
        assertEquals(NS, SAMPLE_KIND.namespace(), "Namespace accessor failed.");
        assertEquals(CODE, SAMPLE_KIND.code(), "Code accessor failed.");
    }

    @Test
    void testIsChecks() {
        // is(ns, code)
        assertTrue(SAMPLE_KIND.is("DFA", "SUBSCRIPTION"), "is() check must pass with correct case.");
        assertTrue(SAMPLE_KIND.is("dfa", "subscription"), "is() check must pass with mixed case.");
        assertFalse(SAMPLE_KIND.is("DFA", "REDEMPTION"), "is() check must fail on wrong code.");
        assertFalse(SAMPLE_KIND.is("OFX", "SUBSCRIPTION"), "is() check must fail on wrong namespace.");

        // isNamespace(ns)
        assertTrue(SAMPLE_KIND.isNamespace("dfa"), "isNamespace() must pass with mixed case.");
        assertFalse(SAMPLE_KIND.isNamespace("ofx"), "isNamespace() must fail on wrong namespace.");

        // isCode(code)
        assertTrue(SAMPLE_KIND.isCode("subscription"), "isCode() must pass with mixed case.");
        assertFalse(SAMPLE_KIND.isCode("redemption"), "isCode() must fail on wrong code.");
    }

    @Test
    void testToStringOutput() {
        assertEquals("DFA:SUBSCRIPTION", SAMPLE_KIND.toString(), "toString() output must be 'NAMESPACE:CODE'.");
        assertEquals("GENERIC:UNKNOWN", TxnKind.UNKNOWN.toString(), "UNKNOWN constant toString() must be correct.");
    }

    @Test
    void testEqualsAndHashCode() {
        TxnKind same = TxnKind.of("DFA", "SUBSCRIPTION");
        TxnKind differentCode = TxnKind.of("DFA", "REDEMPTION");
        TxnKind differentNs = TxnKind.of("OFX", "SUBSCRIPTION");

        // Equals
        assertEquals(SAMPLE_KIND, same, "Equal objects must be equal.");
        assertNotEquals(SAMPLE_KIND, differentCode, "Objects with different codes must not be equal.");
        assertNotEquals(SAMPLE_KIND, differentNs, "Objects with different namespaces must not be equal.");

        // HashCode
        assertEquals(SAMPLE_KIND.hashCode(), same.hashCode(), "Equal objects must have equal hash codes.");
        assertNotEquals(SAMPLE_KIND.hashCode(), differentCode.hashCode(), "Different hash codes expected.");
    }

    @Test
    void testUnknownConstant() {
        assertEquals("GENERIC", TxnKind.UNKNOWN.namespace(), "UNKNOWN namespace must be GENERIC.");
        assertEquals("UNKNOWN", TxnKind.UNKNOWN.code(), "UNKNOWN code must be UNKNOWN.");
    }
}
