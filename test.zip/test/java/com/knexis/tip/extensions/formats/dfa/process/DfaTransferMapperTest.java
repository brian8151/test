package com.knexis.tip.extensions.formats.dfa.process;

import com.fasterxml.jackson.databind.JsonNode;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor.DfaKinds;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord10;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord3;
import com.knexis.tip.extensions.formats.dfa.records.TransferTradeDTO;
import com.knexis.tip.extensions.formats.share.TradeDTO;
import com.knexis.tip.extensions.formats.share.TransactionUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
public class DfaTransferMapperTest {

    private DfaTransferMapper mapper;
    private final LocalDate TRADE_DATE = LocalDate.of(2025, 10, 5);
    private final LocalDate SETTLE_DATE = LocalDate.of(2025, 10, 7);
    private final BigDecimal SHARES = new BigDecimal("100.0000");
    private final String CUSIP = "CUSIP12345";
    private final String ACCOUNT_SUB = "ACC_SUB";
    private final String ACCOUNT_ADD = "ACC_ADD";

    @BeforeEach
    void setUp() {
        mapper = new DfaTransferMapper();
    }

    // --- Helper for creating single-leg groups ---
    private TransactionGroup singleGroup(String account, String effect, DfaRecord3 r3, DfaRecord10 r10) {
        TransactionGroup g = new TransactionGroup();
        DfaRecord1 dfaRecord1 = new DfaRecord1();
        dfaRecord1.setAccountNumber(account);
        dfaRecord1.setCusip(CUSIP);
        dfaRecord1.setTradeDate(TRADE_DATE);
        dfaRecord1.setBatchDate(SETTLE_DATE);
        dfaRecord1.setSharesTxnCount(SHARES);
        dfaRecord1.setShareBalanceEffect(effect);
        g.add(dfaRecord1);
        if (r3 != null) g.add(r3);
        if (r10 != null) g.add(r10);
        return g;
    }

    // --- Helper for creating paired-leg groups (Transfer) ---
    private TransactionUnit<TransactionGroup> pairedUnit(DfaRecord3 r3, DfaRecord10 r10) {
        TransactionGroup subGroup = new TransactionGroup();
        DfaRecord1 dfaRecord1 = new DfaRecord1();
        dfaRecord1.setAccountNumber(ACCOUNT_SUB);
        dfaRecord1.setCusip("CUSIP_SUB");
        dfaRecord1.setShareBalanceEffect("SUB");
        dfaRecord1.setTradeDate(TRADE_DATE.minusDays(1));
        dfaRecord1.setBatchDate(SETTLE_DATE.minusDays(1));
        dfaRecord1.setSharesTxnCount(SHARES.add(BigDecimal.ONE));
        subGroup.add(dfaRecord1);
        if (r3 != null) subGroup.add(r3);
        if (r10 != null) subGroup.add(r10);

        TransactionGroup addGroup = new TransactionGroup();
        DfaRecord1 dfaRecord01 = new DfaRecord1();
        dfaRecord01.setAccountNumber(ACCOUNT_ADD);
        dfaRecord01.setCusip(CUSIP);
        dfaRecord1.setShareBalanceEffect("ADD");
        dfaRecord01.setTradeDate(TRADE_DATE);
        dfaRecord01.setBatchDate(SETTLE_DATE);
        dfaRecord01.setSharesTxnCount(SHARES);
        addGroup.add(dfaRecord01);
        if (r3 != null) addGroup.add(r3);
        if (r10 != null) addGroup.add(r10);

        return new TransactionUnit<>(DfaKinds.TRANSFER, List.of(subGroup, addGroup), "Paired");
    }

    // --- NON-TRANSFER (TradeDTO) TESTS ---

    @Test
    void testSubscriptionMapsToTradeDTO() throws Exception {
        TransactionGroup group = singleGroup(ACCOUNT_ADD, "ADD", null, null);
        TransactionUnit<TransactionGroup> unit = new TransactionUnit<>(DfaKinds.SUBSCRIPTION, List.of(group), "Sub");
        JsonNode json = mapper.toJson(unit);
        // Map JsonNode to DTO for easy property verification
        TradeDTO dto = mapper.getObjectMapper().treeToValue(json, TradeDTO.class);

        assertEquals("SUBSCRIPTION", dto.transactionType(), "Should map to TradeDTO and inherit kind code.");
        assertEquals(ACCOUNT_ADD, dto.accountId(), "Non-transfer accountId must be the only account.");
        assertEquals(CUSIP, dto.isin());
        assertEquals(TRADE_DATE, dto.tradeDate());
        assertEquals(SHARES, dto.shares());
        assertEquals("", dto.dealId(), "DealId should be empty if no R3/R10 present.");
    }

    @Test
    void testRedemptionMapsToTradeDTOAndFindsR3DealId() throws Exception {
        DfaRecord3 r3 = new DfaRecord3();
        r3.setMfTxnId1(100L);
        r3.setMfTxnId2(200L);
        TransactionGroup group = singleGroup(ACCOUNT_SUB, "SUB", r3, null);
        TransactionUnit<TransactionGroup> unit = new TransactionUnit<>(DfaKinds.REDEMPTION, List.of(group), "Red");

        JsonNode json = mapper.toJson(unit);
        TradeDTO dto = mapper.getObjectMapper().treeToValue(json, TradeDTO.class);

        assertEquals(ACCOUNT_SUB, dto.accountId());
        assertEquals("100-200", dto.dealId(), "DealId should come from DFA-003.");
    }

    // --- TRANSFER (TransferTradeDTO) TESTS ---

    @Test
    void testTransferMapsToTransferTradeDTO() throws Exception {
        TransactionUnit<TransactionGroup> unit = pairedUnit(null, null);

        JsonNode json = mapper.toJson(unit);

        // Map JsonNode to DTO for easy property verification
        TransferTradeDTO dto = mapper.getObjectMapper().treeToValue(json, TransferTradeDTO.class);

        assertEquals("TRANSFER", dto.transactionType());
        assertEquals(ACCOUNT_SUB, dto.toAccountId(), "To account must be SUB leg.");

        // Anchor check: Anchor should be the ADD leg's record
        assertEquals("CUSIP_SUB", dto.isin(), "ISIN must come from the ADD leg anchor record.");
        assertEquals(TRADE_DATE.minusDays(1), dto.tradeDate(), "TradeDate must come from the ADD leg anchor record.");
        assertEquals(SHARES.add(BigDecimal.ONE), dto.shares());
    }

    @Test
    void testTransferFindsR10DealIdAndAnchor() throws Exception {
        DfaRecord10 r10 = new DfaRecord10();
        r10.setEventId1(555L);
        r10.setEventId2(666L);
        TransactionUnit<TransactionGroup> unit = pairedUnit(null, r10);

        JsonNode json = mapper.toJson(unit);
        TransferTradeDTO dto = mapper.getObjectMapper().treeToValue(json, TransferTradeDTO.class);
        assertEquals("555-666-555-666", dto.dealId(), "DealId must come from DFA-010.");

    }
}