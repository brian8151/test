package com.knexis.tip.extensions.formats;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.RecordHeader;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class TransactionGroupTest {

    private TransactionGroup transactionGroup;
    private DfaRecord1 rec1a;
    private DfaRecord2 rec2;
    private DfaRecord1 rec1b;

    @BeforeEach
    void setUp() {
        transactionGroup = new TransactionGroup();
        rec1a = new DfaRecord1();
        rec2 = new DfaRecord2();
        rec1b = new DfaRecord1();

        // Add records in mixed order
        transactionGroup.add(rec1a);
        transactionGroup.add(rec2);
        transactionGroup.add(rec1b);
    }

    @Test
    void testAddAndDetailsSize() {
        assertEquals(3, transactionGroup.details().size(), "Details size should reflect all added records.");
    }

    @Test
    void testDetailsIsUnmodifiable() {
        List<OutboundDetail> details = transactionGroup.details();

        // Assert that the list reference is unmodifiable
        assertThrows(UnsupportedOperationException.class, () -> {
            details.add(new DfaRecord1());
        }, "The details() list must be unmodifiable.");

        // Assert that the list contents are correct
        assertSame(rec1a, details.get(0), "First element must be rec1a.");
    }

    @Test
    void testFirstOfFindsCorrectTypeAndOrder() {
        // Test finding the first DfaRecord1
        DfaRecord1 found1 = transactionGroup.firstOf(DfaRecord1.class);
        assertSame(rec1a, found1, "firstOf(DfaRecord1.class) should return the first instance added (rec1a).");

        // Test finding the first DfaRecord2
        DfaRecord2 found2 = transactionGroup.firstOf(DfaRecord2.class);
        assertSame(rec2, found2, "firstOf(DfaRecord2.class) should return the only instance (rec2).");
    }

    @Test
    void testFirstOfReturnsNullForAbsentType() {
        // Create an absent record type for testing
        class AbsentRecord extends RecordHeader {}

        AbsentRecord absent = transactionGroup.firstOf(AbsentRecord.class);
        assertNull(absent, "firstOf() should return null for a type not present in the list.");
    }

    @Test
    void testOfTypeFiltersCorrectly() {
        // Test filtering for DfaRecord1
        List<DfaRecord1> dfa1Records = transactionGroup.ofType(DfaRecord1.class);
        assertEquals(2, dfa1Records.size(), "ofType(DfaRecord1.class) should return 2 records.");
        assertSame(rec1a, dfa1Records.get(0), "First DfaRecord1 should be rec1a.");
        assertSame(rec1b, dfa1Records.get(1), "Second DfaRecord1 should be rec1b.");

        // Test filtering for DfaRecord2
        List<DfaRecord2> dfa2Records = transactionGroup.ofType(DfaRecord2.class);
        assertEquals(1, dfa2Records.size(), "ofType(DfaRecord2.class) should return 1 record.");
        assertSame(rec2, dfa2Records.get(0), "The single DfaRecord2 should be rec2.");
    }

    @Test
    void testDeprecatedMethodsMatchNewMethods() {
        // getRecordsOfType() should return the same list as ofType()
        List<DfaRecord1> expectedList = transactionGroup.ofType(DfaRecord1.class);
        List<DfaRecord1> deprecatedList = transactionGroup.getRecordsOfType(DfaRecord1.class);
        assertEquals(expectedList.size(), deprecatedList.size());
        assertEquals(expectedList.get(0), deprecatedList.get(0), "getRecordsOfType() should be equivalent to ofType().");
    }
}
