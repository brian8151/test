package com.knexis.tip.extensions.formats.dfa.records;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class DfaRecord4Test {

    private DfaRecord4 record;

    @BeforeEach
    void setUp() {
        record = new DfaRecord4();
        // Set inherited fields for better toString context
        record.setRecordType("DFA");
        record.setSeq(4);
    }

    @Test
    void testInheritedFields() {
        assertEquals("DFA", record.getRecordType());
        assertEquals(4, record.getSeq());
    }

    @Test
    void testAllFieldsSetAndGet() {
        BigDecimal commission = new BigDecimal("123.45");

        // Set all fields
        record.setClientReferenceNumber(1234567890123L);
        record.setMerchantDescription("TEST MERCHANT DESCRIPTION FOR TRADE");
        record.setCustodianId(9000001);
        record.setTpaId(8000001);
        record.setAdvCommissionAmount(commission);
        record.setNsccBranchId("BRANCH999");
        record.setNavReasonCode(1);
        record.setClientDefinedText("USERTEXT");
        record.setAlphaMasked("ALPHA12345");
        record.setFromToCustomerAcct("FROMACCTTOACCT");
        record.setFromToCusip("TOCUSIP");
        record.setOperatorId("OPR123");
        record.setNsccIraCode("R");
        record.setFiller("XYZ");

        // Assert all fields
        assertEquals(1234567890123L, record.getClientReferenceNumber());
        assertEquals("TEST MERCHANT DESCRIPTION FOR TRADE", record.getMerchantDescription());
        assertEquals(9000001, record.getCustodianId());
        assertEquals(8000001, record.getTpaId());
        assertEquals(commission, record.getAdvCommissionAmount());
        assertEquals("BRANCH999", record.getNsccBranchId());
        assertEquals(1, record.getNavReasonCode());
        assertEquals("USERTEXT", record.getClientDefinedText());
        assertEquals("ALPHA12345", record.getAlphaMasked());
        assertEquals("FROMACCTTOACCT", record.getFromToCustomerAcct());
        assertEquals("TOCUSIP", record.getFromToCusip());
        assertEquals("OPR123", record.getOperatorId());
        assertEquals("R", record.getNsccIraCode());
        assertEquals("XYZ", record.getFiller());
    }

    @Test
    void testToStringContainsKeyFields() {
        // Set key fields
        record.setAdvCommissionAmount(new BigDecimal("10.50"));
        record.setNsccBranchId("TESTBRANCH");

        String output = record.toString();

        // Assert key fields are present
        assertTrue(output.contains("advCommissionAmount=10.50"));
        assertTrue(output.contains("nsccBranchId=TESTBRANCH"));

    }
}