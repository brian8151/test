package com.knexis.tip.extensions.formats.dfa.records;
import java.time.LocalDate;
import java.math.BigDecimal;
import java.util.Objects;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class DfaRecord1Test {

    private DfaRecord1 record;

    @BeforeEach
    void setUp() {
        record = new DfaRecord1();
    }

    @Test
    void testInheritedFields() {
        record.setRecordType("DFA");
        record.setSeq(1);
        record.setRecordId("DFA-001");

        assertEquals("DFA", record.getRecordType());
        assertEquals(1, record.getSeq());
        assertEquals("DFA-001", record.getRecordId());
    }

    @Test
    void testAllFieldsSetAndGet() {
        // Sample values for all field types
        LocalDate tradeDate = LocalDate.of(2025, 8, 15);
        BigDecimal amount = new BigDecimal("12345.67");

        // Set all fields
        record.setRecordCode(57);
        record.setParticipantNumber(9350000);
        record.setDealerBranchId("TEST");
        record.setCusip("2737000");
        record.setFundCode(33311);
        record.setAccountNumber("F7004710");
        record.setAccountNumberCode("A");
        record.setBatchNumber(1001);
        record.setBatchDate(LocalDate.of(2025, 8, 11));
        record.setTxnCode(10);
        record.setTxnSuffix(21);
        record.setShareBalanceEffect("A");
        record.setSharePriceAmount(new BigDecimal("100.0000"));
        record.setGrossTxnAmount(new BigDecimal("1000000.00"));
        record.setSharesTxnCount(new BigDecimal("10000.0000"));
        record.setTradeDate(tradeDate);
        record.setConfOrPayDate(tradeDate);
        record.setDiscountCategory(10);
        record.setOrderNumber(100000000L);
        record.setAccountType("0");
        record.setDealerLevelControl("1");
        record.setPaymentMethod("Z");
        record.setPrePostNoonFlag("1");
        record.setShortTermWaiverReason("Z");
        record.setTotalRecordCountForType(102);

        // Assert all fields
        assertEquals(57, record.getRecordCode());
        assertEquals(9350000, record.getParticipantNumber());
        assertEquals("TEST", record.getDealerBranchId());
        assertEquals("2737000", record.getCusip());
        assertEquals(33311, record.getFundCode());
        assertEquals("F7004710", record.getAccountNumber());
        assertEquals("A", record.getAccountNumberCode());
        assertEquals(1001, record.getBatchNumber());
        assertEquals(LocalDate.of(2025, 8, 11), record.getBatchDate());
        assertEquals(10, record.getTxnCode());
        assertEquals(21, record.getTxnSuffix());
        assertEquals("A", record.getShareBalanceEffect());
        assertEquals(new BigDecimal("100.0000"), record.getSharePriceAmount());
        assertEquals(new BigDecimal("1000000.00"), record.getGrossTxnAmount());
        assertEquals(new BigDecimal("10000.0000"), record.getSharesTxnCount());
        assertEquals(tradeDate, record.getTradeDate());
        assertEquals(tradeDate, record.getConfOrPayDate());
        assertEquals(10, record.getDiscountCategory());
        assertEquals(100000000L, record.getOrderNumber());
        assertEquals("0", record.getAccountType());
        assertEquals("1", record.getDealerLevelControl());
        assertEquals("Z", record.getPaymentMethod());
        assertEquals("1", record.getPrePostNoonFlag());
        assertEquals("Z", record.getShortTermWaiverReason());
        assertEquals(102, record.getTotalRecordCountForType());
    }

    @Test
    void testToStringContainsKeyFields() {
        // Set a few key fields to ensure they appear in the toString output
        record.setDealerBranchId("BRCH123");
        record.setSharesTxnCount(new BigDecimal("5.5"));
        record.setTradeDate(LocalDate.of(2024, 1, 1));

        String output = record.toString();

        // Assert key fields are present
        assertTrue(output.contains("sharesTxnCount=5.5"));
        assertTrue(output.contains("tradeDate=2024-01-01"));

    }
}
