package com.knexis.tip.extensions.formats;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.RecordHeader;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class TransactionRecordsTest {

    private TransactionRecords txRecords;
    private DfaRecord1 rec1a;
    private DfaRecord2 rec2;
    private DfaRecord1 rec1b;

    @BeforeEach
    void setUp() {
        txRecords = new TransactionRecords();
        rec1a = new DfaRecord1();
        rec2 = new DfaRecord2();
        rec1b = new DfaRecord1();

        // Add records in mixed order
        txRecords.add(rec1a);
        txRecords.add(rec2);
        txRecords.add(rec1b);
    }

    @Test
    void testAddAndDetailsSize() {
        assertEquals(3, txRecords.details().size(), "Details size should reflect all added records.");
    }

    @Test
    void testDetailsIsUnmodifiable() {
        List<OutboundDetail> details = txRecords.details();

        // Assert that the list reference is unmodifiable
        assertThrows(UnsupportedOperationException.class, () -> {
            details.add(new DfaRecord1());
        }, "The details() list must be unmodifiable.");

        // Assert that the list contents are correct
        assertSame(rec1a, details.get(0), "First element must be rec1a.");
    }

    @Test
    void testFirstOfFindsCorrectTypeAndOrder() {
        // Test finding the first DfaRecord1
        DfaRecord1 found1 = txRecords.firstOf(DfaRecord1.class);
        assertSame(rec1a, found1, "firstOf(DfaRecord1.class) should return the first instance added (rec1a), skipping rec2.");

        // Test finding the first DfaRecord2
        DfaRecord2 found2 = txRecords.firstOf(DfaRecord2.class);
        assertSame(rec2, found2, "firstOf(DfaRecord2.class) should return the only instance (rec2).");
    }

    @Test
    void testFirstOfReturnsNullForAbsentType() {
        // Create an absent record type for testing
        class AbsentRecord extends RecordHeader {}

        AbsentRecord absent = txRecords.firstOf(AbsentRecord.class);
        assertNull(absent, "firstOf() should return null for a type not present in the list.");
    }
}