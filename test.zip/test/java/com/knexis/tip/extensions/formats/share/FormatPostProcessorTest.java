package com.knexis.tip.extensions.formats.share;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;


public class FormatPostProcessorTest {

    private final String FILE_ID = "TEST_FILE";
    private OutboundFile<TransactionGroup> outboundFile;
    private final TransactionGroup group1 = new TransactionGroup();
    private final TransactionGroup group2 = new TransactionGroup();

    @BeforeEach
    void setUp() {
        outboundFile = new OutboundFile<>(
                Map.of("header", "data"),
                Arrays.asList(group1, group2),
                Map.of("trailer", "data")
        );
    }

    // --- FormatPostProcessor INTERFACE DEFAULT METHOD TESTS ---

    /** Tests the default implementation of the process method (the no-op fallback). */
    @Test
    void testDefaultProcessMethod() {
        FormatPostProcessor processor = new DfaPostProcessor(); // Use concrete impl to access default method

        List<TransactionUnit<TransactionGroup>> units = processor.process(FILE_ID, outboundFile);

        // 1. Verify number of units matches number of items
        assertEquals(2, units.size(), "Default processor must produce one unit per item.");

        // 2. Verify unit content (TxnKind, Member, Reason)
        TransactionUnit<TransactionGroup> unit1 = units.get(0);
        assertSame(TxnKind.UNKNOWN, unit1.kind(), "Unit kind must be UNKNOWN.");
        assertEquals(1, unit1.members().size(), "Unit must wrap one TransactionGroup.");
        assertSame(group1, unit1.members().get(0), "Unit must wrap the correct group.");
    }

    // --- BasePostProcessor ABSTRACT CLASS METHOD TESTS ---

    /** Tests the implementation of the abstract convert method in BasePostProcessor. */
    @Test
    void testBasePostProcessorConvertLogic() {
        // ConcretePostProcessor extends BasePostProcessor
        BasePostProcessor processor = new DfaPostProcessor();

        // Setup two mock units
        List<TransactionUnit<TransactionGroup>> units = new ArrayList<>();
        units.add(new TransactionUnit<>(TxnKind.of("DFA", "SUB"), List.of(group1), "Reason 1"));
        units.add(new TransactionUnit<>(TxnKind.of("DFA", "RED"), List.of(group2), "Reason 2"));

        // When: convert is called
        List<JsonNode> jsonList = processor.convert(units);

        // Then:
        assertEquals(2, jsonList.size(), "Convert must return two JsonNode elements.");

        // Verify the first node
        JsonNode node1 = jsonList.get(0);
        assertTrue(node1.has("accountId"));
        assertEquals("SUB", node1.get("transactionType").asText());
        assertEquals("USD", node1.get("settlementCurrency").asText(), "The group ID must be correctly mapped.");

        // Verify the second node
        JsonNode node2 = jsonList.get(1);
        assertEquals("RED", node2.get("transactionType").asText());
        assertEquals("USD", node2.get("settlementCurrency").asText());
    }
}