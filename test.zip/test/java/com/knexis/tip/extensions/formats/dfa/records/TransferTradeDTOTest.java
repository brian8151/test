package com.knexis.tip.extensions.formats.dfa.records;
import java.time.LocalDate;
import java.math.BigDecimal;
import java.util.Objects;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class TransferTradeDTOTest {

    // ObjectMapper configured to handle LocalDate and not use timestamps
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    // Sample data
    private final LocalDate sampleTradeDate = LocalDate.of(2025, 11, 1);
    private final LocalDate sampleSettlementDate = LocalDate.of(2025, 11, 3);
    private final BigDecimal sampleShares = new BigDecimal("5000.75");
    private final TransferTradeDTO sampleDTO = new TransferTradeDTO(
            "TRANSFER-4455",
            "FROM_ACCT_123",
            "TO_ACCT_456",
            "US0000000002",
            "TRANSFER",
            sampleTradeDate,
            sampleSettlementDate,
            sampleShares,
            "USD"
    );

    @Test
    void testRecordAccessorsAndImmutability() {
        // Test accessors (default for Java Records)
        assertEquals("TRANSFER-4455", sampleDTO.dealId());
        assertEquals("FROM_ACCT_123", sampleDTO.fromAccountId());
        assertEquals("TO_ACCT_456", sampleDTO.toAccountId());
        assertEquals("TRANSFER", sampleDTO.transactionType());
        assertEquals(sampleTradeDate, sampleDTO.tradeDate());
        assertEquals(sampleShares, sampleDTO.shares());
    }

    @Test
    void testSerializationFormat() throws Exception {
        String json = mapper.writeValueAsString(sampleDTO);

        // 1. Verify date formats (yyyy-MM-dd)
        assertTrue(json.contains("\"tradeDate\":\"2025-11-01\""), "tradeDate must be serialized in yyyy-MM-dd format.");
        assertTrue(json.contains("\"settlementDate\":\"2025-11-03\""), "settlementDate must be serialized in yyyy-MM-dd format.");

        // 2. Verify BigDecimal serialization (as string)
        assertTrue(json.contains("\"shares\":\"5000.75\""), "Shares BigDecimal must be serialized as a string.");

        // 3. Verify account fields are present
        assertTrue(json.contains("\"fromAccountId\":\"FROM_ACCT_123\""));
        assertTrue(json.contains("\"toAccountId\":\"TO_ACCT_456\""));
    }

    @Test
    void testDeserialization() throws Exception {
        String json = """
            {
                "dealId":"T-999",
                "fromAccountId":"SRC_A",
                "toAccountId":"DEST_B",
                "isin":"ISIN123456",
                "transactionType":"TRANSFER",
                "tradeDate":"2023-05-20",
                "settlementDate":"2023-05-22",
                "shares":"10.01",
                "settlementCurrency":"CAD"
            }
            """;

        TransferTradeDTO deserializedDTO = mapper.readValue(json, TransferTradeDTO.class);

        assertEquals("T-999", deserializedDTO.dealId());
        assertEquals("SRC_A", deserializedDTO.fromAccountId());
        assertEquals("DEST_B", deserializedDTO.toAccountId());
        assertEquals(LocalDate.of(2023, 5, 20), deserializedDTO.tradeDate());
        assertEquals(new BigDecimal("10.01"), deserializedDTO.shares());
        assertEquals("CAD", deserializedDTO.settlementCurrency());
    }

    @Test
    void testToStringOutput() {
        String toString = sampleDTO.toString();
        assertTrue(toString.startsWith("TransferTradeDTO["), "toString() should start with the record name.");
        assertTrue(toString.contains("fromAccountId=FROM_ACCT_123"), "toString() should contain the source account.");
        assertTrue(toString.contains("shares=5000.75"), "toString() should contain the shares value.");
    }
}