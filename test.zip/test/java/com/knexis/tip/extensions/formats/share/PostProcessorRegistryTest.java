package com.knexis.tip.extensions.formats.share;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.extensions.formats.dist.process.DistributionPostProcessor;
import org.junit.jupiter.api.Test;

public class PostProcessorRegistryTest {

    @Test
    void testResolveReturnsDfaProcessor() {
        FormatPostProcessor processor = PostProcessorRegistry.resolve("FINANCIALDIRECT");
        assertInstanceOf(DfaPostProcessor.class, processor, "Should return DfaPostProcessor for FINANCIALDIRECT.");
    }

    @Test
    void testResolveReturnsDistributionProcessor() {
        FormatPostProcessor processor = PostProcessorRegistry.resolve("DISTRIBUTION");
        assertInstanceOf(DistributionPostProcessor.class, processor, "Should return DistributionPostProcessor for DISTRIBUTION.");
    }

    @Test
    void testResolveReturnsSameInstanceForAllFallbacks() {
        // 1. Capture the singleton instance by calling resolve(null)
        FormatPostProcessor defaultInstance = PostProcessorRegistry.resolve(null);

        // 2. Assert all fallback conditions return that exact instance

        // Null
        FormatPostProcessor processorNull = PostProcessorRegistry.resolve(null);
        assertSame(defaultInstance, processorNull, "Null input must return the static DEFAULT instance.");

        // Blank
        FormatPostProcessor processorBlank = PostProcessorRegistry.resolve("  ");
        assertSame(defaultInstance, processorBlank, "Blank input must return the static DEFAULT instance.");

        // Unknown type
        FormatPostProcessor processorUnknown = PostProcessorRegistry.resolve("UNKNOWN_TYPE");
        assertSame(defaultInstance, processorUnknown, "Unknown type must return the static DEFAULT instance.");

        // Ensure the DEFAULT instance has a distinguishable toString (for debugging)
        assertTrue(defaultInstance.toString().contains("NoOpFormatPostProcessor"), "Default instance should have correct toString.");
    }

    @Test
    void testResolveIsCaseSensitiveAndTrimmed() {
        // Test with padding (ensures trim() works)
        FormatPostProcessor processorPadded = PostProcessorRegistry.resolve(" FINANCIALDIRECT ");
        assertInstanceOf(DfaPostProcessor.class, processorPadded, "Should return DfaPostProcessor when padded but trimmed.");

        // Test case sensitivity (since the switch statement uses exact strings)
        FormatPostProcessor processorLowercase = PostProcessorRegistry.resolve("financialdirect");
        FormatPostProcessor defaultInstance = PostProcessorRegistry.resolve(null);
        assertSame(defaultInstance, processorLowercase, "Lowercase input must fall back to DEFAULT due to case sensitivity.");
    }
}