package com.knexis.tip.extensions.formats.dfa.records;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class DfaRecord3Test {

    private DfaRecord3 record;

    @BeforeEach
    void setUp() {
        record = new DfaRecord3();
    }

    @Test
    void testInheritedFields() {
        record.setRecordType("DFA");
        record.setSeq(3);

        assertEquals("DFA", record.getRecordType());
        assertEquals(3, record.getSeq());
    }

    @Test
    void testAllFieldsSetAndGet() {
        LocalDate date = LocalDate.of(2025, 9, 20);

        // Set all fields
        record.setContributionYear(2025);
        record.setFundFromCode(50000);
        record.setAccountFromTo(12345678901L);
        record.setVoluntaryTxnDesc("VOLUNTARY TRANSACTION");
        record.setCustomerAccountNumber("CUSTACCT12345");
        record.setAccountNumberCode("F");
        record.setSuperSheetDate(date);
        record.setBankMicrId(111111111L);
        record.setBankAccountNumber(22222222222222222L);
        record.setLiquidationCode("P");
        record.setTradeEntryMethod("T");
        record.setTradeOriginId(9999999);
        record.setMfTxnId1(10000000000L);
        record.setMfTxnId2(20000000000L);
        record.setTrustCompanyNumber("TRST");
        record.setTpaNumber("TPA1");
        record.setClientDefinedField("CLIENTDF");
        record.setFiller("FILL");

        // Assert all fields
        assertEquals(2025, record.getContributionYear());
        assertEquals(50000, record.getFundFromCode());
        assertEquals(12345678901L, record.getAccountFromTo());
        assertEquals("VOLUNTARY TRANSACTION", record.getVoluntaryTxnDesc());
        assertEquals("CUSTACCT12345", record.getCustomerAccountNumber());
        assertEquals("F", record.getAccountNumberCode());
        assertEquals(date, record.getSuperSheetDate());
        assertEquals(111111111L, record.getBankMicrId());
        assertEquals(22222222222222222L, record.getBankAccountNumber());
        assertEquals("P", record.getLiquidationCode());
        assertEquals("T", record.getTradeEntryMethod());
        assertEquals(9999999, record.getTradeOriginId());
        assertEquals(10000000000L, record.getMfTxnId1());
        assertEquals(20000000000L, record.getMfTxnId2());
        assertEquals("TRST", record.getTrustCompanyNumber());
        assertEquals("TPA1", record.getTpaNumber());
        assertEquals("CLIENTDF", record.getClientDefinedField());
        assertEquals("FILL", record.getFiller());
    }

    @Test
    void testToStringContainsKeyFields() {
        // Set a few key fields to ensure they appear in the toString output
        record.setCustomerAccountNumber("A-123");
        record.setMfTxnId1(50L);
        record.setLiquidationCode("F");

        String output = record.toString();

        // Assert key fields are present
        assertTrue(output.contains("customerAccountNumber=A-123"));
        assertTrue(output.contains("mfTxnId1=50"));
        assertTrue(output.contains("liquidationCode=F"));

    }
}