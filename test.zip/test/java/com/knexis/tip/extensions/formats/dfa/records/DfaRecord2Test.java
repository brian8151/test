package com.knexis.tip.extensions.formats.dfa.records;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class DfaRecord2Test {

    private DfaRecord2 record;

    @BeforeEach
    void setUp() {
        record = new DfaRecord2();
    }

    @Test
    void testInheritedFields() {
        record.setRecordType("DFA");
        record.setSeq(2);
        record.setRecordId("DFA-002");

        assertEquals("DFA", record.getRecordType());
        assertEquals(2, record.getSeq());
        assertEquals("DFA-002", record.getRecordId());
    }

    @Test
    void testAllFieldsSetAndGet() {
        // Sample values for all field types
        BigDecimal salesCharge = new BigDecimal("0.0000000000"); // Scale 10
        BigDecimal commAmt = new BigDecimal("254.00"); // Scale 2

        // Set all fields
        record.setCumulativeDiscountNumber(254000000000L);
        record.setLoiNumber(38024L);
        record.setSocialCode(102);
        record.setResidentStateCode("020");
        record.setRepNumber("2902");
        record.setRepName("JANE DOE");
        record.setPercentSalesCharge(salesCharge);
        record.setDealerCommissionCode("N");
        record.setDealerCommissionAmount(commAmt);
        record.setUnderwriterCommissionAmt(new BigDecimal("0.00"));
        record.setAsOfReasonCode(0);
        record.setCertificateIssuance("N");
        record.setCheckNumber(123456789012L);
        record.setSsn("000000000");
        record.setSsnStatusCode(0);
        record.setNavAccount("N");
        record.setAccountPriceScheduleCode(0);
        record.setMgmtCoEmployee("N");
        record.setExternalPlanId("PLANID123");
        record.setUnderwriterCommissionCode("+");
        record.setCdscWaiverReasonCode("    "); // 4 spaces
        record.setCommissionableShares("N");

        // Assert all fields
        assertEquals(254000000000L, record.getCumulativeDiscountNumber());
        assertEquals(38024L, record.getLoiNumber());
        assertEquals(102, record.getSocialCode());
        assertEquals("020", record.getResidentStateCode());
        assertEquals("2902", record.getRepNumber());
        assertEquals("JANE DOE", record.getRepName());
        assertEquals(salesCharge, record.getPercentSalesCharge());
        assertEquals("N", record.getDealerCommissionCode());
        assertEquals(commAmt, record.getDealerCommissionAmount());
        assertEquals(new BigDecimal("0.00"), record.getUnderwriterCommissionAmt());
        assertEquals(0, record.getAsOfReasonCode());
        assertEquals("N", record.getCertificateIssuance());
        assertEquals(123456789012L, record.getCheckNumber());
        assertEquals("000000000", record.getSsn());
        assertEquals(0, record.getSsnStatusCode());
        assertEquals("N", record.getNavAccount());
        assertEquals(0, record.getAccountPriceScheduleCode());
        assertEquals("N", record.getMgmtCoEmployee());
        assertEquals("PLANID123", record.getExternalPlanId());
        assertEquals("+", record.getUnderwriterCommissionCode());
        assertEquals("    ", record.getCdscWaiverReasonCode());
        assertEquals("N", record.getCommissionableShares());
    }

    @Test
    void testToStringContainsKeyFields() {
        // Set a few key fields to ensure they appear in the toString output
        record.setRepName("J. SMITH");
        record.setDealerCommissionAmount(new BigDecimal("99.99"));
        record.setSsn("111223333");

        String output = record.toString();

        // Assert key fields are present

        assertTrue(output.contains("dealerCommissionAmount=99.99"));
    }
}