package com.knexis.tip.extensions.formats.dfa.records;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class DfaRecord10Test {

    private DfaRecord10 record;

    @BeforeEach
    void setUp() {
        record = new DfaRecord10();
        record.setRecordType("DFA");
        record.setSeq(10);
    }

    @Test
    void testInheritedFields() {
        assertEquals("DFA", record.getRecordType());
        assertEquals(10, record.getSeq());
    }

    @Test
    void testAllFieldsSetAndGet() {
        // Set all fields
        record.setFinIntermediaryAbbr("MBDM");
        record.setCustodianAbbr("CUST");
        record.setTpaAbbr("TPA");
        record.setEventId1(9876543210L);
        record.setEventId2(12345678901L);
        record.setTradeTimestamp("2025-08-11-13.30.00.000000");
        record.setEffectivePriceDateYear(2025);
        record.setEffectivePriceDateMonth(8);
        record.setEffectivePriceDateDay(12);
        record.setEffectivePriceTimeHour(14);
        record.setEffectivePriceTimeMinute(0);
        record.setStrikeHour(15);
        record.setStrikeMinute(30);
        record.setTimeZoneCode("E");
        record.setLiquidityFeeResp("F");
        record.setFiller("FILLERDATA");

        // Assert all fields
        assertEquals("MBDM", record.getFinIntermediaryAbbr());
        assertEquals("CUST", record.getCustodianAbbr());
        assertEquals("TPA", record.getTpaAbbr());
        assertEquals(9876543210L, record.getEventId1());
        assertEquals(12345678901L, record.getEventId2());
        assertEquals("2025-08-11-13.30.00.000000", record.getTradeTimestamp());
        assertEquals(2025, record.getEffectivePriceDateYear());
        assertEquals(8, record.getEffectivePriceDateMonth());
        assertEquals(12, record.getEffectivePriceDateDay());
        assertEquals(14, record.getEffectivePriceTimeHour());
        assertEquals(0, record.getEffectivePriceTimeMinute());
        assertEquals(15, record.getStrikeHour());
        assertEquals(30, record.getStrikeMinute());
        assertEquals("E", record.getTimeZoneCode());
        assertEquals("F", record.getLiquidityFeeResp());
        assertEquals("FILLERDATA", record.getFiller());
    }

    @Test
    void testToStringContainsKeyFields() {
        // Set key fields
        record.setEventId1(10L);
        record.setTradeTimestamp("RAWTS");
        record.setTimeZoneCode("P");

        String output = record.toString();

        // Assert key fields are present
        assertTrue(output.contains("eventId1=10"));
        assertTrue(output.contains("tradeTimestamp=RAWTS"));
        assertTrue(output.contains("timeZoneCode=P"));

    }
}