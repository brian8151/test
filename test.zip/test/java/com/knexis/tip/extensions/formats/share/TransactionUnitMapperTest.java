package com.knexis.tip.extensions.formats.share;

import com.fasterxml.jackson.databind.JsonNode;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaTransferMapper;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TransactionUnitMapperTest {

    private final TransactionUnitMapper mapper = new DfaTransferMapper();
    private final TxnKind subscription = TxnKind.of("DFA", "SUBSCRIPTION");
    private final String reasonText = "Simple single-side transaction.";

    @Test
    void testToJsonContractWithContent() {
        TransactionGroup group = new TransactionGroup();
        TransactionUnit<TransactionGroup> unit = new TransactionUnit<>(
                subscription,
                List.of(group),
                reasonText
        );
        JsonNode result = mapper.toJson(unit);

        assertNotNull(result, "toJson() must return a JsonNode object.");
        System.out.println(result.toString());
        assertTrue(result.toString().contains("SUBSCRIPTION"), "toJson() should contain the mapped output.");
    }
}