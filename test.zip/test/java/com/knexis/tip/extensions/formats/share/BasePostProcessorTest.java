package com.knexis.tip.extensions.formats.share;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.extensions.formats.dfa.process.DfaTransferMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class BasePostProcessorTest {

    private DfaTransferMapper mockMapper;
    private DfaPostProcessor processor;

    @BeforeEach
    void setUp() {
        mockMapper = new DfaTransferMapper();
        processor = new DfaPostProcessor();
    }

    @Test
    void testConvertMethodMapsAllUnitsAndVerifiesCasting() {
        // Setup mock units. T is TransactionGroup here.
        TransactionGroup g1 = new TransactionGroup();
        TransactionGroup g2 = new TransactionGroup();

        TransactionUnit<TransactionGroup> unit1 = new TransactionUnit<>(TxnKind.of("DFA", "SUB"), List.of(g1), "r1");
        TransactionUnit<TransactionGroup> unit2 = new TransactionUnit<>(TxnKind.of("DFA", "ADD"), List.of(g2), "r2");

        List<TransactionUnit<TransactionGroup>> units = List.of(unit1, unit2);

        // When: convert is called
        List<JsonNode> jsonList = processor.convert(units);

        // Then:
        assertEquals(2, jsonList.size(), "Should produce one JsonNode for every input unit.");

    }

    @Test
    void testConvertReturnsEmptyListForEmptyInput() {
        List<TransactionUnit<TransactionGroup>> units = List.of();
        List<JsonNode> jsonList = processor.convert(units);

        assertTrue(jsonList.isEmpty(), "Should return an empty list for empty input.");
    }
}