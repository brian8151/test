package com.knexis.tip.extensions.formats.share;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TradeDTOTest {

    // ObjectMapper configured to handle LocalDate and not use timestamps
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    // Sample data
    private final LocalDate sampleTradeDate = LocalDate.of(2025, 10, 5);
    private final LocalDate sampleSettlementDate = LocalDate.of(2025, 10, 7);
    private final BigDecimal sampleShares = new BigDecimal("100.1234");
    private final TradeDTO sampleDTO = new TradeDTO(
            "1234567890123",
            "ACC-456",
            "US0000000001",
            "TRANSFER",
            sampleTradeDate,
            sampleSettlementDate,
            sampleShares,
            "USD"
    );

    @Test
    void testRecordAccessorsAndImmutability() {
        // Test accessors (default for Java Records)
        assertEquals("1234567890123", sampleDTO.dealId());
        assertEquals("ACC-456", sampleDTO.accountId());
        assertEquals("US0000000001", sampleDTO.isin());
        assertEquals("TRANSFER", sampleDTO.transactionType());
        assertEquals(sampleTradeDate, sampleDTO.tradeDate());
        assertEquals(sampleShares, sampleDTO.shares());
        assertEquals("USD", sampleDTO.settlementCurrency());

        // Test immutability (by ensuring no setters exist, implicit in Java Records)
        // No explicit assertion needed; it's guaranteed by the 'record' keyword.
    }

    @Test
    void testSerializationFormat() throws Exception {
        String json = mapper.writeValueAsString(sampleDTO);

        // Expected JSON structure, verifying specific format annotations
        String expectedJsonPart =
                "\"tradeDate\":\"2025-10-05\"," + // @JsonFormat applied
                        "\"settlementDate\":\"2025-10-07\"," + // @JsonFormat applied
                        "\"shares\":\"100.1234\"";     // @JsonSerialize(using = ToStringSerializer.class) applied

        // 1. Verify date formats (yyyy-MM-dd)
        assertTrue(json.contains("\"tradeDate\":\"2025-10-05\""), "tradeDate must be serialized in yyyy-MM-dd format.");
        assertTrue(json.contains("\"settlementDate\":\"2025-10-07\""), "settlementDate must be serialized in yyyy-MM-dd format.");

        // 2. Verify BigDecimal serialization (as string)
        assertTrue(json.contains("\"shares\":\"100.1234\""), "Shares BigDecimal must be serialized as a string.");

        // 3. Verify general field presence
        assertTrue(json.contains("\"dealId\":\"1234567890123\""));
    }

    @Test
    void testDeserialization() throws Exception {
        // Note: For deserialization, shares can be a number or a string.
        // We test with a full JSON string that mimics the output of the serializer.
        String json = String.format("""
            {
                "dealId":"D-987",
                "accountId":"A-789",
                "isin":"ISIN000000",
                "transactionType":"REDEMPTION",
                "tradeDate":"2024-01-15",
                "settlementDate":"2024-01-17",
                "shares":"50.5",
                "settlementCurrency":"EUR"
            }
            """);

        TradeDTO deserializedDTO = mapper.readValue(json, TradeDTO.class);

        assertEquals("D-987", deserializedDTO.dealId());
        assertEquals(LocalDate.of(2024, 1, 15), deserializedDTO.tradeDate());
        assertEquals(new BigDecimal("50.5"), deserializedDTO.shares());
        assertEquals("EUR", deserializedDTO.settlementCurrency());
    }

    @Test
    void testToStringOutput() {
        String toString = sampleDTO.toString();
        assertTrue(toString.startsWith("TradeDTO["), "toString() should start with the record name.");
        assertTrue(toString.contains("dealId=1234567890123"), "toString() should contain basic field values.");
        assertTrue(toString.contains("shares=100.1234"), "toString() should contain BigDecimal value.");
    }
}