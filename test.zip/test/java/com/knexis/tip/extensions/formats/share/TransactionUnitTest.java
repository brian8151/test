package com.knexis.tip.extensions.formats.share;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import org.junit.jupiter.api.Test;
import java.io.Serializable;

public class TransactionUnitTest {

    private final TxnKind subscription = TxnKind.of("DFA", "SUBSCRIPTION");
    private final TxnKind transfer = TxnKind.of("DFA", "TRANSFER");
    private final String reasonText = "Simple single-side transaction.";

    @Test
    void testSingleUnitWrappingTransactionGroup() {
        // 1. Setup a TransactionGroup (T) with a detail record
        TransactionGroup group1 = new TransactionGroup();
        DfaRecord1 dfaRecord1 = new DfaRecord1();
        dfaRecord1.setAccountNumber("ACCT123");
        group1.add(dfaRecord1);
        DfaRecord2 dfaRecord2 = new DfaRecord2();
        group1.add(dfaRecord2);

        // 2. Create the TransactionUnit wrapping the group
        TransactionUnit<TransactionGroup> unit = new TransactionUnit<>(
                subscription,
                List.of(group1),
                reasonText
        );

        // 3. Verify accessors and contained member properties
        assertEquals(1, unit.members().size(), "Unit must contain exactly one TransactionGroup member.");
        assertSame(group1, unit.members().get(0), "The member must be the original TransactionGroup instance.");

        // 4. Verify we can access the detail inside the TransactionGroup
        TransactionGroup retrievedGroup = unit.members().get(0);
        DfaRecord1 detail = retrievedGroup.firstOf(DfaRecord1.class);
        assertNotNull(detail, "Detail must be accessible within the wrapped TransactionGroup.");
        assertEquals("ACCT123", detail.getAccountNumber(), "Detail data should be intact.");
    }

    @Test
    void testPairedUnitWrappingTwoTransactionGroups() {
        // Setup two TransactionGroups (T)
        TransactionGroup group1 = new TransactionGroup();
        DfaRecord1 dfaRecord1 = new DfaRecord1();
        dfaRecord1.setAccountNumber("A1");
        group1.add(dfaRecord1);
        DfaRecord2 dfaRecord2 = new DfaRecord2();
        group1.add(dfaRecord2);


        // Create the TransactionUnit wrapping both groups (a 'TRANSFER' scenario)
        TransactionUnit<TransactionGroup> unit = new TransactionUnit<>(
                transfer,
                List.of(group1),
                "Paired by event ID 12345"
        );
        List<TransactionGroup> members = unit.members();
        // Verify structure
        assertEquals(1, members.size(), "Unit must contain One TransactionGroup");
        assertEquals(2, members.get(0).details().size(), "Unit must contain two TransactionGroup members for a paired transaction.");
        assertEquals(transfer, unit.kind());
        assertTrue(unit.reason().contains("12345"));
    }
}