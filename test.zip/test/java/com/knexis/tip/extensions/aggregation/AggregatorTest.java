package com.knexis.tip.extensions.aggregation;

import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.function.Supplier;

public class AggregatorTest {

    // Supplier for the actual transaction container
    private Supplier<TransactionGroup> transactionSupplier;

    @BeforeEach
    void setUp() {
        // The Aggregator should work with TransactionGroup (TX)
        transactionSupplier = TransactionGroup::new;
    }

    // === AGGREGATOR TESTS ===

    @Test
    void testOnRecordAddsDetailWhenNoPrefix() {
        Aggregator<TransactionGroup> agg = new Aggregator<>(transactionSupplier.get(), null);
        DfaRecord1 rec = new DfaRecord1();
        agg.onRecord("DFA001", rec);

        assertEquals(1, agg.finish().details().size());
        assertSame(rec, agg.finish().details().get(0));
    }

    @Test
    void testFinishReturnsTransactionInstance() {
        TransactionGroup tx = transactionSupplier.get();
        Aggregator<TransactionGroup> agg = new Aggregator<>(tx, null);
        agg.onRecord("DFA001", new DfaRecord1());

        assertSame(tx, agg.finish());
        assertEquals(1, agg.finish().details().size());
    }

    // === FACTORY TESTS ===

    @Test
    void testFactoryCreationWithoutPrefix() {
        Aggregator.Factory<TransactionGroup> factory = new Aggregator.Factory<>(transactionSupplier);

        GroupAggregator<TransactionGroup> agg = factory.create();

        assertNotNull(agg, "Factory must create an Aggregator instance.");

        // Ensure it works without a prefix filter
        agg.onRecord("ANY001", new DfaRecord1()); // Uses CGR001
        assertEquals(1, agg.finish().details().size());
    }


    @Test
    void testFactoryRejectsNullSupplier() {
        assertThrows(NullPointerException.class, () -> {
            new Aggregator.Factory<>(null);
        });
    }
}