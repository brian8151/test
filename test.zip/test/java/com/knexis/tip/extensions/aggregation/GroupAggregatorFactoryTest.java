package com.knexis.tip.extensions.aggregation;

import com.knexis.tip.extensions.formats.TransactionGroup;
import org.junit.jupiter.api.Test;

import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GroupAggregatorFactoryTest {
    private final TransactionGroup mockTx = new TransactionGroup();
    private final Supplier<TransactionGroup> supplier = () -> mockTx;

    @Test
    void testFactoryContract() {
        GroupAggregatorFactory<TransactionGroup> factory = new GroupAggregatorFactory<TransactionGroup>() {
            @Override
            public GroupAggregator<TransactionGroup> create() {
                return new GroupAggregator() {
                    @Override
                    public void onRecord(String recordId, Object record) {

                    }
                    @Override
                    public Object finish() {
                        return null;
                    }
                };
            }
        };
        // Verify create() returns a non-null instance of GroupAggregator
        GroupAggregator<TransactionGroup> aggregator = factory.create();
        assertNotNull(aggregator, "Factory must successfully create an Aggregator instance.");
    }
}
