package com.knexis.tip.extensions.aggregation;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.types.OutboundDetail;
import org.junit.jupiter.api.Test;
import java.util.function.Supplier;

public class GroupAggregatorTest {
    private final TransactionGroup mockTx = new TransactionGroup();
    private final Supplier<TransactionGroup> supplier = () -> mockTx;

    @Test
    void testAggregatorProcess() {
        GroupAggregator<TransactionGroup> aggregator = new ConcreteAggregator(new TransactionGroup());

        // 1. Verify onRecord can be called with a domain detail
        aggregator.onRecord("DFA001", new DfaRecord1());
        aggregator.onRecord("DFA002", new DfaRecord1());

        // 2. Verify finish can be called and returns the correct type
        TransactionGroup result = aggregator.finish();

        assertInstanceOf(TransactionGroup.class, result, "finish() must return the correct aggregated type (TransactionGroup).");
        assertEquals(2, result.details().size(), "The aggregator must add records to the transaction container.");
    }

    @Test
    void testFactoryCreate() {
        GroupAggregatorFactory<TransactionGroup> factory = new ConcreteFactory(supplier);

        // 1. Verify create() returns a GroupAggregator instance
        GroupAggregator<TransactionGroup> aggregator = factory.create();

        assertNotNull(aggregator, "Factory must successfully create an Aggregator instance.");

        // 2. Verify the created aggregator uses the supplied transaction instance
        aggregator.onRecord("TEST01", new DfaRecord1());

        assertSame(mockTx, aggregator.finish(), "The aggregator must use the TransactionGroup instance provided by the supplier.");
    }
    private static class ConcreteAggregator implements GroupAggregator<TransactionGroup> {
        private final TransactionGroup result;
        private int recordCount = 0;

        public ConcreteAggregator(TransactionGroup result) {
            this.result = result;
        }

        @Override
        public void onRecord(String recordId, Object record) {
            // Must ensure the record is an OutboundDetail, as required by real Aggregator
            if (record instanceof OutboundDetail) {
                recordCount++;
                result.add((OutboundDetail) record);
            }
        }

        @Override
        public TransactionGroup finish() {
            return result;
        }
    }

    /** Concrete implementation of GroupAggregatorFactory for testing the factory contract. */
    private static class ConcreteFactory implements GroupAggregatorFactory<TransactionGroup> {
        private final Supplier<TransactionGroup> supplier;

        public ConcreteFactory(Supplier<TransactionGroup> supplier) {
            this.supplier = supplier;
        }

        @Override
        public GroupAggregator<TransactionGroup> create() {
            return new ConcreteAggregator(supplier.get());
        }
    }
}
