package com.knexis.tip;

import com.fasterxml.jackson.databind.JsonNode;
import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.parser.RecordTokenizer;
import com.knexis.tip.core.parser.Validator;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.share.FormatPostProcessor;
import com.knexis.tip.extensions.formats.share.PostProcessorRegistry;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.utils.TransactionPrinter;
import org.junit.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ParseDispatcherTest {

   // public final String file = "data/MFB.MB701.TIP01";
    public final String file = "data/MFB.MBCMBTest.TIP";
    /** Utility: resolve a classpath resource to a Path. */
    private static Path resourcePath(String res) throws Exception {
        URL url = ParseDispatcherTest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }

    @Test
    public void parsesFinancialDirectEndToEnd() throws Exception {
        // Given: input sample under test resources
        //Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        Path input = resourcePath(file);
        List<String> lines = Files.readAllLines(input);

        // And: registry from test catalog.yml
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        String anyId = registry.allIds().iterator().next();
        var common = registry.getById(anyId);
        var headerSchema  = common.getHeader();
        var trailerSchema = common.getTrailer();
        int recordLen     = common.getRecordLength() != null ? common.getRecordLength() : 0;
        // Validate header and tailer using schema positions + match
        String headerLine = lines.get(0);
        Validator.validateHeaderLine(headerLine, headerSchema, recordLen);
        Validator.validateTrailerLine(lines.get(lines.size() - 1), trailerSchema, recordLen);
        String fileTypeId = RecordTokenizer.fileTypeId(headerLine, headerSchema);
        // And: dispatcher auto-registered for every id in the catalog using TransactionGroup
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);

        // When: dispatch & parse
        ParseDispatcher.Result result = dispatcher.dispatch(input, lines,fileTypeId);

        // Then: detected type is FINANCIALDIRECT (from header cols 7–21)
        //assertThat(result.fileTypeId()).isEqualTo("FINANCIALDIRECT");

        // And: we can safely cast to the agreed transaction container
        OutboundFile<TransactionGroup> file = result.cast(TransactionGroup.class);

        // Header basics
        assertThat(file.getHeader()).isNotNull();
        assertThat(file.getHeader()).containsKeys("recordType", "fileTypeText");
        assertThat(file.getHeader().get("recordType")).isEqualTo("RHR");
        //assertThat(file.getHeader().get("fileTypeText")).isEqualTo("FINANCIALDIRECT");

        // Trailer basics
        assertThat(file.getTrailer()).isNotNull();
        assertThat(file.getTrailer()).containsKeys("recordType", "fileTypeText");
        assertThat(file.getTrailer().get("recordType")).isEqualTo("RTR");

        // We should have at least one logical transaction/group
        assertThat(file.getItems()).isNotEmpty();

        // Each transaction should have at least one detail
        for (TransactionGroup tx : file.getItems()) {
            assertThat(tx.details()).isNotEmpty();
        }
        TransactionPrinter.printFile(file);
        FormatPostProcessor pp = PostProcessorRegistry.resolve(fileTypeId);
        var units = pp.process(fileTypeId, file);
        System.out.println("-----Transactions UNIT ----------");
        TransactionPrinter.printUnits(units);
        List<JsonNode> output = pp.convert(units);
        System.out.println("----- JSON OUTPUT ----------");
        TransactionPrinter.printJson(output);
    }

    @Test
    public void autoRegistersAllIdsFromCatalog() {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);

        // All ids present in registry should be registered in dispatcher
        assertThat(registry.allIds()).isNotEmpty();
    }
}
