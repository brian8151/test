package com.knexis.tip.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import com.knexis.tip.conf.UrlProps;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EndpointResolverTest {

    @Mock
    UrlProps urlProps;

    private EndpointResolver resolverWith(Map<String,String> paths, String tailInboundBase) {
        when(urlProps.paths()).thenReturn(paths);
        when(urlProps.tailInbound()).thenReturn(URI.create(tailInboundBase));
        return new EndpointResolver(urlProps);
    }

    @Test
    void resolves_specific_mappings_and_normalizes_slashes() {
        Map<String,String> paths = new HashMap<>();
        paths.put("FINANCIALDIRECT", "tip/financial"); // no leading slash
        paths.put("DISTRIBUTION",    "/dist");         // leading slash (should be trimmed)

        // base has trailing slashes (should be trimmed)
        EndpointResolver resolver = resolverWith(paths, "https://tail.example.com///");

        assertEquals("https://tail.example.com/tip/financial",
                resolver.getUrl("FINANCIALDIRECT").toString());

        assertEquals("https://tail.example.com/dist",
                resolver.getUrl("DISTRIBUTION").toString());
    }

    @Test
    void falls_back_to_DEFAULT_mapping_for_unknown_ids() {
        Map<String,String> paths = new HashMap<>();
        paths.put("DEFAULT", "api/v1/inbound");

        EndpointResolver resolver = resolverWith(paths, "https://tail.example.com/");

        assertEquals("https://tail.example.com/api/v1/inbound",
                resolver.getUrl("SOMETHING_ELSE").toString());
    }

    @Test
    void empty_subpath_returns_base_unchanged() {
        Map<String,String> paths = new HashMap<>();
        paths.put("FINANCIALDIRECT", ""); // blank → returns base

        EndpointResolver resolver = resolverWith(paths, "https://tail.example.com/base/");

        assertEquals("https://tail.example.com/base",
                resolver.getUrl("FINANCIALDIRECT").toString());
    }

    @Test
    void init_logs_two_urls_without_throwing() {
        Map<String,String> paths = new HashMap<>();
        paths.put("FINANCIALDIRECT", "tip/financial");
        paths.put("DISTRIBUTION",    "dist");
        paths.put("DEFAULT",         "fallback");

        EndpointResolver resolver = resolverWith(paths, "https://tail.example.com/");
        assertDoesNotThrow(resolver::init); // just ensure the @PostConstruct logic runs cleanly
    }
}