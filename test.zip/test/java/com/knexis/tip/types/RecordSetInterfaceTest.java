package com.knexis.tip.types;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the RecordSet interface contract.
 */
public class RecordSetInterfaceTest {

    // Change the generic type to DfaRecord1
    private RecordSet<RecordHeader> recordSet;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        // Use the mock implementation to test the contract
        recordSet = new RecordSetBase<>();
        recordSet.add(new DfaRecord1());
        recordSet.add(new DfaRecord2()); // Add a different type for filtering tests
    }

    @Test
    void testAddAndSize() {
        // Initial setup has 2 records
        assertEquals(2, recordSet.size(), "Size should reflect added records.");

        recordSet.add(new DfaRecord1());
        assertEquals(3, recordSet.size(), "Size should increment after adding another record.");
    }

    @Test
    void testGetRecordsIsUnmodifiable() {
        List<RecordHeader> records = recordSet.getRecords();
        assertEquals(2, records.size());

        // Assert that the returned list is unmodifiable (throws an exception on modification)
        assertThrows(UnsupportedOperationException.class, () -> records.add(new DfaRecord1()),
                "getRecords() should return an unmodifiable list.");
    }

    @Test
    void testIterableContract() {
        int count = 0;
        for (RecordHeader detail : recordSet) {
            assertNotNull(detail);
            count++;
        }
        assertEquals(2, count, "Iterator should correctly traverse all records.");
    }

    @Test
    void testFirstOfReturnsNullWhenEmpty() {
        RecordSet<RecordHeader> emptySet = new RecordSetBase<>();
        assertNull(emptySet.firstOf(DfaRecord1.class), "Should return null for firstOf when set is empty.");
    }

    @Test
    void testOfTypeAndFirstOf() {
        // Test firstOf to find an existing type
        DfaRecord1 firstDfa1 = recordSet.firstOf(DfaRecord1.class);
        assertNotNull(firstDfa1, "Should find the first DfaRecord1.");

        // Test ofType to get all records of DfaRecord1
        List<DfaRecord1> dfa1s = recordSet.ofType(DfaRecord1.class);
        assertEquals(1, dfa1s.size(), "Should return only one DfaRecord1.");

        // Test for a type that is present (DfaRecord2)
        List<DfaRecord2> dfa2s = recordSet.ofType(DfaRecord2.class);
        assertEquals(1, dfa2s.size(), "Should return one DfaRecord2.");

        // Test for a type that is NOT present
        class AbsentRecord extends RecordHeader {}
        List<AbsentRecord> absents = recordSet.ofType(AbsentRecord.class);
        assertTrue(absents.isEmpty(), "Should return an empty list for a non-existent type.");
        assertNull(recordSet.firstOf(AbsentRecord.class), "Should return null for firstOf a non-existent type.");
    }
}