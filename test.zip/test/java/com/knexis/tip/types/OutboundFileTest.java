package com.knexis.tip.types;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the OutboundFile class.
 */
public class OutboundFileTest {

    private Map<String, Object> mockHeader;
    private Map<String, Object> mockTrailer;
    private List<String> initialItems;
    private OutboundFile<String> outboundFile;

    // A mock generic type for testing purposes
    public static class MockTransaction {}

    @BeforeEach
    void setUp() {
        mockHeader = new HashMap<>();
        mockHeader.put("fileType", "FINANCIALDIRECT");
        mockHeader.put("recordCount", 100);

        mockTrailer = new HashMap<>();
        mockTrailer.put("hashTotal", 1234567);

        initialItems = Arrays.asList("TXN1", "TXN2");

        // Instantiate OutboundFile with String as the generic type T
        outboundFile = new OutboundFile<>(mockHeader, initialItems, mockTrailer);
    }

    @Test
    void testConstructorInitialization() {
        // Assert final fields are initialized correctly via constructor
        assertSame(mockHeader, outboundFile.getHeader(), "Header should be the same instance passed to the constructor.");
        assertSame(mockTrailer, outboundFile.getTrailer(), "Trailer should be the same instance passed to the constructor.");
        assertSame(initialItems, outboundFile.getItems(), "Items list should be the same instance passed to the constructor.");
    }

    @Test
    void testGetHeaderAndTrailerImmutability() {
        // Test that modifying the map returned by the getter modifies the internal state
        // (Since header and trailer are final Map references, not copies)
        outboundFile.getHeader().put("newKey", "newValue");
        assertTrue(mockHeader.containsKey("newKey"), "Modifying the returned header map should affect the internal map.");

        outboundFile.getTrailer().put("newKey2", "newValue2");
        assertTrue(mockTrailer.containsKey("newKey2"), "Modifying the returned trailer map should affect the internal map.");
    }

    @Test
    void testSetAndGetItems() {
        // Test the initial state
        assertEquals(2, outboundFile.getItems().size(), "Initial items list size should be 2.");

        // Create and set a new list of items
        List<String> newItems = Collections.singletonList("TXN3");
        outboundFile.setItems(newItems);

        // Test the new state
        assertSame(newItems, outboundFile.getItems(), "setItems should update the internal reference.");
        assertEquals(1, outboundFile.getItems().size(), "Items list size should be 1 after setting a new list.");
    }

    @Test
    void testGenericTypeSafety() {
        // Instantiate OutboundFile with a custom generic type
        MockTransaction mockTxn1 = new MockTransaction();
        MockTransaction mockTxn2 = new MockTransaction();
        List<MockTransaction> txnItems = Arrays.asList(mockTxn1, mockTxn2);

        OutboundFile<MockTransaction> txnFile = new OutboundFile<>(mockHeader, txnItems, mockTrailer);

        // Verify generic type access
        List<MockTransaction> retrievedItems = txnFile.getItems();
        assertEquals(2, retrievedItems.size(), "Generic list size check.");
        assertSame(mockTxn1, retrievedItems.get(0), "Generic item access check.");
    }
}