package com.knexis.tip.types;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the RecordHeader class, covering POJO accessors and static methods.
 */
public class RecordHeaderTest {

    private DfaRecord1 r1;
    private DfaRecord1 r2;
    private DfaRecord2 r3;
    private TransactionGroup txGroup; // Now using the concrete TransactionGroup class

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        r1 = new DfaRecord1();
        r1.setRecordType("DFA");
        r1.setSeq(1);

        r2 = new DfaRecord1(); // Test trimming/case conversion
        r2.setRecordType("DFA ");
        r2.setSeq(2);

        r3 = new DfaRecord2();
        r3.setRecordType("NON");
        r3.setSeq(1);

        // Initialize the TransactionGroup and add details using its add method
        txGroup = new TransactionGroup();
        txGroup.add(r1);
        txGroup.add(r3); // Seq 1 is repeated but different type
        txGroup.add(r2);
    }

    // --- POJO Accessor Tests ---

    @Test
    void testPojoAccessors() {
        // Test getters and setters inherited from Lombok/OutboundDetailBase
        assertEquals("DFA", r1.getRecordType());
        assertEquals(1, r1.getSeq());

        r1.setRecordType("RHR");
        r1.setSeq(999);
        assertEquals("RHR", r1.getRecordType());
        assertEquals(999, r1.getSeq());
        // Verify default/null access
        DfaRecord1 defaultRec = new DfaRecord1();
        assertNull(defaultRec.getRecordType());
        assertNull(defaultRec.getSeq());
    }

    // --- Static Utility Method Tests ---

    @Test
    void testStaticRecordType() {
        // Test normal record type
        assertEquals("DFA", RecordHeader.recordType(r1), "Should return trimmed and uppercased record type.");
        // Test trimming and case conversion
        assertEquals("DFA", RecordHeader.recordType(r2), "Should trim whitespace and uppercase.");
        // Test null values
        assertEquals("", RecordHeader.recordType(null), "Should return empty string for null input.");
        r1.setRecordType(null);
        assertEquals("", RecordHeader.recordType(r1), "Should return empty string for null recordType.");
        r1.setRecordType(" ");
        assertEquals("", RecordHeader.recordType(r1), "Should return empty string for blank recordType.");
        r1.setRecordType("MIXED");
        assertEquals("MIXED", RecordHeader.recordType(r1), "Should handle mixed case.");
    }

    @Test
    void testStaticSeq() {
        // Test normal sequence
        assertEquals(1, RecordHeader.seq(r1), "Should return the sequence number.");
        // Test null values
        assertNull(RecordHeader.seq(null), "Should return null for null input.");
        r1.setSeq(null);
        assertNull(RecordHeader.seq(r1), "Should return null for null seq value.");
    }

    @Test
    void testFirstBySeq() {
        // Find existing record by sequence
        Optional<OutboundDetail> found1 = RecordHeader.firstBySeq(txGroup, 1);
        assertTrue(found1.isPresent(), "Should find a record with seq 1.");
        assertSame(r1, found1.get(), "Should return the first record with seq 1 (r1).");

        // Find existing record by sequence 2
        Optional<OutboundDetail> found2 = RecordHeader.firstBySeq(txGroup, 2);
        assertTrue(found2.isPresent(), "Should find a record with seq 2.");
        assertSame(r2, found2.get(), "Should return the record with seq 2 (r2).");

        // Try to find non-existent sequence
        Optional<OutboundDetail> notFound = RecordHeader.firstBySeq(txGroup, 99);
        assertFalse(notFound.isPresent(), "Should not find a record with seq 99.");
    }

    @Test
    void testGetFirstBySeqWithTypeCasting() {
        // Find r1 (DfaRecord1) by seq 1
        Optional<DfaRecord1> foundR1 = RecordHeader.getFirstBySeq(txGroup, 1, DfaRecord1.class);
        assertTrue(foundR1.isPresent(), "Should find DfaRecord1 with seq 1.");
        assertSame(r1, foundR1.get(), "Should return r1 and cast it correctly.");

        // Try to find r3 (DfaRecord2) by seq 1 - this should fail because r1 is first
        Optional<DfaRecord2> foundR3Fail = RecordHeader.getFirstBySeq(txGroup, 1, DfaRecord2.class);
        assertFalse(foundR3Fail.isPresent(), "Should NOT find DfaRecord2 with seq 1 because DfaRecord1 comes first.");

        // Find r2 (DfaRecord1) by seq 2
        Optional<DfaRecord1> foundR2 = RecordHeader.getFirstBySeq(txGroup, 2, DfaRecord1.class);
        assertTrue(foundR2.isPresent(), "Should find DfaRecord1 with seq 2.");
        assertSame(r2, foundR2.get(), "Should return r2 and cast it correctly.");

        // Correct test: search for type that is present
        Optional<DfaRecord2> foundR3 = RecordHeader.getFirstBySeq(txGroup, 1, DfaRecord2.class);
        assertFalse(foundR3.isPresent(), "Should fail because r1 (DfaRecord1) is the first match for seq 1, but we requested DfaRecord2.");
    }
}