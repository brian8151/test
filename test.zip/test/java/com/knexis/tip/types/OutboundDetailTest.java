package com.knexis.tip.types;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Unit tests for the OutboundDetail interface via its mock implementation.
 */
public class OutboundDetailTest {

    @Test
    void testRecordIdAccessors() {
        OutboundDetail detail = new OutboundDetailBase();
        String expectedId = "DFA-001";

        // 1. Test initial state
        assertNull(detail.getRecordId(), "Record ID should be null initially.");

        // 2. Test setter
        detail.setRecordId(expectedId);

        // 3. Test getter
        assertEquals(expectedId, detail.getRecordId(), "Getter should retrieve the set Record ID.");
    }

    @Test
    void testLineNumberAccessors() {
        OutboundDetail detail = new OutboundDetailBase();
        Integer expectedLineNumber = 42;

        // 1. Test initial state
        assertNull(detail.getLineNumber(), "Line Number should be null initially.");

        // 2. Test setter
        detail.setLineNumber(expectedLineNumber);

        // 3. Test getter
        assertEquals(expectedLineNumber, detail.getLineNumber(), "Getter should retrieve the set Line Number.");
    }

    @Test
    void testSettersHandleNull() {
        OutboundDetail detail = new OutboundDetailBase();

        // Set values
        detail.setRecordId("DFA-002");
        detail.setLineNumber(100);

        // Set back to null
        detail.setRecordId(null);
        detail.setLineNumber(null);

        // Verify null
        assertNull(detail.getRecordId(), "Setting Record ID to null should be supported.");
        assertNull(detail.getLineNumber(), "Setting Line Number to null should be supported.");
    }
}