package com.knexis.tip.types;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Iterator;
import java.util.List;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord2;
import org.junit.jupiter.api.Test;
/**
 * Unit tests for the RecordSetBase class, using DfaRecord1 and DfaRecord2.
 */
public class RecordSetBaseTest {

    // Use RecordHeader as the generic type T for testing
    private final RecordSetBase<RecordHeader> set = new RecordSetBase<>();

    private final DfaRecord1 recDfa1a = new DfaRecord1();
    private final DfaRecord2 recDfa2a = new DfaRecord2();
    private final DfaRecord1 recDfa1b = new DfaRecord1();

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        set.add(recDfa1a);
        set.add(recDfa2a);
        set.add(recDfa1b);
    }

    @Test
    void testAddAndSize() {
        assertEquals(3, set.size(), "Size should reflect the number of added records.");
    }

    @Test
    void testGetRecordsIsUnmodifiable() {
        List<RecordHeader> records = set.getRecords();
        assertEquals(3, records.size(), "getRecords() should return the full list.");

        // Assert it is unmodifiable (throws an exception on attempted modification)
        assertThrows(UnsupportedOperationException.class, () -> {
            records.add(new DfaRecord1());
        }, "The list returned by getRecords() must be unmodifiable.");
    }

    @Test
    void testOfType() {
        // Test filtering for DfaRecord1
        List<DfaRecord1> records1 = set.ofType(DfaRecord1.class);
        assertEquals(2, records1.size(), "ofType(DfaRecord1.class) should return 2 records.");
        assertTrue(records1.contains(recDfa1a) && records1.contains(recDfa1b), "The list should contain the correct instances of DfaRecord1.");

        // Test filtering for DfaRecord2
        List<DfaRecord2> records2 = set.ofType(DfaRecord2.class);
        assertEquals(1, records2.size(), "ofType(DfaRecord2.class) should return 1 record.");
        assertTrue(records2.contains(recDfa2a), "The list should contain the correct instance of DfaRecord2.");

        // Test filtering for a type not present (e.g., a generic RecordHeader)
        List<RecordHeader> recordsHeader = set.ofType(RecordHeader.class);
        assertEquals(3, recordsHeader.size(), "ofType(RecordHeader.class) should return all 3 records as they extend RecordHeader.");
    }

    @Test
    void testFirstOf() {
        // Test finding the first DfaRecord1
        DfaRecord1 first1 = set.firstOf(DfaRecord1.class);
        assertSame(recDfa1a, first1, "firstOf(DfaRecord1.class) should return the first instance added (recDfa1a).");

        // Test finding the first DfaRecord2
        DfaRecord2 first2 = set.firstOf(DfaRecord2.class);
        assertSame(recDfa2a, first2, "firstOf(DfaRecord2.class) should return the first instance of DfaRecord2.");

        // Test finding a type that is not present
        class RecordZ extends RecordHeader {}
        RecordZ firstZ = set.firstOf(RecordZ.class);
        assertNull(firstZ, "firstOf() should return null if the type is not found.");
    }

    @Test
    void testIterator() {
        Iterator<RecordHeader> iterator = set.iterator();
        assertTrue(iterator.hasNext(), "Iterator should have elements.");

        // Verify order
        assertSame(recDfa1a, iterator.next(), "First element from iterator should be recDfa1a.");
        assertSame(recDfa2a, iterator.next(), "Second element from iterator should be recDfa2a.");
        assertSame(recDfa1b, iterator.next(), "Third element from iterator should be recDfa1b.");
        assertFalse(iterator.hasNext(), "Iterator should be exhausted.");
    }
}