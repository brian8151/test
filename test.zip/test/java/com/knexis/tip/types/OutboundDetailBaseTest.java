package com.knexis.tip.types;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the OutboundDetailBase concrete class.
 */
public class OutboundDetailBaseTest {

    @Test
    void testInitialState() {
        OutboundDetailBase base = new OutboundDetailBase();
        assertNull(base.getRecordId(), "Record ID should be null upon instantiation.");
        assertNull(base.getLineNumber(), "Line Number should be null upon instantiation.");
    }

    @Test
    void testRecordIdAccessors() {
        OutboundDetailBase base = new OutboundDetailBase();
        String expectedId = "FIN-001";

        // Test setter and getter for a valid value
        base.setRecordId(expectedId);
        assertEquals(expectedId, base.getRecordId(), "Getter should retrieve the set Record ID.");

        // Test setter for null
        base.setRecordId(null);
        assertNull(base.getRecordId(), "Setting Record ID to null should be supported.");
    }

    @Test
    void testLineNumberAccessors() {
        OutboundDetailBase base = new OutboundDetailBase();
        Integer expectedLineNumber = 75;

        // Test setter and getter for a valid value
        base.setLineNumber(expectedLineNumber);
        assertEquals(expectedLineNumber, base.getLineNumber(), "Getter should retrieve the set Line Number.");

        // Test setter for null
        base.setLineNumber(null);
        assertNull(base.getLineNumber(), "Setting Line Number to null should be supported.");
    }
}