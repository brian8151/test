package com.knexis.tip.utils;

import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.parser.RecordTokenizer;
import com.knexis.tip.core.parser.Validator;
import com.knexis.tip.core.schema.OutboundFileSchema;
import com.knexis.tip.core.schema.RecordSchema;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.types.OutboundFile;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SchemaLoaderTest {
    private static Path resourcePath(String res) throws Exception {
        URL url = SchemaLoaderTest.class.getClassLoader().getResource(res);
        if (url == null) throw new IllegalArgumentException("Resource not found: " + res);
        return Path.of(url.toURI());
    }
    @Test
    void loadsCatalog_and_parses_financialDirect() throws Exception {
        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");

        // Basic sanity on catalog
        assertThat(registry.allIds()).isNotEmpty();
        OutboundFileSchema schema = registry.getById("FINANCIALDIRECT");
        assertThat(schema).isNotNull();

        // Read sample file and derive fileTypeId from header per schema
        Path input = resourcePath("data/MFB.MBCMBTest.TIP");
        List<String> lines = Files.readAllLines(input);

        RecordSchema headerSchema = schema.getHeader();
        int recordLen = schema.getRecordLength() != null ? schema.getRecordLength() : 0;
        Validator.validateHeaderLine(lines.get(0), headerSchema, recordLen);
        String fileTypeId = RecordTokenizer.fileTypeId(lines.get(0), headerSchema);
        assertThat(fileTypeId).isEqualTo("FINANCIALDIRECT");

        // Dispatcher with all strategies registered from the catalog
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);

        // Parse & assert basics
        ParseDispatcher.Result result = dispatcher.dispatch(input, lines, fileTypeId);
        assertThat(result.fileTypeId()).isEqualTo("FINANCIALDIRECT");
        assertThat(result.txClass()).isEqualTo(TransactionGroup.class);

        OutboundFile<TransactionGroup> file = result.cast(TransactionGroup.class);
        assertThat(file.getHeader().get("recordType")).isEqualTo("RHR");
        assertThat(file.getTrailer().get("recordType")).isEqualTo("RTR");
        assertThat(file.getItems()).isNotEmpty(); // e.g., 4 groups for your sample
    }

    @Test
    void loadFromResource_missing_throws() {
        assertThrows(SchemaException.class,
                () -> SchemaLoader.loadFromResource("schemas/missing-does-not-exist.yml"));
    }

    @Test
    void loadFromPath_success_and_error() throws Exception {
        Path tmp = Files.createTempFile("schema-", ".yml");
        Files.writeString(tmp, "fileType: TMP\nrecordLength: 42\n");
        OutboundFileSchema s = SchemaLoader.load(tmp);
        assertThat(s.getFileType()).isEqualTo("TMP");
        assertThat(s.getRecordLength()).isEqualTo(42);

        Path bad = tmp.getParent().resolve("nope-" + System.nanoTime() + ".yml");
        assertThrows(SchemaException.class, () -> SchemaLoader.load(bad));
    }

    @Test
    void loadFromStream_success_and_invalid_yaml() throws Exception {
        String yml = "fileType: STREAM\nrecordLength: 7\n";
        try (InputStream in = new ByteArrayInputStream(yml.getBytes(StandardCharsets.UTF_8))) {
            OutboundFileSchema s = SchemaLoader.load(in);
            assertThat(s.getFileType()).isEqualTo("STREAM");
            assertThat(s.getRecordLength()).isEqualTo(7);
        }

        try (InputStream in = SchemaLoaderTest.class.getClassLoader().getResourceAsStream("schemas/invalid.yml")) {
            assertThrows(SchemaException.class, () -> SchemaLoader.load(in));
        }
    }

    @Test
    void loadFromResource_detects_circular_extends() {
        assertThrows(SchemaException.class, () -> SchemaLoader.loadFromResource("schemas/cycleA.yml"));
    }
}
