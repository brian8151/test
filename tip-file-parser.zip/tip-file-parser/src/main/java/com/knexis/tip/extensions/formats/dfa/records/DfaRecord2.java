package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString(callSuper = true, includeFieldNames = true)
public class DfaRecord2 extends RecordHeader implements DfaDetail {
    private Long cumulativeDiscountNumber;     // 7–15
    private Long loiNumber;                    // 16–24
    private Integer socialCode;                // 25–27
    private String residentStateCode;          // 28–30
    private String repNumber;                  // 31–39
    private String repName;                    // 40–69
    private BigDecimal percentSalesCharge;     // 70–84 (scale 10)
    private String dealerCommissionCode;       // 85
    private BigDecimal dealerCommissionAmount; // 86–100 (scale 2)
    private BigDecimal underwriterCommissionAmt;// 101–115 (scale 2)
    private Integer asOfReasonCode;            // 116–118
    private String certificateIssuance;        // 119
    private Long checkNumber;                  // 120–132
    private String ssn;                        // 133–141
    private Integer ssnStatusCode;             // 142
    private String navAccount;                 // 143
    private Integer accountPriceScheduleCode;  // 144
    private String mgmtCoEmployee;             // 145
    private String externalPlanId;             // 146–154
    private String underwriterCommissionCode;  // 155
    private String cdscWaiverReasonCode;       // 156–159
    private String commissionableShares;       // 160
}