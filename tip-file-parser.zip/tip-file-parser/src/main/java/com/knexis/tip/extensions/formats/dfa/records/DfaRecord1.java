package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@ToString(callSuper = true)
public class DfaRecord1 extends RecordHeader implements DfaDetail {
    private String recordType;
    private Integer seq;
    private Integer recordCode;
    private Integer participantNumber;
    private String dealerBranchId;
    private String cusip;
    private Integer fundCode;
    private String accountNumber;
    private String accountNumberCode;
    private Integer batchNumber;
    private LocalDate batchDate;
    private Integer txnCode;
    private Integer txnSuffix;
    private String shareBalanceEffect;
    private BigDecimal sharePriceAmount;
    private BigDecimal grossTxnAmount;
    private BigDecimal sharesTxnCount;
    private LocalDate tradeDate;
    private LocalDate confOrPayDate;
    private Integer discountCategory;
    private Long orderNumber;
    private String accountType;
    private String dealerLevelControl;
    private String paymentMethod;
    private String prePostNoonFlag;
    private String shortTermWaiverReason;
    private Integer totalRecordCountForType;
}