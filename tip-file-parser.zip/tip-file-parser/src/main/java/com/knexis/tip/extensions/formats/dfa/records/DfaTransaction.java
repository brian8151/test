package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordSetBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
/** One logical DFA transaction = ordered list of sub-records */
public class DfaTransaction extends RecordSetBase<DfaDetail> {
    private final List<DfaDetail> records = new ArrayList<>();

    public void add(DfaDetail record) { records.add(record); }
    public List<DfaDetail> getRecords() { return records; }

    /** Helper to fetch all records of a specific class (preserves order). */
    public <T extends DfaDetail> List<T> getRecordsOfType(Class<T> type) {
        List<T> out = new ArrayList<>();
        for (DfaDetail d : records) if (type.isInstance(d)) out.add(type.cast(d));
        return out;
    }

    /** First record of given type, or null. */
    public <T extends DfaDetail> T firstOf(Class<T> type) {
        for (DfaDetail d : records) if (type.isInstance(d)) return type.cast(d);
        return null;
    }
}