package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TagField {
    private int start;  // 1-based inclusive
    private int end;    // 1-based inclusive
    private String match;
}
