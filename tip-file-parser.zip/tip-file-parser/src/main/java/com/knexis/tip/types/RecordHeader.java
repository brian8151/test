package com.knexis.tip.types;

import lombok.Getter;
import lombok.Setter;

/**
 * Common fixed-width header *data* present on every detail record:
 *  - recordType: cols 1–3 (e.g., "DFA")
 *  - seq:        cols 4–6 (e.g., 001/002/003)
 */
@Getter
@Setter
public abstract class RecordHeader extends OutboundDetailBase {
    private String  recordType;  // 1–3
    private Integer seq;         // 4–6
}