package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.OutboundDetail;

public interface DfaDetail extends OutboundDetail {
}
