package com.knexis.tip;

import com.knexis.tip.core.parser.DataLineParser;
import com.knexis.tip.extensions.formats.dfa.aggregation.DfaAggregator;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.extensions.formats.dfa.records.DfaDetail;
import com.knexis.tip.extensions.formats.dfa.records.DfaTransaction;
import com.knexis.tip.core.schema.OutboundFileSchema;
import com.knexis.tip.utils.SchemaLoader;
import lombok.extern.slf4j.Slf4j;

import java.nio.file.Paths;

/**
 * Entry point for running the Outbound File Parser as a standalone application.
 *
 * <p>This example loads the DFA (Direct Financial Activity) schema from the classpath
 * resource {@code direct-financial-activity.yml}, then parses an input file into
 * structured {@link DfaTransaction} objects.</p>
 *
 * <h3>Usage</h3>
 * <pre>
 *   java -cp target/tip-file-parser.jar com.knexis.tip.TapeInterfaceFileParser inputFilePath
 * </pre>
 *
 * <h3>Responsibilities</h3>
 * <ul>
 *   <li>Load the schema definition (YAML) using {@link SchemaLoader}.</li>
 *   <li>Initialize a {@link DataLineParser} with the loaded schema.</li>
 *   <li>Parse the provided input file into an {@link OutboundFile} of {@link DfaTransaction}.</li>
 *   <li>Print summary output for demonstration/debugging.</li>
 * </ul>
 *
 * <p>For real-world use, replace the hard-coded schema with a config-driven one,
 * and handle exceptions / logging appropriately.</p>
 */
@Slf4j
public class TapeInterfaceFileParser
{
    public static void main(String[] args) {
//        if (args.length == 0) {
//            System.err.println("Usage: TapeInterfaceFileParser <inputFilePath>");
//            System.exit(1);
//        }

        //String inputPath = args[0];
        String inputPath = "C:\\work\\jpmc\\ssc\\MFB.MBCMB002.TIPTest";

        String schemaPath = "direct-financial-activity.yml";

        System.out.println("Loading schema from resource: " + schemaPath);

        // 1. Load schema definition from resources
        OutboundFileSchema schema = SchemaLoader.loadFromResource(schemaPath);

        // 2. Initialize parser with schema
        DataLineParser parser = new DataLineParser(schema);

        // 3. Parse the input file using DFA aggregator -> OutboundFile<DfaTransaction>
        OutboundFile<DfaTransaction> file = parser.parse(
                Paths.get(inputPath),
                new DfaAggregator.Factory()
        );

        // 4. Print summary
        log.info("Schema loaded successfully.");
        log.info("Parsed header:  {}", file.getHeader());
        log.info("Parsed trailer: {}", file.getTrailer());
        log.info("Found {} DFA transactions.",file.getItems().size());
        int i = 1;
        for (DfaTransaction txn : file.getItems()) {
            log.info("Transaction {} has {} detail records:", i++, txn.getRecords().size());
            for (DfaDetail rec : txn.getRecords()) {
                log.info("  {} -> {}", rec.getClass().getSimpleName(), rec);
            }
        }
    }
}
