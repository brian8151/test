package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class RecordBody {
    private StartRecord startRecord;
    private String groupingKey;      // "constant" for single stream; extend to expressions if needed
    private List<RecordDef> records;
}
