package com.knexis.tip.core.parser;

import com.knexis.tip.core.exception.RecordParseException;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.core.exception.ValidationException;
import com.knexis.tip.core.schema.*;
import com.knexis.tip.extensions.aggregation.GroupAggregator;
import com.knexis.tip.extensions.aggregation.GroupAggregatorFactory;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;


/**
 * Generic fixed-width file parser driven by OutboundFileSchema.
 * - Instantiates sub-record POJOs using className from schema (or Map if absent)
 * - Groups body records via a pluggable GroupAggregator<T>
 */
public final class DataLineParser {

    private final OutboundFileSchema schema;

    public DataLineParser(OutboundFileSchema schema) {
        this.schema = Objects.requireNonNull(schema, "schema");
    }

    /* -------------------------------------------------------------------------------------------------------------- */
    /* Public API – typed aggregation                                                                                */
    /* -------------------------------------------------------------------------------------------------------------- */

    public <T> OutboundFile<T> parse(Path path, GroupAggregatorFactory<T> factory) {
        try (BufferedReader br = Files.newBufferedReader(path)) {
            return parse(br.lines().toList(), factory);
        } catch (IOException e) {
            throw new RecordParseException("I/O reading file: " + path, -1, "");
        }
    }

    public <T> OutboundFile<T> parse(List<String> lines, GroupAggregatorFactory<T> factory) {
        if (lines == null || lines.isEmpty()) {
            throw new ValidationException("Empty file");
        }

        final int expectedLen = Optional.ofNullable(schema.getRecordLength()).orElse(0);
        int idx = 0;

        // ===== HEADER =====
        final int headerLineNum = idx + 1;
        final String headerLine = lines.get(idx++);
        ensureTag(headerLine, schema.getHeader(), "header", idx);
        int headerMin = Validator.minRequiredLength(schema.getHeader().getFields());
        Validator.assertLength(headerLine, expectedLen, headerMin, idx);
        Map<String, Object> header = parseRecordSchema(headerLine, schema.getHeader());

        // ===== BODY PREP =====
        final var body = Objects.requireNonNull(schema.getBody(), "Schema body is null");
        final var defs = Objects.requireNonNull(body.getRecords(), "Body records are null");
        final StartRecord sr = body.getStartRecord(); // may be null

        if (sr != null && sr.getRecordRef() != null) {
            boolean exists = defs.stream().anyMatch(d -> Objects.equals(d.getId(), sr.getRecordRef()));
            if (!exists) throw new SchemaException("Start record ref not found: " + sr.getRecordRef());
        }

        final List<T> items = new ArrayList<>();
        GroupAggregator<T> current = null;

        // ===== BODY LOOP (leave last line for trailer) =====
        for (; idx < lines.size() - 1; idx++) {
            String line = lines.get(idx);

            // trailer? stop body parsing
            if (matchesTagSafely(line, schema.getTrailer().getTagField())) break;

            if (line.length() < 6) {
                throw new RecordParseException("Line too short to read tag/sequence", idx + 1, line);
            }

            RecordDef matched = matchRecord(defs, line);
            if (matched == null) {
                throw new RecordParseException("Unrecognized body record", idx + 1, line);
            }

            int bodyMin = Validator.minRequiredLength(matched.getFields());
            Validator.assertLength(line, expectedLen, bodyMin, idx + 1);

            // open group on start-record OR on first body line if no start configured
            boolean startsHere = isStartRecord(line, matched, sr);
            if (startsHere) {
                if (current != null) items.add(current.finish());
                current = factory.create();
            }
            if (current == null) { // no startRecord -> first body line starts group
                current = factory.create();
            }

            Object parsed = parseRecordDef(line, matched, idx + 1);
            current.onRecord(matched.getId(), parsed);
        }

        // ===== FLUSH LAST GROUP BEFORE TRAILER =====
        if (current != null) {
            items.add(current.finish());
        }

        // ===== TRAILER =====
        if (idx >= lines.size()) {
            throw new ValidationException("Missing trailer record");
        }
        final String trailerLine = lines.get(idx);

        ensureTag(trailerLine, schema.getTrailer(), "trailer", idx + 1);
        int trailerMin = Validator.minRequiredLength(schema.getTrailer().getFields());
        Validator.assertLength(trailerLine, expectedLen, trailerMin, idx + 1);
        Map<String, Object> trailer = parseRecordSchema(trailerLine, schema.getTrailer());


        return new OutboundFile<>(header, items, trailer);
    }

    private boolean matchesTagSafely(String line, TagField tagField) {
        if (line == null) return false;
        if (line.length() < tagField.getEnd()) return false; // too short to contain tag
        return matchesTag(line, tagField);
    }

    /**
     * check file meta per line while parsing
     * @param line
     * @param def
     * @param lineNumber
     * @return
     */
    private Object parseRecordDef(String line, RecordDef def, int lineNumber) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (FieldDef f : def.getFields()) {
            String raw = RecordTokenizer.slice(line, f.getStart(), f.getEnd());
            Object val = Transformers.convert(f, raw);
            map.put(f.getName(), val);
        }
        String className = def.getClassName();
        if (className == null || className.isBlank()) {
            // strict mode? If DFA requires typed records, throw here instead.
            return map;
        }
        try {
            Class<?> cls = Class.forName(className);
            Object bean = cls.getDeclaredConstructor().newInstance();
            BeanMapper.populate(bean, map);
            if (bean instanceof OutboundDetail od) {
                od.setRecordId(def.getId());
                od.setLineNumber(lineNumber);
//                if (bean instanceof OutboundDetailBase ofb) {
//                    ofb.setRawLine(line);
//                }
            }
            return bean;
        } catch (Exception e) {
            throw new SchemaException("Failed to instantiate " + className + " for " + def.getId(), e);
        }
    }

    /* -------------------------------------------------------------------------------------------------------------- */
    /* Internals                                                                                                     */
    /* -------------------------------------------------------------------------------------------------------------- */

    private static boolean matchesTag(String line, TagField tagField) {
        String tag = RecordTokenizer.slice(line, tagField.getStart(), tagField.getEnd());
        return tag.equals(tagField.getMatch());
    }

    private static void ensureTag(String line, RecordSchema rs, String which, int lineNum) {
        if (!matchesTag(line, rs.getTagField())) {
            throw new ValidationException("Invalid " + which + " tag at line " + lineNum);
        }
    }

    /** Start if
     * (a) recordRef matches the matched.id OR
     * (b) tag+sequence equals the configured values.
     * */
    private boolean isStartRecord(String line, RecordDef matched, StartRecord sr) {
        if (sr == null) return false;

        // by record id (recordRef)
        if (sr.getRecordRef() != null && matched != null && sr.getRecordRef().equals(matched.getId())) {
            return true;
        }
        // by tag+sequence (requires 1–6 available)
        if (sr.getTag() != null && sr.getSequence() != null && line.length() >= 6) {
            String tag = RecordTokenizer.slice(line, 1, 3);
            String seq = RecordTokenizer.slice(line, 4, 6);
            return sr.getTag().equals(tag) && sr.getSequence().equals(seq);
        }
        return false;
    }

    private RecordDef matchRecord(List<RecordDef> defs, String line) {
        for (RecordDef d : defs) {
            if (rangeMatch(line, d.getTag()) && rangeMatch(line, d.getSequence())) {
                return d;
            }
        }
        return null;
    }

    private boolean rangeMatch(String line, RangeMatch rm) {
        if (rm == null) return true;
        String s = RecordTokenizer.slice(line, rm.getStart(), rm.getEnd());
        return Objects.equals(s, rm.getMatch());
    }

    private Map<String, Object> parseRecordSchema(String line, RecordSchema rs) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (FieldDef f : rs.getFields()) {
            String raw = RecordTokenizer.slice(line, f.getStart(), f.getEnd());
            Object val = Transformers.convert(f, raw);
            map.put(f.getName(), val);
        }
        return map;
    }

}
