package com.knexis.tip.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.core.schema.OutboundFileSchema;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Loads a YAML schema into FileSchema. */
@Slf4j
public final class SchemaLoader {

    private static final ObjectMapper YAML = new ObjectMapper(new YAMLFactory());

    private SchemaLoader() { }

    public static OutboundFileSchema load(Path yamlPath) {
        try (InputStream in = Files.newInputStream(yamlPath)) {
            log.debug("Loading schema from path: {}", yamlPath);
            return load(in);
        } catch (IOException e) {
            String msg = "Failed to load schema from: " + yamlPath;
            log.error(msg, e);
            throw new SchemaException(msg, e);
        } catch (SchemaException se) {
            // bubble up with context already logged
            throw se;
        } catch (Exception ex) {
            String msg = "Unexpected error loading schema from: " + yamlPath;
            log.error(msg, ex);
            throw new SchemaException(msg, ex);
        }
    }

    public static OutboundFileSchema load(InputStream yamlStream) {
        try {
            OutboundFileSchema schema = YAML.readValue(yamlStream, OutboundFileSchema.class);
            if (schema == null) {
                throw new SchemaException("Schema parsed to null");
            }
            log.debug("Schema loaded successfully: {}", schema);
            return schema;
        } catch (IOException e) {
            String msg = "Failed to parse schema YAML";
            log.error(msg, e);
            throw new SchemaException(msg, e);
        } catch (SchemaException se) {
            // bubble up with context already logged
            throw se;
        } catch (Exception ex) {
            String msg = "Unexpected error parsing schema YAML";
            log.error(msg, ex);
            throw new SchemaException(msg, ex);
        }
    }
    public static OutboundFileSchema loadFromResource(String resourceName) {
        InputStream in = SchemaLoader.class.getClassLoader().getResourceAsStream(resourceName);
        if (in == null) {
            throw new SchemaException("Schema resource not found on classpath: " + resourceName);
        }
        return load(in);
    }
}