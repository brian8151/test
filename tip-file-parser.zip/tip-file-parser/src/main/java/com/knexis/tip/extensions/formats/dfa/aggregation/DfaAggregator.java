package com.knexis.tip.extensions.formats.dfa.aggregation;

import com.knexis.tip.extensions.aggregation.GroupAggregator;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.extensions.aggregation.GroupAggregatorFactory;
import com.knexis.tip.extensions.formats.dfa.records.DfaDetail;
import com.knexis.tip.extensions.formats.dfa.records.DfaTransaction;

public class DfaAggregator implements GroupAggregator<DfaTransaction> {
    private final DfaTransaction tx = new DfaTransaction();

    @Override
    public void onRecord(String recordId, Object record) {
        if (record instanceof DfaDetail) {
            tx.add((DfaDetail) record);      // keep order as in file
        } else {
            // Strict mode: every record must be a DFA POJO, not a Map
            throw new SchemaException(
                    "Unexpected record type for " + recordId + ". className in the schema is required"
            );
        }
    }

    @Override
    public DfaTransaction finish() { return tx; }

    public static class Factory implements GroupAggregatorFactory<DfaTransaction> {
        @Override public GroupAggregator<DfaTransaction> create() { return new DfaAggregator(); }
    }
}