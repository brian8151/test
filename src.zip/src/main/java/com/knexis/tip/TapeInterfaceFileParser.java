package com.knexis.tip;

import com.knexis.tip.core.parser.DataLineParser;
import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.utils.HeaderPeek;
import com.knexis.tip.utils.SchemaLoader;
import lombok.extern.slf4j.Slf4j;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Entry point for running the Outbound File Parser as a standalone application.
 *
 * <p>This example loads the DFA (Direct Financial Activity) schema from the classpath
 * resource {@code direct-financial-activity.yml}, then parses an input file into
 * structured {@link TransactionGroup} objects.</p>
 *
 * <h3>Usage</h3>
 * <pre>
 *   java -cp target/tip-file-parser.jar com.knexis.tip.TapeInterfaceFileParser inputFilePath
 * </pre>
 *
 * <h3>Responsibilities</h3>
 * <ul>
 *   <li>Load the schema definition (YAML) using {@link SchemaLoader}.</li>
 *   <li>Initialize a {@link DataLineParser} with the loaded schema.</li>
 *   <li>Parse the provided input file into an {@link OutboundFile} of {@link TransactionGroup}.</li>
 *   <li>Print summary output for demonstration/debugging.</li>
 * </ul>
 *
 * <p>For real-world use, replace the hard-coded schema with a config-driven one,
 * and handle exceptions / logging appropriately.</p>
 */
@Slf4j
public class TapeInterfaceFileParser
{
    public static void main(String[] args)  throws Exception {
//        if (args.length == 0) {
//            System.err.println("Usage: TapeInterfaceFileParser <inputFilePath>");
//            System.exit(1);
//        }

        //String inputPath = args[0];
        String inputPath = "C:\\work\\jpmc\\ssc\\MFB.MBCMB002a.TIPTest";
        final Path input = Path.of(inputPath);

        SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        // 2) Peek the header and detect file type
        var preview = HeaderPeek.read(input);
        if (!"RHR".equals(preview.recordType())) {
            throw new IllegalArgumentException("Not a TIP outbound file (recordType=" + preview.recordType() + ")");
        }
        List<String> lines = Files.readAllLines(input);
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(registry);
        ParseDispatcher.Result result = dispatcher.dispatch(input, lines);

        log.info("Detected type: {}", result.fileTypeId());
        var file = result.cast(TransactionGroup.class);
        log.info("Header: {}", result.file().getHeader());
        log.info("Trailer: {}", result.file().getTrailer());
        log.info("Transactions: {}", result.file().getItems().size());
        int i = 1;
        for (TransactionGroup tx : file.getItems()) {
            log.info("Txn {} has {} details", i++, tx.details().size());
            for (Object detail : tx.details()) {
                // Shows the concrete class (e.g., DfaRecord1) and its toString()
                log.info("   {} -> {}", detail.getClass().getSimpleName(), detail);
            }
        }
    }
}
