package com.knexis.tip.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.core.schema.OutboundFileSchema;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/** Loads a YAML schema into FileSchema. */
@Slf4j
public final class SchemaLoader {

    private static final ObjectMapper YAML = new ObjectMapper(new YAMLFactory());

    private SchemaLoader() { }

    /** Load a schema from a filesystem path; supports extendsResource inside the YAML. */
    public static OutboundFileSchema load(Path yamlPath) {
        try (InputStream in = Files.newInputStream(yamlPath)) {
            log.debug("Loading schema from path: {}", yamlPath);
            OutboundFileSchema parsed = parseYaml(in, "file:" + yamlPath);
            OutboundFileSchema resolved = resolveExtends(parsed, new HashSet<>());
            log.debug("Schema loaded+resolved (from path): {}", resolved);
            return resolved;
        } catch (IOException e) {
            String msg = "Failed to load schema from: " + yamlPath;
            log.error(msg, e);
            throw new SchemaException(msg, e);
        } catch (SchemaException se) {
            throw se; // already logged
        } catch (Exception ex) {
            String msg = "Unexpected error loading schema from: " + yamlPath;
            log.error(msg, ex);
            throw new SchemaException(msg, ex);
        }
    }

    /** Load a schema from an InputStream; supports extendsResource inside the YAML. */
    public static OutboundFileSchema load(InputStream yamlStream) {
        try {
            OutboundFileSchema parsed = parseYaml(yamlStream, "stream");
            OutboundFileSchema resolved = resolveExtends(parsed, new HashSet<>());
            log.debug("Schema loaded+resolved (from stream): {}", resolved);
            return resolved;
        } catch (IOException e) {
            String msg = "Failed to parse schema YAML";
            log.error(msg, e);
            throw new SchemaException(msg, e);
        } catch (SchemaException se) {
            throw se;
        } catch (Exception ex) {
            String msg = "Unexpected error parsing schema YAML";
            log.error(msg, ex);
            throw new SchemaException(msg, ex);
        }
    }

    /** Load a schema from the classpath; supports extendsResource chaining. */
    public static OutboundFileSchema loadFromResource(String resourceName) {
        try (InputStream in = getResourceAsStream(resourceName)) {
            log.debug("Loading schema from resource: {}", resourceName);
            OutboundFileSchema parsed = parseYaml(in, "cp:" + resourceName);
            OutboundFileSchema resolved = resolveExtends(parsed, new HashSet<>());
            log.debug("Schema loaded+resolved (from resource): {}", resolved);
            return resolved;
        } catch (IOException e) {
            String msg = "Failed to load schema from resource: " + resourceName;
            log.error(msg, e);
            throw new SchemaException(msg, e);
        }
    }
    /**
     * Resolve extendsResource recursively. Child overrides base where non-null.
     * Protect against cycles (A -> B -> A).
     */
    private static OutboundFileSchema resolveExtends(OutboundFileSchema child, Set<String> seen) {
        String extendsRes = trimToNull(child.getCommonResource());
        if (extendsRes == null) return child;

        if (!seen.add(extendsRes)) {
            throw new SchemaException("Circular schema inheritance detected at: " + extendsRes);
        }

        OutboundFileSchema base;
        try (InputStream in = getResourceAsStream(extendsRes)) {
            base = parseYaml(in, "cp:" + extendsRes);
        } catch (IOException e) {
            String msg = "Failed to load base schema from resource: " + extendsRes;
            log.error(msg, e);
            throw new SchemaException(msg, e);
        }

        // Resolve parent chain first, then merge base <- child
        OutboundFileSchema resolvedBase = resolveExtends(base, seen);
        OutboundFileSchema merged = merge(resolvedBase, child);

        // Clear extends on result to avoid accidental reuse
        merged.setCommonResource(null);
        return merged;
    }
    /**
     * Merge base and child: child wins if non-null; base otherwise.
     * Shallow merge is sufficient for our DSL: header/trailer/body are replaced as whole blocks.
     */
    private static OutboundFileSchema merge(OutboundFileSchema base, OutboundFileSchema child) {
        Objects.requireNonNull(base, "base schema");
        Objects.requireNonNull(child, "child schema");

        OutboundFileSchema out = new OutboundFileSchema();
        out.setFileType(nvl(child.getFileType(), base.getFileType()));
        out.setRecordLength(nvl(child.getRecordLength(), base.getRecordLength()));
        out.setHeader(nvl(child.getHeader(), base.getHeader()));
        out.setTrailer(nvl(child.getTrailer(), base.getTrailer()));
        out.setBody(nvl(child.getBody(), base.getBody()));
        return out;
    }

    private static <T> T nvl(T a, T b) { return (a != null ? a : b); }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static InputStream getResourceAsStream(String resourceName) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        InputStream in = (cl != null) ? cl.getResourceAsStream(resourceName)
                : SchemaLoader.class.getClassLoader().getResourceAsStream(resourceName);
        if (in == null) {
            throw new SchemaException("Schema resource not found on classpath: " + resourceName);
        }
        return in;
    }

    private static OutboundFileSchema parseYaml(InputStream in, String origin) throws IOException {
        OutboundFileSchema schema = YAML.readValue(in, OutboundFileSchema.class);
        if (schema == null) {
            throw new SchemaException("Schema parsed to null (" + origin + ")");
        }
        return schema;
    }
    public static <T> T parseYamlFromResource(String resourceName, Class<T> type) {
        try (InputStream in = getResourceAsStream(resourceName)) {
            return YAML.readValue(in, type);
        } catch (IOException e) {
            throw new SchemaException("Failed to load schema from resource: " + resourceName, e);
        }
    }
}