package com.knexis.tip.utils;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.share.TransactionUnit;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public final class TransactionPrinter {

    private TransactionPrinter() {}

    /** Print parsed file with all groups and their details. */
    public static void printFile(OutboundFile<TransactionGroup> file) {
        int i = 1;
        log.info("Transactions: {}", file.getItems().size());
        for (TransactionGroup tx : file.getItems()) {
            log.info("Txn {} has {} details", i++, tx.details().size());
            for (OutboundDetail detail : tx.details()) {
                log.info("   {} -> {}",
                        detail.getClass().getSimpleName(),
                        detail.toString());
            }
        }
    }

    /** Print post-processed units with all member groups + details. */
    public static void printUnits(List<TransactionUnit<TransactionGroup>> units) {
        int n = 1;
        for (var u : units) {
            log.info("Unit #{} -> {} : {} (members={})",
                    n++, u.kind(), u.reason(), u.members().size());

            int m = 1;
            for (TransactionGroup member : u.members()) {
                log.info("   Member {} has {} details", m++, member.details().size());
                for (OutboundDetail detail : member.details()) {
                    log.info("      {} -> {}",
                            detail.getClass().getSimpleName(),
                            detail.toString());
                }
            }
        }
    }
}