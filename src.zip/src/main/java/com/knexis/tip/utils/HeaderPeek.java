package com.knexis.tip.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class HeaderPeek {
    private HeaderPeek() {}

    /** 1-based inclusive slice, safe on short lines. */
    public static String slice(String line, int start, int end) {
        if (line == null) return "";
        int s = Math.max(0, start - 1);
        int e = Math.min(line.length(), end);
        return (s < e) ? line.substring(s, e) : "";
    }

    public static Preview read(Path path) {
        try {
            List<String> lines = Files.readAllLines(path);
            if (lines.isEmpty()) throw new IllegalArgumentException("Empty file: " + path);
            String h = lines.get(0);
            return new Preview(
                    h,
                    slice(h, 1, 3).trim(),    // RHR
                    slice(h, 4, 6).trim(),
                    slice(h, 7, 21).trim(),   // FINANCIALDIRECT
                    slice(h, 46, 53).trim()   // Job Name (optional)
            );
        } catch (IOException e) {
            throw new RuntimeException("Failed to read header of " + path, e);
        }
    }

    public record Preview(String raw, String recordType, String seq, String fileTypeText, String jobName) {}
}