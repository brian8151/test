package com.knexis.tip.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public final class HeaderPeek {
    private HeaderPeek() {}

    /** 1-based inclusive slice, safe on short lines. */
    public static String slice(String line, int start, int end) {
        if (line == null) return "";
        int s = Math.max(0, start - 1);
        int e = Math.min(line.length(), end);
        return (s < e) ? line.substring(s, e) : "";
    }

    public static Preview read(Path path) {
        try {
            List<String> lines = Files.readAllLines(path);
            if (lines.isEmpty()) throw new IllegalArgumentException("Empty file: " + path);
            String h = lines.getFirst();
            return new Preview(
                    h,
                    slice(h, 1, 3).trim(),    // RHR
                    slice(h, 4, 6).trim(),
                    slice(h, 7, 21).trim(),   // FINANCIALDIRECT
                    slice(h, 46, 53).trim()   // Job Name (optional)
            );
        } catch (IOException e) {
            throw new RuntimeException("Failed to read header of " + path, e);
        }
    }
    public static Preview read(List<String> lines) {
        if (lines == null || lines.isEmpty()) throw new IllegalArgumentException("Empty input");
        String h = lines.getFirst();
        return parseHeader(h);
    }
    public static Preview read(InputStream in) {
        return read(in, StandardCharsets.UTF_8);
    }
    public static Preview read(InputStream in, Charset charset) {
        if (in == null) throw new IllegalArgumentException("InputStream is null");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, charset))) {
            String h = br.readLine();
            if (h == null) throw new IllegalArgumentException("Empty input");
            return parseHeader(h);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to read header from stream", e);
        }
    }
    private static Preview parseHeader(String h) {
        return new Preview(
                h,
                slice(h, 1, 3).trim(),   // RHR
                slice(h, 4, 6).trim(),
                slice(h, 7, 21).trim(),  // FINANCIALDIRECT
                slice(h, 46, 53).trim()  // Job Name (optional)
        );
    }
    public record Preview(String raw, String recordType, String seq, String fileTypeText, String jobName) {}
}