package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;
@Getter
@Setter
@ToString(callSuper = true)
public class DfaRecord3 extends RecordHeader {
    private Integer contributionYear;        // 7–10
    private Integer fundFromCode;            // 11–17
    private Long accountFromTo;              // 18–28
    private String voluntaryTxnDesc;         // 29–54
    private String customerAccountNumber;    // 55–74
    private String accountNumberCode;        // 75
    private LocalDate superSheetDate;        // 76–83
    private Long bankMicrId;                 // 84–92
    private Long bankAccountNumber;          // 93–109
    private String liquidationCode;          // 110
    private String tradeEntryMethod;         // 111
    private Integer tradeOriginId;           // 112–118
    private Long mfTxnId1;                   // 119–129
    private Long mfTxnId2;                   // 130–140
    private String trustCompanyNumber;       // 141–144
    private String tpaNumber;                // 145–148
    private String clientDefinedField;       // 149–156
    private String filler;                   // 157–160
}