package com.knexis.tip.extensions.formats;

import com.knexis.tip.types.OutboundDetail;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** One logical DFA transaction = ordered list of DFA detail sub-records. */
public class TransactionGroup implements OutboundTransaction<OutboundDetail> {

    // Internal storage; prefer immutable exposure
    private final List<OutboundDetail> details = new ArrayList<>();

    /** Aggregator will call this. */
    @Override
    public void add(OutboundDetail d) {
        details.add(d);
    }

    /** Parser/consumers call this to read details. */
    @Override
    public List<OutboundDetail> details() {
        return Collections.unmodifiableList(details);
    }

    /** Convenience: all details of a specific DFA record type (preserves order). */
    public <T extends OutboundDetail> List<T> ofType(Class<T> type) {
        List<T> out = new ArrayList<>();
        for (OutboundDetail d : details) {
            if (type.isInstance(d)) out.add(type.cast(d));
        }
        return out;
    }

    /** Convenience: first detail of given type, or null. */
    public <T extends OutboundDetail> T firstOf(Class<T> type) {
        for (OutboundDetail d : details) {
            if (type.isInstance(d)) return type.cast(d);
        }
        return null;
    }

    /** @deprecated Use {@link #details()} */
    @Deprecated
    public List<OutboundDetail> getRecords() { return details(); }

    /** @deprecated Use {@link #ofType(Class)} */
    @Deprecated
    public <T extends OutboundDetail> List<T> getRecordsOfType(Class<T> type) { return ofType(type); }
}