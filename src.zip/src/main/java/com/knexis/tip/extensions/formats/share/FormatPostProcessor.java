package com.knexis.tip.extensions.formats.share;

import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.types.RecordHeader;

import java.util.ArrayList;
import java.util.List;

public interface FormatPostProcessor {
    /**
     * Process a parsed TIP file into format-specific {@link TransactionUnit}s.
     *
     * <p><b>Default:</b> No-op — emits one UNKNOWN unit per input item.</p>
     *
     * @param fileTypeId header file type id (e.g., "FINANCIALDIRECT")
     * @param file       parsed file with grouped transactions
     * @param <T>        item type (usually {@code TransactionGroup})
     * @return list of produced units (may be empty)
     */
    default <T> List<TransactionUnit<T>> process(String fileTypeId, OutboundFile<T> file) {
        List<TransactionUnit<T>> out = new ArrayList<>();
        for (T t : file.getItems()) {
            out.add(new TransactionUnit<>(TxnKind.UNKNOWN, List.of(t),
                    "no post-processor for " + fileTypeId));
        }
        return out;
    }
}
