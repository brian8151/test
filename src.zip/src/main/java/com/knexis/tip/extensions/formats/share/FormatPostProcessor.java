package com.knexis.tip.extensions.formats.share;

import com.knexis.tip.types.OutboundFile;

import java.util.List;

public interface FormatPostProcessor {
    <T> List<TransactionUnit<T>> process(String fileTypeId, OutboundFile<T> file);
}
