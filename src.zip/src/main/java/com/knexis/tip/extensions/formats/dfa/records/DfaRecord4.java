package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString(callSuper = true)
public class DfaRecord4 extends RecordHeader {
    private Long clientReferenceNumber;      // 7–19
    private String merchantDescription;      // 20–59
    private Integer custodianId;             // 60–66
    private Integer tpaId;                   // 67–73
    private BigDecimal advCommissionAmount;  // 74–88 (scale 2)
    private String nsccBranchId;             // 89–97
    private Integer navReasonCode;           // 98
    private String clientDefinedText;        // 99–108
    private String alphaMasked;              // 109–118
    private String fromToCustomerAcct;       // 119–138
    private String fromToCusip;              // 139–147
    private String operatorId;               // 148–155
    private String nsccIraCode;              // 156
    private String filler;                   // 157–160
}