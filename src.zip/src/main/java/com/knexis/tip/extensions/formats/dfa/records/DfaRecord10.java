package com.knexis.tip.extensions.formats.dfa.records;

import com.knexis.tip.types.RecordHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * DFA-010 Record
 * Tenth detail record for Direct Financial Activity.
 */
@Getter
@Setter
@ToString(callSuper = true)
public class DfaRecord10 extends RecordHeader {

    // 7–10
    private String finIntermediaryAbbr;

    // 11–14
    private String custodianAbbr;

    // 15–18
    private String tpaAbbr;

    // 19–29
    private Long eventId1;

    // 30–40
    private Long eventId2;

    // 41–66 (raw timestamp string: YYYY-MM-DD-HH.MM.SS. + millis)
    private String tradeTimestamp;

    // 67–70
    private Integer effectivePriceDateYear;

    // 71–72
    private Integer effectivePriceDateMonth;

    // 73–74
    private Integer effectivePriceDateDay;

    // 75–76
    private Integer effectivePriceTimeHour;

    // 77–78
    private Integer effectivePriceTimeMinute;

    // 79–80
    private Integer strikeHour;

    // 81–82
    private Integer strikeMinute;

    // 83
    private String timeZoneCode;

    // 84
    private String liquidityFeeResp;

    // 85–160
    private String filler;

    // Meta info from OutboundDetail
    private String recordId;
    private Integer lineNumber;
}