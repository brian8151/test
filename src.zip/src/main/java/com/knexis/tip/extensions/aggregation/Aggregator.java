package com.knexis.tip.extensions.aggregation;

import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.extensions.formats.OutboundTransaction;
import com.knexis.tip.types.OutboundDetail;

import java.util.Objects;
import java.util.function.Supplier;

public class Aggregator <TX extends OutboundTransaction<OutboundDetail>>
        implements GroupAggregator<TX> {

    private final TX tx;
    private final String groupPrefix; // e.g., "DFA" or null to accept all

    public Aggregator(TX tx, String groupPrefix) {
        this.tx = tx;
        this.groupPrefix = (groupPrefix != null && !groupPrefix.isBlank()) ? groupPrefix : null;
    }

    @Override
    public void onRecord(String recordId, Object record) {
        if (!(record instanceof OutboundDetail d)) {
            throw new SchemaException("Record did not implement OutboundDetail (id=" + recordId + ")");
        }
        if (groupPrefix != null) {
            String rid = d.getRecordId();
            if (rid == null || !rid.startsWith(groupPrefix)) {
                throw new SchemaException("Detail belongs to different group: " + rid + " (expected " + groupPrefix + ")");
            }
        }
        tx.add(d);
    }

    @Override public TX finish() { return tx; }

    /** Factory to plug into DataLineParser.parse(...) */
    public static final class Factory<TX extends OutboundTransaction<OutboundDetail>>
            implements GroupAggregatorFactory<TX> {

        private final Supplier<TX> supplier;
        private String groupPrefix;

        public Factory(Supplier<TX> supplier) {
            this.supplier = Objects.requireNonNull(supplier, "supplier");
        }

        /** Optional: enforce a group prefix like "DFA". */
        public Factory<TX> withGroupPrefix(String prefix) {
            this.groupPrefix = prefix;
            return this;
        }

        @Override
        public GroupAggregator<TX> create() {
            return new Aggregator<>(supplier.get(), groupPrefix);
        }
    }
}