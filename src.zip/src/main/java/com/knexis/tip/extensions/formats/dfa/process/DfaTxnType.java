package com.knexis.tip.extensions.formats.dfa.process;

public enum DfaTxnType {
    SUBSCRIPTION,
    REDEMPTION,
    TRANSFER,
    UNKNOWN
}