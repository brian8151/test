package com.knexis.tip.extensions.aggregation;

// One logical “group” in the file (e.g., a DFA transaction)
public interface GroupAggregator<T> {
    /** Called for each body record in a group in the order encountered. */
    void onRecord(String recordId, Object record);

    /** Called once when the group ends; return the completed aggregate. */
    T finish();
}
