package com.knexis.tip.extensions.formats.share;

import java.util.Objects;

/** Extensible, namespaced transaction kind (e.g., DFA:SUBSCRIPTION, OFX:PAYMENT, …). */
public final class TxnKind {
    private final String namespace;  // e.g., "DFA", "OFX", "GENERIC"
    private final String code;       // e.g., "SUBSCRIPTION", "REDEMPTION", "TRANSFER"

    private TxnKind(String namespace, String code) {
        this.namespace = namespace;
        this.code = code;
    }

    public static TxnKind of(String namespace, String code) {
        return new TxnKind(
                Objects.requireNonNull(namespace, "namespace").toUpperCase(),
                Objects.requireNonNull(code, "code").toUpperCase()
        );
    }

    /** A fallback when no format-specific label applies. */
    public static final TxnKind UNKNOWN = TxnKind.of("GENERIC", "UNKNOWN");

    public String namespace() {
        return namespace;
    }
    public String code()      {
        return code;
    }

    /** Handy checks */
    public boolean is(String ns, String code) {
        return this.namespace.equalsIgnoreCase(ns) && this.code.equalsIgnoreCase(code);
    }
    public boolean isNamespace(String ns) {
        return this.namespace.equalsIgnoreCase(ns);
    }
    public boolean isCode(String code)    {
        return this.code.equalsIgnoreCase(code);
    }

    @Override public String toString() {
        return namespace + ":" + code;
    }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TxnKind k)) return false;
        return namespace.equals(k.namespace) && code.equals(k.code);
    }
    @Override public int hashCode() {
        return Objects.hash(namespace, code);
    }
}