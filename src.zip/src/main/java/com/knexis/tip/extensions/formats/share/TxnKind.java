package com.knexis.tip.extensions.formats.share;

import java.util.Objects;

/**
 * Value object for an extensible, namespaced transaction kind, e.g.:
 * <ul>
 *   <li>{@code DFA:SUBSCRIPTION}</li>
 *   <li>{@code DFA:REDEMPTION}</li>
 *   <li>{@code DFA:TRANSFER}</li>
 *   <li>{@code OFX:PAYMENT}</li>
 * </ul>
 *
 * <p>Use {@link #of(String, String)} to construct; inputs are normalized to UPPERCASE.
 * Equality is based on both fields (already uppercased), and convenience predicates
 * provide case-insensitive checks.</p>
 *
 * <h3>Why namespacing?</h3>
 * Different formats can reuse the same code safely (e.g., {@code DFA:TRANSFER} vs
 * {@code OFX:TRANSFER}). This avoids collisions and keeps logs unambiguous.</h3>
 *
 * <h3>Examples</h3>
 * <pre>{@code
 * TxnKind k1 = TxnKind.of("DFA", "Transfer");
 * TxnKind k2 = TxnKind.of("dfa", "TRANSFER");
 * assert k1.equals(k2);           // true, normalized to "DFA:TRANSFER"
 *
 * k1.is("dfa", "transfer");       // true (case-insensitive predicate)
 * k1.isNamespace("DFA");          // true
 * k1.isCode("TRANSFER");          // true
 *
 * TxnKind.UNKNOWN.toString();     // "GENERIC:UNKNOWN"
 * }</pre>
 *
 * <p><b>Immutability:</b> instances are immutable and safe to cache/use as map keys.</p>
 */
public final class TxnKind {
    private final String namespace;  // e.g., "DFA", "OFX", "GENERIC"
    private final String code;       // e.g., "SUBSCRIPTION", "REDEMPTION", "TRANSFER"

    private TxnKind(String namespace, String code) {
        this.namespace = namespace;
        this.code = code;
    }

    public static TxnKind of(String namespace, String code) {
        return new TxnKind(
                Objects.requireNonNull(namespace, "namespace").toUpperCase(),
                Objects.requireNonNull(code, "code").toUpperCase()
        );
    }

    /** A fallback when no format-specific label applies. */
    public static final TxnKind UNKNOWN = TxnKind.of("GENERIC", "UNKNOWN");

    /** The kind's namespace (format family), e.g., {@code "DFA"}. */
    public String namespace() { return namespace; }
    /** The kind's code within the namespace, e.g., {@code "TRANSFER"}. */
    public String code()      { return code; }


    /** Handy checks */
    /** Case-insensitive match on both namespace and code. */
    public boolean is(String ns, String code) {
        return this.namespace.equalsIgnoreCase(ns) && this.code.equalsIgnoreCase(code);
    }
    /** Case-insensitive namespace check. */
    public boolean isNamespace(String ns) {
        return this.namespace.equalsIgnoreCase(ns);
    }
    /** Case-insensitive code check. */
    public boolean isCode(String code) {
        return this.code.equalsIgnoreCase(code);
    }

    @Override public String toString() {
        return namespace + ":" + code;
    }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TxnKind k)) return false;
        return namespace.equals(k.namespace) && code.equals(k.code);
    }
    @Override public int hashCode() {
        return Objects.hash(namespace, code);
    }
}