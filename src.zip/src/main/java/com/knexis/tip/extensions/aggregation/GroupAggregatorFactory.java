package com.knexis.tip.extensions.aggregation;

public interface GroupAggregatorFactory<T> {
    GroupAggregator<T> create();
}