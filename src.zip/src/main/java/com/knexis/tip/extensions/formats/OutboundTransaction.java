package com.knexis.tip.extensions.formats;

import com.knexis.tip.types.OutboundDetail;
import java.util.List;

/** Transaction; */
public interface OutboundTransaction<D extends OutboundDetail> {
    void add(D d);
    List<D> details();
}
