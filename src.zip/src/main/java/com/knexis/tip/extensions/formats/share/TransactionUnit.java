package com.knexis.tip.extensions.formats.share;

import java.util.List;

public final class TransactionUnit<T> {
    private final TxnKind kind;       // namespaced kind
    private final List<T> members;    // one for SUB/RED; two for TRANSFER
    private final String reason;      // for logs / debugging

    public TransactionUnit(TxnKind kind, List<T> members, String reason) {
        this.kind = kind;
        this.members = List.copyOf(members);
        this.reason = reason;
    }
    public TxnKind kind()      { return kind; }
    public List<T> members()   { return members; }
    public String reason()     { return reason; }
}