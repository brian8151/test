package com.knexis.tip.extensions.formats.share;

import java.util.List;
/**
 * Immutable unit of post-processed output representing one logical transaction.
 *
 * <p>A unit wraps:</p>
 * <ul>
 *   <li>{@link #kind}: the final, namespaced classification (e.g., {@code DFA:TRANSFER}).</li>
 *   <li>{@link #members}: the contributing parsed items (usually {@code TransactionGroup}s).
 *       For DFA:
 *       <ul>
 *         <li>SUBSCRIPTION / REDEMPTION → size 1</li>
 *         <li>TRANSFER → size 2 (paired ADD↔SUB)</li>
 *       </ul>
 *   </li>
 *   <li>{@link #reason}: short human-readable explanation for logs/debugging
 *       (e.g., {@code "paired by DFA-010 (id1,id2)"}).</li>
 * </ul>
 *
 * <h3>Construction</h3>
 * The constructor defensively copies {@code members} to an unmodifiable list. It does not
 * enforce size constraints; callers (post-processors) should follow format-specific norms.
 *
 * <h3>Example</h3>
 * <pre>{@code
 * // Single-side classification:
 * TransactionUnit<TransactionGroup> u1 =
 *     new TransactionUnit<>(TxnKind.of("DFA", "SUBSCRIPTION"), List.of(tx), "DFA001=A");
 *
 * // Paired transfer:
 * TransactionUnit<TransactionGroup> u2 =
 *     new TransactionUnit<>(TxnKind.of("DFA", "TRANSFER"), List.of(txAdd, txSub), "paired by DFA-010 (e1,e2)");
 * }</pre>
 *
 * @param <T> element type for members (commonly {@code TransactionGroup})
 */
public final class TransactionUnit<T> {
    private final TxnKind kind;       // namespaced kind
    private final List<T> members;    // one for SUB/RED; two for TRANSFER
    private final String reason;      // for logs / debugging

    public TransactionUnit(TxnKind kind, List<T> members, String reason) {
        this.kind = kind;
        this.members = List.copyOf(members);
        this.reason = reason;
    }
    /** Final classification of this unit (e.g., {@code DFA:TRANSFER}). */
    public TxnKind kind()      { return kind; }
    /** Contributing parsed item(s). Unmodifiable. */
    public List<T> members()   { return members; }
    /** Short explanation: why this unit has this kind. Suitable for logs. */
    public String reason()     { return reason; }
}