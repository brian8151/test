package com.knexis.tip.extensions.formats.dfa.process;

import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord1;
import com.knexis.tip.extensions.formats.dfa.records.DfaRecord10;
import com.knexis.tip.extensions.formats.share.FormatPostProcessor;
import com.knexis.tip.extensions.formats.share.TransactionKindAware;
import com.knexis.tip.extensions.formats.share.TransactionUnit;
import com.knexis.tip.extensions.formats.share.TxnKind;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;

import java.util.*;


/**
 * DFA-specific post processor:
 * - Uses DFA001 shareBalanceEffect (A/S/N) for SUB/RED/UNKNOWN
 * - Pairs transfers using DFA010 (eventId1,eventId2)
 * - Produces TransactionUnit<T> with namespaced TxnKind ("DFA:SUBSCRIPTION", etc.)
 */
public final class DfaPostProcessor implements FormatPostProcessor {

    /** Centralized DFA kinds. */
    public static final class DfaKinds {
        public static final TxnKind SUBSCRIPTION = TxnKind.of("DFA", "SUBSCRIPTION");
        public static final TxnKind REDEMPTION   = TxnKind.of("DFA", "REDEMPTION");
        public static final TxnKind TRANSFER     = TxnKind.of("DFA", "TRANSFER");
    }

    private static final class TxInfo {
        final int idx;                     // 1-based order in file
        final TransactionGroup tx;
        Effect effect = Effect.UNKNOWN;    // derived from DFA-001
        EventKey eventKey;                 // derived from DFA-010 (may be null)
        boolean consumed;                  // used during pairing
        TxInfo(int idx, TransactionGroup tx) { this.idx = idx; this.tx = tx; }
    }

    private enum Effect { ADD, SUB, NONE, UNKNOWN }

    /** Pairing key for DFA-010. */
    private static final class EventKey {
        final Long id1, id2;
        EventKey(Long id1, Long id2) { this.id1 = id1; this.id2 = id2; }
        boolean valid() { return id1 != null && id2 != null; }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof EventKey k)) return false;
            return Objects.equals(id1, k.id1) && Objects.equals(id2, k.id2);
        }
        @Override public int hashCode() { return Objects.hash(id1, id2); }
        @Override public String toString() { return "(" + id1 + "," + id2 + ")"; }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> List<TransactionUnit<T>> process(String fileTypeId, OutboundFile<T> file) {
        // Only handle DFA here; other file types should have their own processors.
        if (!"FINANCIALDIRECT".equals(fileTypeId)) {
            List<TransactionUnit<T>> out = new ArrayList<>();
            for (T t : file.getItems()) {
                out.add(new TransactionUnit<>(TxnKind.UNKNOWN, List.of(t), "no DFA post-processor"));
            }
            return out;
        }

        // Build TxInfo list from parsed TransactionGroup items
        List<TxInfo> infos = new ArrayList<>();
        int i = 1;
        for (T t : file.getItems()) {
            if (!(t instanceof TransactionGroup tg)) continue; // defensive
            TxInfo info = new TxInfo(i++, tg);
            info.effect   = extractEffect(tg);
            info.eventKey = extractEventKey(tg);
            infos.add(info);
        }

        // Pair by DFA-010 (eventId1,eventId2)
        Map<EventKey, List<TxInfo>> byKey = new HashMap<>();
        for (TxInfo x : infos) {
            if (x.eventKey != null && x.eventKey.valid()) {
                byKey.computeIfAbsent(x.eventKey, k -> new ArrayList<>()).add(x);
            }
        }

        List<TransactionUnit<T>> units = new ArrayList<>();

        for (Map.Entry<EventKey, List<TxInfo>> e : byKey.entrySet()) {
            List<TxInfo> group = e.getValue();
            if (group.size() < 2) continue;

            // Prefer pairing ADD with SUB; otherwise pair first two unconsumed
            TxInfo add = null, sub = null;
            for (TxInfo x : group) if (!x.consumed && x.effect == Effect.ADD) { add = x; break; }
            for (TxInfo x : group) if (!x.consumed && x.effect == Effect.SUB) { sub = x; break; }

            if (add != null && sub != null) {
                add.consumed = sub.consumed = true;
                tagKind(add.tx, DfaKinds.TRANSFER);
                tagKind(sub.tx, DfaKinds.TRANSFER);
                units.add(new TransactionUnit<>(
                        DfaKinds.TRANSFER,
                        List.of((T) add.tx, (T) sub.tx),
                        "paired by DFA-010 " + e.getKey() + " (ADD↔SUB)"
                ));
            } else {
                // fallback: take first two unconsumed in this key
                TxInfo x1 = null, x2 = null;
                for (TxInfo x : group) if (!x.consumed) { x1 = x; break; }
                if (x1 != null) for (TxInfo x : group) if (!x.consumed && x != x1) { x2 = x; break; }
                if (x1 != null && x2 != null) {
                    x1.consumed = x2.consumed = true;
                    tagKind(x1.tx, DfaKinds.TRANSFER);
                    tagKind(x2.tx, DfaKinds.TRANSFER);
                    units.add(new TransactionUnit<>(
                            DfaKinds.TRANSFER,
                            List.of((T) x1.tx, (T) x2.tx),
                            "paired by DFA-010 " + e.getKey()
                    ));
                }
            }
        }

        // Remaining: classify by effect (A -> SUBSCRIPTION, S -> REDEMPTION)
        for (TxInfo x : infos) {
            if (x.consumed) continue;
            TxnKind kind;
            String why;
            switch (x.effect) {
                case ADD -> { kind = DfaKinds.SUBSCRIPTION; why = "DFA001=A (no matching DFA-010 pair)"; }
                case SUB -> { kind = DfaKinds.REDEMPTION;   why = "DFA001=S (no matching DFA-010 pair)"; }
                case NONE, UNKNOWN -> { kind = TxnKind.UNKNOWN; why = "DFA001=N/UNKNOWN"; }
                default -> { kind = TxnKind.UNKNOWN; why = "unrecognized"; }
            }
            tagKind(x.tx, kind); // optional annotation
            units.add(new TransactionUnit<>(kind, List.of((T) x.tx), why));
        }

        return units;
    }

    /** Extract ADD/SUB/NONE from DFA-001. */
    private static Effect extractEffect(TransactionGroup tx) {
        for (OutboundDetail d : tx.details()) {
            if (d instanceof DfaRecord1 r1) {
                Object e = r1.getShareBalanceEffect();
                if (e == null) return Effect.UNKNOWN;
                String s = e.toString().trim().toUpperCase(Locale.ROOT);
                return switch (s) {
                    case "A", "ADD" -> Effect.ADD;
                    case "S", "SUB" -> Effect.SUB;
                    case "N", "NONE" -> Effect.NONE;
                    default -> Effect.UNKNOWN;
                };
            }
        }
        return Effect.UNKNOWN;
    }

    /** Extract (eventId1,eventId2) from DFA-010. */
    private static EventKey extractEventKey(TransactionGroup tx) {
        for (OutboundDetail d : tx.details()) {
            if (d instanceof DfaRecord10 r10) {
                Long id1 = r10.getEventId1();
                Long id2 = r10.getEventId2();
                if (id1 != null || id2 != null) return new EventKey(id1, id2);
            }
        }
        return null;
    }

    /** If TransactionGroup supports it, tag with the chosen kind. */
    private static void tagKind(TransactionGroup tx, TxnKind kind) {
        if (tx instanceof TransactionKindAware aware) {
            aware.setKind(kind);
        }
    }
}