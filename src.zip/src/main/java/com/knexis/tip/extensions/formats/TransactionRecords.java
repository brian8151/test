package com.knexis.tip.extensions.formats;

import com.knexis.tip.types.OutboundDetail;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Generic transaction: ordered list of detail records. */
public class TransactionRecords implements OutboundTransaction<OutboundDetail> {
    private final List<OutboundDetail> details = new ArrayList<>();

    @Override public void add(OutboundDetail d)      { details.add(d); }
    @Override public List<OutboundDetail> details()  { return Collections.unmodifiableList(details); }

    /** Convenience: first detail of a given type. */
    public <T extends OutboundDetail> T firstOf(Class<T> type) {
        for (OutboundDetail d : details) if (type.isInstance(d)) return type.cast(d);
        return null;
    }
}