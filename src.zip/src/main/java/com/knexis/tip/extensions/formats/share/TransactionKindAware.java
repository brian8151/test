package com.knexis.tip.extensions.formats.share;
/**
 * Optional capability for transaction containers (e.g., {@code TransactionGroup})
 * to carry a chosen {@link TxnKind} decided by a post-processor.
 *
 * <p>Post-processors (like {@code DfaPostProcessor}) will detect this interface
 * and call {@link #setKind(TxnKind)} to annotate the container with the final
 * classification. If a container does not implement this interface, processors
 * should behave gracefully and simply skip the annotation.</p>
 *
 * <h3>Typical Usage</h3>
 * <pre>{@code
 * public final class TransactionGroup implements TransactionKindAware {
 *     private TxnKind kind = TxnKind.UNKNOWN;
 *     @Override public void setKind(TxnKind kind) { this.kind = kind; }
 *     @Override public TxnKind getKind() { return kind; }
 *     // ... details(), etc.
 * }
 *
 * // In a processor:
 * if (tx instanceof TransactionKindAware aware) {
 *     aware.setKind(TxnKind.of("DFA", "TRANSFER"));
 * }
 * }</pre>
 *
 * <p><b>Thread-safety:</b> Implementations should document whether setting/reading the
 * kind is thread-safe. The default {@code TransactionGroup} usage is single-threaded
 * within a parse/post-process pipeline.</p>
 */
public interface TransactionKindAware {
    void setKind(TxnKind kind);
    TxnKind getKind();
}
