package com.knexis.tip.extensions.formats.share;

public interface TransactionKindAware {
    void setKind(TxnKind kind);
    TxnKind getKind();
}
