package com.knexis.tip.extensions.formats.share;

import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.extensions.formats.dist.process.DistributionPostProcessor;

import java.util.HashMap;
import java.util.Map;

public final class PostProcessorRegistry {
    private final Map<String, FormatPostProcessor> map = new HashMap<>();
    /** Singleton anonymous no-op that relies on the interface's default process(...) */
    private static final FormatPostProcessor DEFAULT = new FormatPostProcessor() {
        @Override public String toString() { return "NoOpFormatPostProcessor"; }
    };
    public FormatPostProcessor get(String fileTypeId) { return map.get(fileTypeId); }
    /**
     * return a concrete processor if known; otherwise return an
     * anonymous default that uses the interface's no-op {@code process(...)}.
     *
     * @param fileTypeId e.g. "FINANCIALDIRECT"
     * @return processor (never null)
     */
    public static FormatPostProcessor resolve(String fileTypeId) {
        if (fileTypeId == null || fileTypeId.isBlank()) return DEFAULT;
        return switch (fileTypeId.trim()) {
            case "FINANCIALDIRECT" -> new DfaPostProcessor();
            case "DISTRIBUTION"    -> new DistributionPostProcessor();
            default -> DEFAULT; // anonymous default uses the interface's default process()
        };
    }
}