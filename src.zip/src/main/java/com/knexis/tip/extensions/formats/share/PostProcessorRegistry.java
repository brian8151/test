package com.knexis.tip.extensions.formats.share;

import java.util.HashMap;
import java.util.Map;

public final class PostProcessorRegistry {
    private final Map<String, FormatPostProcessor> map = new HashMap<>();
    public PostProcessorRegistry register(String fileTypeId, FormatPostProcessor p) {
        map.put(fileTypeId, p); return this;
    }
    public FormatPostProcessor get(String fileTypeId) { return map.get(fileTypeId); }
}