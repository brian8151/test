package com.knexis.tip.types;

import java.util.List;

/** A homogeneous, ordered set of detail records belonging to one logical group. */
public interface RecordSet<T extends OutboundDetail> extends Iterable<T> {

    /** Add a detail (order is preserved). */
    void add(T detail);

    /** Unmodifiable view of all details (in order). */
    List<T> getRecords();

    /** Number of details in this set. */
    int size();

    /** All details of a given subtype (in order). */
    <S extends T> List<S> ofType(Class<S> type);

    /** First detail of a given subtype, or null. */
    <S extends T> S firstOf(Class<S> type);
}