package com.knexis.tip.types;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Iterator;

public class RecordSetBase<T extends OutboundDetail> implements RecordSet<T> {

    private final List<T> records = new ArrayList<>();

    @Override public void add(T detail) { records.add(detail); }

    @Override public List<T> getRecords() { return Collections.unmodifiableList(records); }

    @Override public int size() { return records.size(); }

    @Override public <S extends T> List<S> ofType(Class<S> type) {
        List<S> out = new ArrayList<>();
        for (T d : records) if (type.isInstance(d)) out.add(type.cast(d));
        return out;
    }

    @Override public <S extends T> S firstOf(Class<S> type) {
        for (T d : records) if (type.isInstance(d)) return type.cast(d);
        return null;
    }

    @Override public Iterator<T> iterator() { return getRecords().iterator(); }
}