package com.knexis.tip.types;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class OutboundFile<T> {
    private final Map<String, Object> header;
    private List<T> items;
    private final Map<String, Object> trailer;

    public OutboundFile(Map<String, Object> header, List<T> items, Map<String, Object> trailer) {
        this.header = header;
        this.items = items;
        this.trailer = trailer;
    }

}
