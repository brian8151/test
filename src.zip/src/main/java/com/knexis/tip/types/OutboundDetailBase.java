package com.knexis.tip.types;

public class OutboundDetailBase implements OutboundDetail {
    private String recordId;
    private Integer lineNumber;

    @Override public String getRecordId() {
        return recordId;
    }
    @Override public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @Override public Integer getLineNumber() {
        return lineNumber;
    }
    @Override public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }
}
