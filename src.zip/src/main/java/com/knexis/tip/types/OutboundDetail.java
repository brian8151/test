package com.knexis.tip.types;

public interface OutboundDetail {
    /** Logical record id from the schema, e.g. "DFA-001", "DFA-004". */
    String getRecordId();
    void setRecordId(String recordId);

    /** Source line number in the file (optional but super handy for debugging). */
    Integer getLineNumber();
    void setLineNumber(Integer lineNumber);

}