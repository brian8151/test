package com.knexis.tip.service;

import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcher.Result;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.extensions.formats.share.PostProcessorRegistry;
import com.knexis.tip.utils.HeaderPeek;
import com.knexis.tip.utils.TransactionPrinter;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import software.amazon.awssdk.services.s3.S3Client;

/**
 * process tip files from an S3 InputStream.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TipFileProcessorService {
    private final S3Client s3Client;
    private SchemaRegistry registry;

    @PostConstruct
    public void init() {
        log.info("Initializing SchemaRegistry at startup...");
        this.registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        log.info("SchemaRegistry loaded with {} schemas: {}", registry.allIds().size(), registry.allIds());
    }

    public void processS3TipFile(String bucket, String key) throws Exception {
        try (var in = s3Client.getObject(
                GetObjectRequest.builder().bucket(bucket).key(key).build())) {
            processTipFile(key, in);
        }
    }

    public void processTipFile(String virtualFileName, InputStream in) throws Exception {
        // Read all lines from stream
        List<String> lines;
        try (var br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            lines = br.lines().collect(Collectors.toList());
        }

        // === Begin original logic (minimally adapted) ===

        var preview = HeaderPeek.read(lines);
        if (!"RHR".equals(preview.recordType())) {
            throw new IllegalArgumentException("Not a TIP outbound file (recordType=" + preview.recordType() + ")");
        }

        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(this.registry);
        // We don’t have a real Path here; pass a synthetic one for any IDs/logging:
        Result result = dispatcher.dispatch(virtualFileName, lines);

        log.info("Detected type: {}", result.fileTypeId());
        var file = result.cast(TransactionGroup.class);
//        TransactionPrinter.printFile(file);
        var pp = new PostProcessorRegistry()
                .register("FINANCIALDIRECT", new DfaPostProcessor());
        var units = pp.get(result.fileTypeId())
                .process(result.fileTypeId(), file);
        TransactionPrinter.printUnits(units);
    }
}