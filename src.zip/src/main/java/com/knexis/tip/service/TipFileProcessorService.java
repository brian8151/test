package com.knexis.tip.service;

import com.knexis.tip.core.parser.ParseDispatcher;
import com.knexis.tip.core.parser.ParseDispatcher.Result;
import com.knexis.tip.core.parser.ParseDispatcherFactory;
import com.knexis.tip.core.parser.RecordTokenizer;
import com.knexis.tip.core.parser.Validator;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.extensions.formats.dfa.process.DfaPostProcessor;
import com.knexis.tip.extensions.formats.share.FormatPostProcessor;
import com.knexis.tip.extensions.formats.share.PostProcessorRegistry;
import com.knexis.tip.utils.TransactionPrinter;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

/**
 * High-level pipeline to process TIP outbound files from an {@link InputStream}, including S3 objects.
 *
 * <h2>What this service does</h2>
 * <ol>
 *   <li>Loads the {@link SchemaRegistry} at startup from {@code schemas/catalog.yml} (classpath).</li>
 *   <li>Reads the entire input stream into memory as lines (header, body, trailer).</li>
 *   <li>Uses the <em>common</em> header/trailer schemas (shared via {@code common-schemas.yml}) to:
 *       <ul>
 *         <li>Validate the header/trailer tags and minimal length via {@link Validator}.</li>
 *         <li>Extract {@code fileTypeId} (aka {@code fileTypeText}, e.g., {@code FINANCIALDIRECT}) from the header.</li>
 *       </ul>
 *   </li>
 *   <li>Delegates parsing to a {@link ParseDispatcher} (registered for all known schemas), which
 *       returns an {@link com.knexis.tip.types.OutboundFile OutboundFile}&lt;{@link TransactionGroup}&gt;.</li>
 *   <li>Optionally runs format-specific post-processing (e.g., DFA classification and transfer pairing)
 *       via {@link PostProcessorRegistry} and prints the results with {@link TransactionPrinter}.</li>
 * </ol>
 *
 * <h2>Notes & Assumptions</h2>
 * <ul>
 *   <li><strong>Validation:</strong> This service performs <em>tag-level</em> validation of the header and trailer
 *       (positions and expected tag string) before parsing. Field-level typing/length checks are enforced by the parser.</li>
 *   <li><strong>Memory:</strong> The entire file is read into memory as a {@code List<String>}. For very large files,
 *       consider a streaming/iterative approach.</li>
 *   <li><strong>Common header/trailer:</strong> We obtain the common header/trailer schemas by picking any registered
 *       schema id from the registry (they share the same common-schemas.yml). If your project diverges per file type,
 *       inject a specific id instead.</li>
 *   <li><strong>Post-processing:</strong> This example registers only {@link DfaPostProcessor} keyed by DFA fileTypeId.
 *       Add/register other format processors as needed.</li>
 * </ul>
 *
 * <h2>Example</h2>
 * <pre>{@code
 * // From another Spring component:
 * @Autowired TipFileProcessorService svc;
 * svc.processS3TipFile("my-bucket", "tip/outbound/2025/08/20/file.tip");
 * }</pre>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TipFileProcessorService {
    private final S3Client s3Client;
    private SchemaRegistry registry;
    /**
     * Initialize the {@link SchemaRegistry} once at application startup.
     * Loads {@code schemas/catalog.yml} from the classpath and logs available ids (e.g., FINANCIALDIRECT).
     */
    @PostConstruct
    public void init() {
        log.info("Initializing SchemaRegistry at startup...");
        this.registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
        log.info("SchemaRegistry loaded with {} schemas: {}", registry.allIds().size(), registry.allIds());
    }
    /**
     * Convenience entry point: fetch a TIP file from S3 and process it.
     *
     * <p>This method only acquires the object stream; all parsing/validation is delegated to
     * {@link #processTipFile(InputStream)}.</p>
     *
     * @param bucket S3 bucket name
     * @param key    S3 object key
     * @throws Exception if I/O or parsing/post-processing fails
     */
    public void processS3TipFile(String bucket, String key) throws Exception {
        try (var in = s3Client.getObject(
                GetObjectRequest.builder().bucket(bucket).key(key).build())) {
            processTipFile(in);
        }
    }

    /**
     * Process a TIP outbound file from an {@link InputStream}.
     *
     * <p><strong>Flow:</strong>
     * <ol>
     *   <li>Read entire stream as UTF-8 lines.</li>
     *   <li>Resolve the common header/trailer schemas and record length from the registry.</li>
     *   <li>Validate header and trailer via {@link Validator} (schema-driven ranges + expected tag values).</li>
     *   <li>Extract {@code fileTypeId} from the header via {@link RecordTokenizer#fileTypeId(String, com.knexis.tip.core.schema.RecordSchema)}.</li>
     *   <li>Create a {@link ParseDispatcher} (registered for all ids) and parse to an {@code OutboundFile&lt;TransactionGroup&gt;}.</li>
     *   <li>Optionally apply format-specific post-processing (e.g., DFA) and print results.</li>
     * </ol>
     *
     * <p><strong>Validation coverage:</strong> The pre-parse validation here verifies the header/trailer tags and basic length.
     * The {@link com.knexis.tip.core.parser.DataLineParser} then enforces field slicing, types, and record-level constraints.</p>
     *
     * @param in input stream positioned at the start of the TIP file
     * @throws Exception for malformed input, unknown {@code fileTypeId}, or downstream processing errors
     */
    public void processTipFile(InputStream in) throws Exception {
        // Read all lines from stream
        List<String> lines;
        try (var br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            lines = br.lines().collect(Collectors.toList());
        }

        // === Begin original logic (minimally adapted) ===
        // --- Resolve common header/trailer and nominal record length. ---
        // All formats include common header/trailer via common-schemas.yml
        String anyId = registry.allIds().iterator().next();
        var common = registry.getById(anyId);
        var headerSchema  = common.getHeader();
        var trailerSchema = common.getTrailer();
        int recordLen     = common.getRecordLength() != null ? common.getRecordLength() : 0;
        // --- Validate header and trailer using schema-defined tag ranges and expected matches. ---
        String headerLine = lines.get(0);
        Validator.validateHeaderLine(headerLine, headerSchema, recordLen);
        Validator.validateTrailerLine(lines.get(lines.size() - 1), trailerSchema, recordLen);
        // --- Extract fileTypeId (aka fileTypeText) from header using schema field positions. ---
        String fileTypeId = RecordTokenizer.fileTypeId(headerLine, headerSchema);
        // --- Parse: register default strategy (TransactionGroup) for all ids and dispatch. ---
        ParseDispatcher dispatcher = ParseDispatcherFactory.registerAll(this.registry);
        Result result = dispatcher.dispatch(lines, fileTypeId);
        log.info("Detected type: {}", result.fileTypeId());
        // Cast to the expected transaction container type for downstream handling.
        var file = result.cast(TransactionGroup.class);
//        TransactionPrinter.printFile(file);
        // --- Optional post-processing: format-specific classification/pairing.
        FormatPostProcessor pp = PostProcessorRegistry.resolve(fileTypeId);
        var units = pp.process(fileTypeId, file);
        TransactionPrinter.printUnits(units);
    }
}