package com.knexis.tip.service;

import com.amazonaws.services.s3.event.S3EventNotification;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.ListenerExecutionFailedException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import java.util.List;


@Slf4j
@Component
@RequiredArgsConstructor
public class TipS3ToSqsEventListener {
    private final S3StorageService s3;
    private final TipFileProcessorService processor;
    private final ObjectMapper mapper;

    @Value("${app.s3.archive-prefix:archive/}")
    private String archivePrefix;

    @SqsListener("${app.sqs.queue-name}")
    public void onMessage(String rawMessage) {
        log.info("received sqs raw message: {}", rawMessage);
        try {
            JsonNode root = mapper.readTree(rawMessage);
            for (JsonNode rec : root.path("Records")) {
                String bucket = rec.path("s3").path("bucket").path("name").asText();
                String key = java.net.URLDecoder.decode(
                        rec.path("s3").path("object").path("key").asText(null),
                        java.nio.charset.StandardCharsets.UTF_8);
                log.info("Received S3 event record: bucket={}, key={}", bucket, key);
                if (key == null || key.isEmpty()) {
                    log.warn("Missing or empty S3 object key in event: {}", rec);
                    return;
                }
                if (key.startsWith(archivePrefix)) {
                    log.info("Skipping archived object (no reprocessing): s3://{}/{}", bucket, key);
                    continue;
                }
                try {
                    log.info("===================== START process TIP file: s3://{}/{} =====================", bucket, key);
                    processor.processS3TipFile(bucket, key);
                    log.info("Successfully processed TIP file: s3://{}/{}", bucket, key);

                    log.info("Archiving file: s3://{}/{} -> prefix '{}'", bucket, key, archivePrefix);
                    s3.moveToArchive(bucket, key, archivePrefix);
                    log.info("Archived TIP file: s3://{}/{}", bucket, key);
                    log.info("===================== COMPLETE processed TIP file: s3://{}/{} =====================", bucket, key);

                } catch (Exception ex) {
                    log.error("Error handling S3 record (bucket={}, key={}): {}", bucket, key, ex.getMessage(), ex);
                    Message<String> failed = MessageBuilder.withPayload(rawMessage).build();
                    throw new ListenerExecutionFailedException("Failed processing SQS message", ex, failed);
                }
            }
        } catch (Exception e) {
            log.error("Error handling S3 record {}",e.getMessage(), e);
        }
    }
}
