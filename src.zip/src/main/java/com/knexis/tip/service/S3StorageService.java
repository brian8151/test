package com.knexis.tip.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.CopyObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
@Slf4j
public class S3StorageService {

    private final S3Client s3;

    /** Move == copy to new key + delete original */
    public void moveToArchive(String bucket, String key, String archivePrefix) {
        if (archivePrefix!=null && key.startsWith(archivePrefix)) {
            log.info("Already archived, skip move: s3://{}/{}", bucket, key);
            return;
        }
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        String fileName = key.contains("/") ? key.substring(key.lastIndexOf('/') + 1) : key;
        String destKey = (archivePrefix == null ? "archive/" : archivePrefix) + ts + "-" + fileName;
        if (destKey.length() > 1000) { // leave some headroom
            int maxFilePart = Math.max(1, 1000 - (archivePrefix.length() + ts.length() + 1));
            if (fileName.length() > maxFilePart) {
                String ext = "";
                int dot = fileName.lastIndexOf('.');
                if (dot > 0 && dot < fileName.length() - 1) {
                    ext = fileName.substring(dot);
                    fileName = fileName.substring(0, dot);
                }
                fileName = fileName.substring(0, Math.min(fileName.length(), maxFilePart - ext.length())) + ext;
                destKey = archivePrefix + ts + "-" + fileName;
            }
        }
        String copySource = bucket + "/" + key;
        String encodedCopySource = URLEncoder.encode(copySource, StandardCharsets.UTF_8);

        CopyObjectRequest copyReq = CopyObjectRequest.builder()
                        .copySource(encodedCopySource)
                        .destinationBucket(bucket)
                        .destinationKey(destKey)
                        .build();

        s3.copyObject(copyReq);
        s3.deleteObject(b -> b.bucket(bucket).key(key));
        log.info("Archived s3://{}/{} -> s3://{}/{}", bucket, key, bucket, destKey);
    }

    public void writeObject(String bucket, String key, InputStream data, long contentLength) {
        s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).build(),
                RequestBody.fromInputStream(data, contentLength));
    }
}