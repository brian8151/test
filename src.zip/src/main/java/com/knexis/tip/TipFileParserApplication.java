package com.knexis.tip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TipFileParserApplication {
    public static void main(String[] args) {
        SpringApplication.run(TipFileParserApplication.class, args);
    }
}