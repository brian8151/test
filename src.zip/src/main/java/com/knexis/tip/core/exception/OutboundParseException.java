package com.knexis.tip.core.exception;

public class OutboundParseException extends RuntimeException {

    public OutboundParseException(String message) {
        super(message);
    }

    public OutboundParseException(String message, Throwable cause) {
        super(message, cause);
    }
}