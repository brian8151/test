package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.FieldDef;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public final class Transformers {
    private Transformers() { }

    public static Object convert(FieldDef def, String raw) {
        String s = raw == null ? "" : raw;
        if (Boolean.TRUE.equals(def.getTrim())) s = s.trim();
        if ((s.isBlank()) && Boolean.TRUE.equals(def.getNullable())) return null;

        return switch (def.getType()) {
            case STRING -> s;
            case INT -> parseInt(s);
            case LONG -> parseLong(s);
            case DECIMAL -> parseDecimal(s, def.getScale());
            case DATE -> parseDate(s, def.getPattern());
            case ENUM -> mapEnum(s, def.getEnumMap());
            default -> s;
        };
    }

    private static Integer parseInt(String s) {
        if (s.isBlank()) return null;
        return Integer.valueOf(s);
    }

    private static Long parseLong(String s) {
        if (s.isBlank()) return null;
        return Long.valueOf(s);
    }

    private static BigDecimal parseDecimal(String s, Integer scale) {
        if (s.isBlank()) return null;
        BigDecimal bd = new BigDecimal(s);
        if (scale != null && scale > 0) {
            return bd.movePointLeft(scale);
        }
        return bd;
    }

    private static LocalDate parseDate(String s, String pattern) {
        if (s.isBlank()) return null;
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern(pattern != null ? pattern : "yyyyMMdd");
        return LocalDate.parse(s, fmt);
    }

    private static String mapEnum(String s, Map<String, String> enumMap) {
        if (enumMap == null || enumMap.isEmpty()) return s;
        return enumMap.getOrDefault(s, s);
    }
}
