package com.knexis.tip.core.exception;

/**
 * Thrown when a line cannot be parsed according to the schema.
 */
public class RecordParseException extends OutboundParseException {
    private final int lineNumber;
    private final String lineContent;

    public RecordParseException(String message, int lineNumber, String lineContent) {
        super(message + " (line " + lineNumber + ")");
        this.lineNumber = lineNumber;
        this.lineContent = lineContent;
    }

    public int getLineNumber() { return lineNumber; }
    public String getLineContent() { return lineContent; }
}
