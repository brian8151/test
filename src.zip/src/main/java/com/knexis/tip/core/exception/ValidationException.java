package com.knexis.tip.core.exception;

/**
 * Thrown when header/trailer validation fails
 * (e.g., record counts mismatch, wrong file type).
 */
public class ValidationException extends OutboundParseException {
    public ValidationException(String message) {
        super(message);
    }
}
