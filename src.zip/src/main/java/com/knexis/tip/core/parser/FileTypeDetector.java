package com.knexis.tip.core.parser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class FileTypeDetector {
    private FileTypeDetector() {}

    /** 1-based inclusive slice helper. Safe if line shorter than end. */
    public static String slice(String line, int start, int end) {
        if (line == null) return "";
        int s = Math.max(0, start - 1);
        int e = Math.min(line.length(), end);
        return (s < e) ? line.substring(s, e) : "";
    }

    public static HeaderPreview readHeader(Path path) {
        try {
            List<String> lines = Files.readAllLines(path);
            if (lines.isEmpty()) throw new IllegalArgumentException("Empty file: " + path);
            String h = lines.get(0);
            String recordType   = slice(h, 1, 3).trim();   // should be RHR
            String seq          = slice(h, 4, 6).trim();
            String fileTypeText = slice(h, 7, 21).trim();  // e.g., FINANCIALDIRECT
            String processedDate= slice(h, 30, 37).trim();
            String jobName      = slice(h, 46, 53).trim();
            // (ignoring fileFormatCode 54–56 since we don’t need it.)

            return new HeaderPreview(h, recordType, seq, fileTypeText, processedDate, jobName);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read header of " + path, e);
        }
    }

    public record HeaderPreview(
            String rawLine,
            String recordType,
            String seq,
            String fileTypeText,
            String processedDate,
            String jobName
    ) {}
}