package com.knexis.tip.core.parser;

import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.core.schema.OutboundFileSchema;
import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.aggregation.Aggregator;
import com.knexis.tip.extensions.aggregation.GroupAggregatorFactory;
import com.knexis.tip.extensions.formats.OutboundTransaction;
import com.knexis.tip.extensions.formats.TransactionGroup;
import com.knexis.tip.types.OutboundDetail;
import com.knexis.tip.types.OutboundFile;
import com.knexis.tip.utils.HeaderPeek;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Auto-detects TIP file type from header, selects the correct schema (via SchemaRegistry)
 **/
public final class ParseDispatcher {

    /** Per-file-type strategy: how to create a TX and what family prefix (DFA/NFA/etc) to enforce. */
    public static final class Strategy<TX extends OutboundTransaction<OutboundDetail>> {
        private final String groupPrefix;          // e.g., "DFA" or null to accept any
        private final Supplier<TX> txSupplier;      // e.g., DfaTransaction::new
        private final Class<TX> txClass;            // e.g., DfaTransaction.class

        public Strategy(String groupPrefix, Supplier<TX> txSupplier, Class<TX> txClass) {
            this.groupPrefix = (groupPrefix == null || groupPrefix.isBlank()) ? null : groupPrefix;
            this.txSupplier   = txSupplier;
            this.txClass      = txClass;
        }

        GroupAggregatorFactory<TX> factory() {
            return new Aggregator.Factory<>(txSupplier).withGroupPrefix(groupPrefix);
        }

        Class<TX> txClass() { return txClass; }
    }
    /** Result wrapper that carries the chosen fileTypeId, raw OutboundFile<?> and the TX class. */
    public static final class Result {
        private final String fileTypeId;
        private final OutboundFile<?> file;
        private final Class<? extends OutboundTransaction<OutboundDetail>> txClass;

        public Result(String fileTypeId,
                      OutboundFile<?> file,
                      Class<? extends OutboundTransaction<OutboundDetail>> txClass) {
            this.fileTypeId = fileTypeId;
            this.file = file;
            this.txClass = txClass;
        }

        public String fileTypeId() { return fileTypeId; }
        public OutboundFile<?> file() { return file; }
        public Class<? extends OutboundTransaction<OutboundDetail>> txClass() { return txClass; }

        /** Type-safe cast to the expected transaction type with a clear error if mismatched. */
        public <TX extends OutboundTransaction<OutboundDetail>> OutboundFile<TX> cast(Class<TX> expected) {
            if (!txClass.equals(expected)) {
                throw new ClassCastException(
                        "ParseDispatcher.Result holds " + txClass.getName() +
                                " but cast requested " + expected.getName()
                );
            }
            @SuppressWarnings("unchecked")
            OutboundFile<TX> typed = (OutboundFile<TX>) file;
            return typed;
        }
    }

    private final SchemaRegistry registry;
    private final Map<String, Strategy<?>> strategies = new HashMap<>();

    public ParseDispatcher(SchemaRegistry registry) {
        this.registry = registry;
    }
    public static ParseDispatcher registerAll(SchemaRegistry registry) {
        ParseDispatcher d = new ParseDispatcher(registry);
        for (String id : registry.allIds()) {
            d.register(id, new Strategy<>(null, TransactionGroup::new, TransactionGroup.class));
        }
        return d;
    }
    /** Register a file type id (header fileTypeText) with its parse strategy */
    public <TX extends OutboundTransaction<OutboundDetail>> ParseDispatcher register(
            String fileTypeId,
            Strategy<TX> strategy
    ) {
        strategies.put(fileTypeId, strategy);
        return this;
    }
    /** pure line-based dispatch (no filesystem). */
    public Result dispatch(String sourceName, List<String> lines) {
        return dispatchFromLines(lines);
    }

    public Result dispatch(Path input, List<String> lines) {
        // Do NOT call HeaderPeek.read(input); that would hit the filesystem.
        return dispatchFromLines(lines);
    }
    /** Single implementation that performs header peek, strategy lookup, and parsing from memory. */
    private Result dispatchFromLines(List<String> lines) {
        // Peek header from in-memory lines
        HeaderPeek.Preview hdr = HeaderPeek.read(lines);
        if (!"RHR".equals(hdr.recordType())) {
            throw new IllegalArgumentException("Not a TIP outbound file: recordType=" + hdr.recordType());
        }

        String fileTypeId = hdr.fileTypeText();     // e.g., "FINANCIALDIRECT"
        Strategy<?> strategy = strategies.get(fileTypeId);
        if (strategy == null) {
            throw new SchemaException("No strategy registered for fileTypeId: " + fileTypeId);
        }

        OutboundFileSchema schema = registry.getById(fileTypeId);
        DataLineParser parser = new DataLineParser(schema);

        @SuppressWarnings("unchecked")
        GroupAggregatorFactory<? extends OutboundTransaction<OutboundDetail>> factory =
                ((Strategy<? extends OutboundTransaction<OutboundDetail>>) strategy).factory();

        OutboundFile<?> parsed = parser.parse(lines, factory);

        // Construct Result exactly as defined: (fileTypeId, parsed file, txClass)
        return new Result(fileTypeId, parsed, strategy.txClass());
    }

}
