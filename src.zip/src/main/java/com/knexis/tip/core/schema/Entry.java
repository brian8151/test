package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class Entry {
    private String id;
    private String resource; // classpath resource

}