package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OutboundFileSchema {
    private String fileType;          // e.g., FINANCIALDIRECT
    private String commonResource;
    private Integer recordLength;     // e.g., 160 (1-based inclusive end indexes in fields)
    private RecordSchema header;      // RHR
    private RecordSchema trailer;     // RTR
    private RecordBody body;
}
