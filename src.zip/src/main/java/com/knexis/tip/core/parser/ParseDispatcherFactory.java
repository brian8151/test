package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.SchemaRegistry;
import com.knexis.tip.extensions.formats.TransactionGroup;

public final class ParseDispatcherFactory {
    private ParseDispatcherFactory() {}

    /** Auto-register all schemas in the registry with a generic TransactionGroup strategy. */
    public static ParseDispatcher registerAll(SchemaRegistry registry) {
        ParseDispatcher d = new ParseDispatcher(registry);
        for (String id : registry.allIds()) {
            d.register(id, new ParseDispatcher.Strategy<>(null, TransactionGroup::new, TransactionGroup.class));
        }
        return d;
    }
}
