package com.knexis.tip.core.exception;

/**
 * Thrown when the schema (YAML/JSON) is malformed or inconsistent.
 */
public class SchemaException extends OutboundParseException {
    public SchemaException(String message) {
        super(message);
    }
    public SchemaException(String message, Throwable cause) {
        super(message, cause);
    }
}