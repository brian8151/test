package com.knexis.tip.core.parser;

import com.knexis.tip.core.exception.RecordParseException;
import com.knexis.tip.core.exception.ValidationException;
import com.knexis.tip.core.schema.FieldDef;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

@Slf4j
public final class Validator {
    private Validator() { }

    /**
     * Compute the minimal required length for a line to safely parse all non-filler fields.
     * We assume fields named "filler" (case-insensitive) are ignorable for truncation checks.
     */
    public static int minRequiredLength(List<FieldDef> fields) {
        int max = 0;
        if (fields == null) return max;
        for (FieldDef f : fields) {
            String name = f.getName();
            boolean isFiller = name != null && name.trim().equalsIgnoreCase("filler");
            if (!isFiller) {
                max = Math.max(max, f.getEnd());
            }
        }
        return max;
    }
    public static void assertLength(String line, int expectedLen, int lineNum) {
        // delegate with minRequiredLen = 0 (means: no strict requirement)
        assertLength(line, expectedLen, 0, lineNum);
    }
    /**
     * Validate length with filler awareness.
     * - If actual < minRequiredLen => throw (data truncated).
     * - Else if actual < expectedLen => warn (only trailing filler missing).
     * - Else OK.
     *
     * @param line        the raw line text
     * @param expectedLen expected fixed width length
     * @param lineNum     1-based line number in file
     */
    public static void assertLength(String line, int expectedLen, int minRequiredLen, int lineNum) {
        if (line == null) {
            throw new RecordParseException("Null line at " + lineNum, lineNum, null);
        }

        int actualLen = line.length();
        if (minRequiredLen > 0 && actualLen < minRequiredLen) {
            throw new RecordParseException(
                    "Line truncated before required data (need >= " + minRequiredLen +
                            ", found " + actualLen + ") at line " + lineNum +
                            ". Content: [" + preview(line) + "]",
                    lineNum,
                    line
            );
        }

        if (expectedLen > 0 && actualLen < expectedLen) {
            // Only filler missing at end — warn and continue
            log.warn("Line {} shorter than expected fixed width ({} vs {}). Assuming trailing filler only. Content: [{}]",
                    lineNum, actualLen, expectedLen, preview(line));
        }
    }
    /** Trimmed preview of content (avoid huge dumps). */
    public static String preview(String line) {
        if (line == null) return "";
        return line.length() > 120 ? line.substring(0, 120) + "..." : line;
    }
    public static void validateTrailerCount(Map<String, Object> trailer,
                                            int headerLineNum,   // 1-based
                                            int trailerLineNum,  // 1-based
                                            int totalLinesInFile,
                                            String headerPreview,
                                            String trailerPreview) {
        Object cnt = trailer.get("recordCount");
        if (!(cnt instanceof Number)) return;

        int expected = ((Number) cnt).intValue();

        // Actual count for this request is from header to trailer inclusive
        int actual = trailerLineNum - headerLineNum + 1;
        int body = Math.max(0, actual - 2); // minus header & trailer

        if (expected != actual) {
            String msg =
                    "Trailer record count mismatch.\n" +
                            "  expected (from trailer.recordCount): " + expected + "\n" +
                            "  actual (header..trailer inclusive):  " + actual + "\n" +
                            "  body detail lines:                   " + body + "\n" +
                            "  header line #:                       " + headerLineNum + "\n" +
                            "  trailer line #:                      " + trailerLineNum + "\n" +
                            "  total lines in file:                 " + totalLinesInFile + "\n" +
                            "  header preview: [" + headerPreview + "]\n" +
                            "  trailer preview: [" + trailerPreview + "]";
            throw new ValidationException(msg);
        }
    }
}