package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StartRecord {
    private String tag;          // e.g., "DFA"
    private String sequence;     // e.g., "001"
    private String recordRef;    // e.g., "DFA-001" (id of RecordDef)
}
