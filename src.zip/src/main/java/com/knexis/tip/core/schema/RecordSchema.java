package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class RecordSchema {
    private TagField tagField;
    private List<FieldDef> fields;
}
