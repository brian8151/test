package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SchemaDescriptor {
    private String id;
    private String resource;        // e.g., schemas/direct-financial-activity.yml
}