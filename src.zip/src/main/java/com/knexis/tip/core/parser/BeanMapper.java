package com.knexis.tip.core.parser;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

final class BeanMapper {
    private BeanMapper() { }

    static void populate(Object bean, Map<String, Object> values) {
        Class<?> cls = bean.getClass();
        for (Map.Entry<String, Object> e : values.entrySet()) {
            String name = e.getKey();
            Object val = e.getValue();

            // try setter
            String setter = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
            Method m = findSetter(cls, setter, val);
            if (m != null) {
                try { m.invoke(bean, val); } catch (Exception ignore) {}
                continue;
            }
            // try field
            try {
                Field f = cls.getDeclaredField(name);
                f.setAccessible(true);
                f.set(bean, val);
            } catch (Exception ignore) { /* skip if not present */ }
        }
    }

    private static Method findSetter(Class<?> cls, String setter, Object arg) {
        if (arg == null) return null;
        Class<?> t = arg.getClass();
        try {
            return cls.getMethod(setter, t);
        } catch (NoSuchMethodException e) {
            // try parents like Number -> BigDecimal, Integer -> Number not trivial; skip
            return null;
        }
    }
}
