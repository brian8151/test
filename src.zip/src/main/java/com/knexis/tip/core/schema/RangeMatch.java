package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RangeMatch {
    private int start;
    private int end;
    private String match;
}
