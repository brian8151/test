package com.knexis.tip.core.schema;

import jdk.jfr.Threshold;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Definition for a single record line within the body grammar.
 * Example: DFA-001, DFA-002, etc.
 */
@Getter
@Setter
@Threshold
public class RecordDef {
    private String id;                // e.g., "DFA-001"
    private RangeMatch tag;           // where and what to match for tag (e.g., DFA)
    private RangeMatch sequence;      // where and what to match for sequence (e.g., 001)
    private String className;         // fully-qualified class name to map into
    private boolean required;         // must appear in a group
    private boolean repeat;           // can appear multiple times in a group
    private List<FieldDef> fields;    // field definitions (fixed-width)
}
