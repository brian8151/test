package com.knexis.tip.core.schema;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class Catalog {
    private List<Entry> schemas;
}
