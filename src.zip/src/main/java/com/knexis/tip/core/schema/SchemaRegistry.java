package com.knexis.tip.core.schema;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.utils.SchemaLoader;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public final class SchemaRegistry {

    private static final ObjectMapper YAML = new ObjectMapper(new YAMLFactory());

    private final Map<String, OutboundFileSchema> byId;

    private SchemaRegistry(Map<String, OutboundFileSchema> byId) {
        this.byId = byId;
    }

    /**
     * Loads and initializes a {@code SchemaRegistry} from a root catalog configuration file.
     * <p>
     * This static factory method serves as the main entry point for loading all file format schemas.
     * It begins by parsing the specified catalog resource file (e.g., {@code catalog.yml}), which
     * contains a list of schema entries. Each entry provides an ID (like "FINANCIALDIRECT") and a
     * reference to another YAML file containing the detailed schema definition (e.g.,
     * {@code direct-financial-activity.yml}).
     * <p>
     * The method iterates through each entry in the catalog, loads the corresponding detailed schema,
     * validates it, and caches it in a map. The resulting {@code SchemaRegistry} instance provides a
     * centralized, ready-to-use collection of all configured file schemas.
     *
     * <pre>
     * {@code
     * // Example Usage:
     * SchemaRegistry registry = SchemaRegistry.loadFromResource("schemas/catalog.yml");
     * OutboundFileSchema dfaSchema = registry.getById("FINANCIALDIRECT");
     * }
     * </pre>
     *
     * @param catalogResource The classpath resource path to the main catalog YAML file.
     * @return A fully initialized {@code SchemaRegistry} instance containing all loaded schemas.
     * @throws SchemaException if the catalog is empty, an entry is malformed (missing id or resource),
     * or if a schema's internal {@code fileType} does not match the ID in the catalog.
     */
    public static SchemaRegistry loadFromResource(String catalogResource) {
        Catalog catalog = SchemaLoader.parseYamlFromResource(catalogResource, Catalog.class);
        if (catalog.getSchemas().isEmpty()) {
            throw new SchemaException("No schemas listed in catalog: " + catalogResource);
        }
        Map<String, OutboundFileSchema> map = new LinkedHashMap<>();
        for (Entry e : catalog.getSchemas()) {
            if (e.getId() == null || e.getId().isBlank())
                throw new SchemaException("Catalog entry missing id: " + e);
            if (e.getResource() == null || e.getResource().isBlank())
                throw new SchemaException("Catalog entry missing resource for id " + e.getId());

            OutboundFileSchema schema = SchemaLoader.loadFromResource(e.getResource());
            // Optional: sanity check the schema fileType matches the id
            if (schema.getFileType() != null && !schema.getFileType().equals(e.getId())) {
                throw new SchemaException("Schema fileType ("+schema.getFileType()+") != catalog id ("+e.getId()+")");
            }
            map.put(e.getId(), schema);
        }
        return new SchemaRegistry(map);
    }

    /** Get a resolved schema by id (uses internal cache). */
    public OutboundFileSchema getById(String id) {
        OutboundFileSchema s = byId.get(id);
        if (s == null) throw new SchemaException("Unknown schema id: " + id);
        return s;
    }

    /** All registered ids from the catalog (e.g., FINANCIALDIRECT, NONFINANCIALACT, …) */
    public Set<String> allIds() {
        return Collections.unmodifiableSet(byId.keySet());
    }

}