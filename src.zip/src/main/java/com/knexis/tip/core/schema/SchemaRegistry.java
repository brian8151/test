package com.knexis.tip.core.schema;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.knexis.tip.core.exception.SchemaException;
import com.knexis.tip.utils.SchemaLoader;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public final class SchemaRegistry {

    private static final ObjectMapper YAML = new ObjectMapper(new YAMLFactory());

    private final Map<String, OutboundFileSchema> byId;

    private SchemaRegistry(Map<String, OutboundFileSchema> byId) {
        this.byId = byId;
    }


    public static SchemaRegistry loadFromResource(String catalogResource) {
        Catalog catalog = SchemaLoader.parseYamlFromResource(catalogResource, Catalog.class);
        if (catalog.getSchemas().isEmpty()) {
            throw new SchemaException("No schemas listed in catalog: " + catalogResource);
        }
        Map<String, OutboundFileSchema> map = new LinkedHashMap<>();
        for (Entry e : catalog.getSchemas()) {
            if (e.getId() == null || e.getId().isBlank())
                throw new SchemaException("Catalog entry missing id: " + e);
            if (e.getResource() == null || e.getResource().isBlank())
                throw new SchemaException("Catalog entry missing resource for id " + e.getId());

            OutboundFileSchema schema = SchemaLoader.loadFromResource(e.getResource());
            // Optional: sanity check the schema fileType matches the id
            if (schema.getFileType() != null && !schema.getFileType().equals(e.getId())) {
                throw new SchemaException("Schema fileType ("+schema.getFileType()+") != catalog id ("+e.getId()+")");
            }
            map.put(e.getId(), schema);
        }
        return new SchemaRegistry(map);
    }

    /** Get a resolved schema by id (uses internal cache). */
    public OutboundFileSchema getById(String id) {
        OutboundFileSchema s = byId.get(id);
        if (s == null) throw new SchemaException("Unknown schema id: " + id);
        return s;
    }

    /** All registered ids from the catalog (e.g., FINANCIALDIRECT, NONFINANCIALACT, …) */
    public Set<String> allIds() {
        return Collections.unmodifiableSet(byId.keySet());
    }

    private static void validateDescriptor(SchemaDescriptor d, String origin) {
        if (d == null) throw new SchemaException("Null descriptor in catalog: " + origin);
        if (d.getId() == null || d.getId().isBlank()) {
            throw new SchemaException("Schema descriptor missing id in: " + origin);
        }
        if (d.getResource() == null || d.getResource().isBlank()) {
            throw new SchemaException("Schema descriptor '" + d.getId() + "' missing resource in: " + origin);
        }
    }
}