package com.knexis.tip.core.schema;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Map;

/**
 * A single fixed-width field in a record line.
 * Positions are 1-based inclusive for both start and end.
 */
@Getter
@Setter
@ToString
public class FieldDef {

    public enum DataType {
        STRING,
        INT,
        LONG,
        DECIMAL,    // requires 'scale' for implied decimals
        DATE,       // requires 'pattern', e.g., yyyyMMdd
        ENUM        // requires 'enumMap' or 'allowedValues'
    }

    private String name;
    private int start;              // 1-based inclusive
    private int end;                // 1-based inclusive
    private DataType type = DataType.STRING;

    // Optional attributes
    private Integer scale;          // for DECIMAL implied precision
    private String pattern;         // for DATE
    private Boolean trim;           // trim string
    private Boolean nullable;       // blanks allowed
    @JsonAlias({"enum", "enumMap"})
    private Map<String, String> enumMap; // for ENUM mapping (raw -> symbol)
    private List<String> allowedValues;  // optional whitelist

}

