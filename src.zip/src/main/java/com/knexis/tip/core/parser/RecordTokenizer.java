package com.knexis.tip.core.parser;

/** 1-based inclusive fixed-width slicer. */
public final class RecordTokenizer {
    private RecordTokenizer() { }

    public static String slice(String line, int start, int end) {
        if (line == null) return "";
        // Convert to 0-based substring indexes
        int from = Math.max(0, start - 1);
        int to = Math.min(line.length(), end);
        if (from >= to) return "";
        return line.substring(from, to);
    }
}