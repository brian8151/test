package com.knexis.tip.core.parser;

import com.knexis.tip.core.schema.FieldDef;
import com.knexis.tip.core.schema.RecordSchema;

/** 1-based inclusive fixed-width slicer. */
public final class RecordTokenizer {
    private RecordTokenizer() { }
    /**
     * Return a fixed-width slice using 1-based, inclusive column positions.
     *
     * <p>This helper is designed for TIP fixed-width records where field positions are
     * defined in YAML as 1-based, inclusive ranges (e.g., {@code start: 7, end: 21}).
     * Internally it converts to Java's 0-based {@code String#substring(int, int)} indices
     * and safely clips the range to the actual line length.</p>
     *
     * <h3>Behavior</h3>
     * <ul>
     *   <li>If {@code line} is {@code null}, returns {@code ""}.</li>
     *   <li>Start/end are treated as 1-based, inclusive. Example: (1,3) → characters 1..3.</li>
     *   <li>Out-of-bounds indices are clipped:
     *       <ul>
     *         <li>{@code start <= 0} behaves like {@code start = 1}.</li>
     *         <li>{@code end > line.length()} behaves like {@code end = line.length()}.</li>
     *       </ul>
     *   </li>
     *   <li>If the (clipped) start is at or beyond the (clipped) end, returns {@code ""} (no error).</li>
     *   <li>No padding is added; returned text may be shorter than the requested width if the line is short.</li>
     *   <li>Whitespace is preserved; call {@code .trim()} if desired.</li>
     * </ul>
     *
     * <h3>Examples</h3>
     * <pre>{@code
     * String s = "ABCDEFG";
     * slice(s, 1, 3);   // "ABC"
     * slice(s, 4, 6);   // "DEF"
     * slice(s, 7, 10);  // "G"   (clipped to end of line)
     * slice(s, 5, 4);   // ""    (from >= to)
     * slice(null, 1, 3);// ""
     * slice("ABC", 5, 7);// ""   (range beyond line)
     * }</pre>
     *
     * <h3>Complexity</h3>
     * Runs in O(k) for the length of the returned substring; avoids IndexOutOfBounds exceptions
     * by clipping indices.
     *
     * @param line  the source line (may be {@code null})
     * @param start 1-based inclusive start column (schema position)
     * @param end   1-based inclusive end column (schema position)
     * @return substring for the requested fixed-width range, or {@code ""} if unavailable
     */
    public static String slice(String line, int start, int end) {
        if (line == null) return "";
        // Convert to 0-based substring indexes
        int from = Math.max(0, start - 1);
        int to = Math.min(line.length(), end);
        if (from >= to) return "";
        return line.substring(from, to);
    }
    /**
     * Schema-driven extractor (preferred). Uses the header RecordSchema to locate the
     * "fileTypeText" field and slice it from the line (honors trim=true).
     *
     * @param headerLine   the first line of the file (header)
     * @param headerSchema the header RecordSchema from common-schemas.yml
     * @return fileTypeId (fileTypeText), trimmed if the schema says trim=true
     */
    public static String fileTypeId(String headerLine, RecordSchema headerSchema) {
        if (headerLine == null) throw new IllegalArgumentException("headerLine is null");
        if (headerSchema == null || headerSchema.getFields() == null) {
            throw new IllegalArgumentException("headerSchema or fields are null");
        }
        for (FieldDef f : headerSchema.getFields()) {
            if ("fileTypeText".equals(f.getName())) {
                String raw = RecordTokenizer.slice(headerLine, f.getStart(), f.getEnd());
                return Boolean.TRUE.equals(f.getTrim())
                        ? (raw == null ? "" : raw.trim())
                        : (raw == null ? "" : raw);
            }
        }
        throw new IllegalArgumentException("Header schema missing field: fileTypeText");
    }
}